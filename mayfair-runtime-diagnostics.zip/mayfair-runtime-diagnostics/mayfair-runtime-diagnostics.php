<?php
/**
 * Plugin Name:       Mayfair Runtime Diagnostics
 * Description:       Read-only runtime diagnostics for the Mayfair Properties & Developers architecture. Verifies CPTs, taxonomies, and ACF field groups against the intended specification. Makes NO changes to site content or configuration.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Mayfair Properties & Developers
 * License:           GPL-2.0-or-later
 * Text Domain:       mayfair-runtime-diagnostics
 */

/*
 * SAFETY NOTE:
 * This plugin is intentionally READ-ONLY. It performs no database writes,
 * creates no posts/terms/options, and modifies nothing. It only inspects
 * the live runtime state and renders a PASS/FAIL report under
 * Tools -> Mayfair Diagnostics.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Mayfair_Runtime_Diagnostics {

	const MENU_SLUG = 'mayfair-runtime-diagnostics';

	/** @var array Collected results: [ section, label, status(PASS|FAIL|WARN|INFO), detail ] */
	private $results = array();

	public static function init() {
		static $instance = null;
		if ( null === $instance ) {
			$instance = new self();
			add_action( 'admin_menu', array( $instance, 'register_page' ) );
		}
		return $instance;
	}

	public function register_page() {
		add_management_page(
			'Mayfair Diagnostics',
			'Mayfair Diagnostics',
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	/* ---------------------------------------------------------------------
	 * Expected specification (source of truth for comparisons)
	 * ------------------------------------------------------------------ */

	private function expected_cpts() {
		return array( 'property', 'project', 'insight' );
	}

	private function expected_taxonomies() {
		return array(
			'property-type'   => array( 'property' ),
			'property-status' => array( 'property' ),
			'location'        => array( 'property', 'project' ), // intentionally shared
			'project-type'    => array( 'project' ),
			'insight-topic'   => array( 'insight' ),
		);
	}

	private function expected_acf_groups() {
		return array(
			'property' => array(
				'title'       => 'Mayfair Property Details',
				'field_count' => 17,
				'labels'      => array(
					'Property ID', 'Price', 'Price Note', 'Area', 'Bedrooms',
					'Bathrooms', 'Floor', 'Furnishing', 'Possession', 'Locality',
					'Latitude', 'Longitude', 'Floor Plan', 'Brochure',
					'Video Tour URL', 'Feature on Homepage', 'Verified by Mayfair',
				),
			),
			'project' => array(
				'title'       => 'Mayfair Project Details',
				'field_count' => 9,
				'labels'      => array(
					'Developer Name', 'Possession Date', 'Starting Price',
					'Maximum Price', 'RERA Number', 'Project Brochure',
					'Latitude', 'Longitude', 'Show on Homepage',
				),
			),
			'insight' => array(
				'title'       => 'Mayfair Insight Details',
				'field_count' => 9,
				'labels'      => array(
					'Insight Subtitle', 'Reading Time', 'Author Name',
					'Author Image', 'Featured Insight', 'External Source URL',
					'Source Name', 'CTA Text', 'CTA URL',
				),
			),
		);
	}

	private function acf_pro_only_types() {
		return array( 'gallery', 'repeater', 'flexible_content', 'clone', 'group_clone' );
	}

	/* ---------------------------------------------------------------------
	 * Result helpers
	 * ------------------------------------------------------------------ */

	private function add( $section, $label, $status, $detail = '' ) {
		$this->results[] = array(
			'section' => $section,
			'label'   => $label,
			'status'  => $status,
			'detail'  => $detail,
		);
	}

	private function pass( $section, $label, $detail = '' ) { $this->add( $section, $label, 'PASS', $detail ); }
	private function fail( $section, $label, $detail = '' ) { $this->add( $section, $label, 'FAIL', $detail ); }
	private function warn( $section, $label, $detail = '' ) { $this->add( $section, $label, 'WARN', $detail ); }
	private function info( $section, $label, $detail = '' ) { $this->add( $section, $label, 'INFO', $detail ); }

	/* ---------------------------------------------------------------------
	 * Checks
	 * ------------------------------------------------------------------ */

	private function run_all_checks() {
		$this->results = array();
		$this->check_environment();
		$this->check_core_plugin();
		$this->check_cpts();
		$this->check_taxonomies();
		$this->check_acf();
	}

	private function check_environment() {
		global $wp_version;
		$this->info( 'Environment', 'WordPress version', $wp_version );
		$this->info( 'Environment', 'PHP version', PHP_VERSION );
		$this->info( 'Environment', 'Permalink structure', get_option( 'permalink_structure' ) ? get_option( 'permalink_structure' ) : '(plain - pretty permalinks DISABLED)' );

		if ( ! get_option( 'permalink_structure' ) ) {
			$this->warn( 'Environment', 'Pretty permalinks', 'Permalinks are set to "Plain". CPT rewrite slugs will not be used until you choose a pretty permalink structure under Settings -> Permalinks.' );
		} else {
			$this->pass( 'Environment', 'Pretty permalinks', 'Enabled' );
		}
	}

	private function check_core_plugin() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$active  = (array) get_option( 'active_plugins', array() );
		$network = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
		$all     = array_merge( $active, $network );

		$core_found = '';
		foreach ( $all as $plugin_file ) {
			if ( false !== stripos( $plugin_file, 'mayfair-properties-core' ) ) {
				$core_found = $plugin_file;
				break;
			}
		}

		if ( $core_found ) {
			$this->pass( 'Core Plugin', 'Mayfair Properties & Developers Core active', $core_found );
		} else {
			$this->fail( 'Core Plugin', 'Mayfair Properties & Developers Core active', 'No active plugin path contains "mayfair-properties-core". Active: ' . implode( ', ', $all ) );
		}

		$acf_found = '';
		foreach ( $all as $plugin_file ) {
			if ( false !== stripos( $plugin_file, 'advanced-custom-fields' ) || false !== stripos( $plugin_file, 'acf' ) ) {
				$acf_found = $plugin_file;
				break;
			}
		}

		if ( function_exists( 'acf_get_field_groups' ) ) {
			$acf_version = defined( 'ACF_VERSION' ) ? ACF_VERSION : ( function_exists( 'acf_get_setting' ) ? acf_get_setting( 'version' ) : 'unknown' );
			$is_pro      = ( defined( 'ACF_PRO' ) && ACF_PRO ) || ( function_exists( 'acf_get_setting' ) && acf_get_setting( 'pro' ) );
			$this->pass( 'Core Plugin', 'ACF loaded', 'Version ' . $acf_version . ( $is_pro ? ' (PRO)' : ' (Free)' ) . ( $acf_found ? ' - ' . $acf_found : '' ) );
			if ( $is_pro ) {
				$this->info( 'Core Plugin', 'ACF edition', 'ACF Pro detected. The architecture does not require Pro; free ACF is sufficient.' );
			}
		} else {
			$this->fail( 'Core Plugin', 'ACF loaded', 'acf_get_field_groups() is not available. Is ACF installed and active?' );
		}
	}

	private function check_cpts() {
		foreach ( $this->expected_cpts() as $cpt ) {
			if ( ! post_type_exists( $cpt ) ) {
				$this->fail( 'Custom Post Types', "CPT '{$cpt}' registered", 'post_type_exists() returned false.' );
				continue;
			}
			$this->pass( 'Custom Post Types', "CPT '{$cpt}' registered" );

			$obj = get_post_type_object( $cpt );

			// Visibility / query configuration.
			if ( $obj->public && $obj->publicly_queryable && $obj->show_ui && $obj->show_in_menu ) {
				$this->pass( 'Custom Post Types', "CPT '{$cpt}' visibility", 'public, publicly_queryable, show_ui, show_in_menu all true' );
			} else {
				$this->fail( 'Custom Post Types', "CPT '{$cpt}' visibility", sprintf(
					'public=%s publicly_queryable=%s show_ui=%s show_in_menu=%s',
					var_export( (bool) $obj->public, true ),
					var_export( (bool) $obj->publicly_queryable, true ),
					var_export( (bool) $obj->show_ui, true ),
					var_export( (bool) ( $obj->show_in_menu ? true : false ), true )
				) );
			}

			// REST (required for Elementor dynamic data + block editor).
			if ( ! empty( $obj->show_in_rest ) ) {
				$this->pass( 'Custom Post Types', "CPT '{$cpt}' show_in_rest", 'rest_base=' . ( $obj->rest_base ? $obj->rest_base : $cpt ) );
			} else {
				$this->fail( 'Custom Post Types', "CPT '{$cpt}' show_in_rest", 'show_in_rest is false; Elementor/REST integrations may not see this CPT.' );
			}

			// Archive + rewrite.
			if ( ! empty( $obj->has_archive ) ) {
				$archive = is_string( $obj->has_archive ) ? $obj->has_archive : '(default)';
				$this->pass( 'Custom Post Types', "CPT '{$cpt}' has_archive", 'archive slug: ' . $archive );
			} else {
				$this->warn( 'Custom Post Types', "CPT '{$cpt}' has_archive", 'No archive registered. Listing pages must be built manually if intended.' );
			}

			$rewrite_slug = ( is_array( $obj->rewrite ) && ! empty( $obj->rewrite['slug'] ) ) ? $obj->rewrite['slug'] : $cpt;
			$this->info( 'Custom Post Types', "CPT '{$cpt}' rewrite slug", $rewrite_slug );

			// Supports.
			$expected_supports = array( 'title', 'editor', 'excerpt', 'thumbnail' );
			$missing           = array();
			foreach ( $expected_supports as $feature ) {
				if ( ! post_type_supports( $cpt, $feature ) ) {
					$missing[] = $feature;
				}
			}
			if ( empty( $missing ) ) {
				$this->pass( 'Custom Post Types', "CPT '{$cpt}' supports", 'title, editor, excerpt, thumbnail all supported' );
			} else {
				$this->fail( 'Custom Post Types', "CPT '{$cpt}' supports", 'Missing: ' . implode( ', ', $missing ) );
			}

			// Sample permalink (read-only query).
			$sample = get_posts( array(
				'post_type'        => $cpt,
				'posts_per_page'   => 1,
				'post_status'      => 'publish',
				'suppress_filters' => true,
				'no_found_rows'    => true,
			) );
			if ( $sample ) {
				$this->info( 'Custom Post Types', "CPT '{$cpt}' sample permalink", get_permalink( $sample[0] ) );
			} else {
				$this->info( 'Custom Post Types', "CPT '{$cpt}' sample permalink", 'No published posts yet - cannot show a sample URL.' );
			}
		}
	}

	private function check_taxonomies() {
		$shared_location_ok = true;

		foreach ( $this->expected_taxonomies() as $tax => $expected_objects ) {
			if ( ! taxonomy_exists( $tax ) ) {
				$this->fail( 'Taxonomies', "Taxonomy '{$tax}' registered", 'taxonomy_exists() returned false.' );
				if ( 'location' === $tax ) {
					$shared_location_ok = false;
				}
				continue;
			}
			$this->pass( 'Taxonomies', "Taxonomy '{$tax}' registered" );

			$tax_obj = get_taxonomy( $tax );
			$actual  = (array) $tax_obj->object_type;
			sort( $actual );
			$expected_sorted = $expected_objects;
			sort( $expected_sorted );

			if ( $actual === $expected_sorted ) {
				$this->pass( 'Taxonomies', "Taxonomy '{$tax}' attached to correct CPTs", implode( ', ', $actual ) );
			} else {
				$this->fail( 'Taxonomies', "Taxonomy '{$tax}' attached to correct CPTs", 'Expected [' . implode( ', ', $expected_sorted ) . '] but found [' . implode( ', ', $actual ) . ']' );
				if ( 'location' === $tax ) {
					$shared_location_ok = false;
				}
			}

			if ( empty( $tax_obj->show_in_rest ) ) {
				$this->warn( 'Taxonomies', "Taxonomy '{$tax}' show_in_rest", 'Not exposed in REST; block editor / Elementor taxonomy controls may not list it.' );
			}
		}

		// Shared location taxonomy: exactly one, shared by property + project.
		if ( $shared_location_ok && taxonomy_exists( 'location' ) ) {
			$this->pass( 'Taxonomies', 'Single shared location taxonomy', "One 'location' taxonomy is shared by property and project." );
		}

		// Look for accidental duplicate location-like taxonomies.
		$all_taxes  = get_taxonomies( array(), 'names' );
		$suspicious = array();
		foreach ( $all_taxes as $name ) {
			if ( 'location' !== $name && false !== stripos( $name, 'location' ) ) {
				$suspicious[] = $name;
			}
		}
		if ( $suspicious ) {
			$this->warn( 'Taxonomies', 'Possible duplicate location taxonomies', implode( ', ', $suspicious ) );
		} else {
			$this->pass( 'Taxonomies', 'No duplicate location-like taxonomies found' );
		}
	}

	private function check_acf() {
		if ( ! function_exists( 'acf_get_field_groups' ) || ! function_exists( 'acf_get_fields' ) ) {
			$this->fail( 'ACF', 'ACF functions available', 'Cannot run ACF checks because ACF is not loaded.' );
			return;
		}

		$expected_groups = $this->expected_acf_groups();
		$pro_types       = $this->acf_pro_only_types();

		foreach ( $expected_groups as $cpt => $spec ) {

			// Find groups whose location rules target this CPT.
			$groups_for_cpt = acf_get_field_groups( array( 'post_type' => $cpt ) );
			$group          = null;
			foreach ( $groups_for_cpt as $g ) {
				if ( 0 === strcasecmp( trim( $g['title'] ), $spec['title'] ) ) {
					$group = $g;
					break;
				}
			}

			// Fallback: search all groups by title (location rule may be wrong).
			$location_rule_ok = ( null !== $group );
			if ( ! $group ) {
				foreach ( acf_get_field_groups() as $g ) {
					if ( 0 === strcasecmp( trim( $g['title'] ), $spec['title'] ) ) {
						$group = $g;
						break;
					}
				}
			}

			if ( ! $group ) {
				$this->fail( 'ACF', "Field group '{$spec['title']}' exists", 'No ACF field group with this title was found on the live site.' );
				continue;
			}
			$this->pass( 'ACF', "Field group '{$spec['title']}' exists", 'key=' . $group['key'] . ( ! empty( $group['active'] ) ? ' (active)' : ' (INACTIVE)' ) );

			if ( isset( $group['active'] ) && ! $group['active'] ) {
				$this->fail( 'ACF', "Field group '{$spec['title']}' active", 'Group exists but is set to inactive.' );
			}

			if ( $location_rule_ok ) {
				$this->pass( 'ACF', "Field group '{$spec['title']}' location rule", "Correctly targets post type '{$cpt}'." );
			} else {
				$this->fail( 'ACF', "Field group '{$spec['title']}' location rule", "Group found by title but its location rules do NOT target post type '{$cpt}'." );
			}

			// Fields.
			$fields = acf_get_fields( $group );
			if ( ! is_array( $fields ) ) {
				$fields = array();
			}

			$count = count( $fields );
			if ( $count === $spec['field_count'] ) {
				$this->pass( 'ACF', "Field group '{$spec['title']}' field count", $count . ' fields (expected ' . $spec['field_count'] . ')' );
			} else {
				$this->fail( 'ACF', "Field group '{$spec['title']}' field count", 'Found ' . $count . ' fields, expected ' . $spec['field_count'] . '.' );
			}

			// Pro-only field type scan.
			$found_pro = array();
			foreach ( $fields as $f ) {
				if ( in_array( $f['type'], $pro_types, true ) ) {
					$found_pro[] = $f['label'] . ' (' . $f['type'] . ')';
				}
			}
			if ( $found_pro ) {
				$this->fail( 'ACF', "Field group '{$spec['title']}' free-ACF compliance", 'Pro-only field types found: ' . implode( ', ', $found_pro ) );
			} else {
				$this->pass( 'ACF', "Field group '{$spec['title']}' free-ACF compliance", 'No Gallery/Repeater/Flexible Content/Clone fields.' );
			}

			// Live vs expected field labels.
			$live_labels = array();
			foreach ( $fields as $f ) {
				$live_labels[] = trim( $f['label'] );
			}
			$missing = array_udiff( $spec['labels'], $live_labels, 'strcasecmp' );
			$extra   = array_udiff( $live_labels, $spec['labels'], 'strcasecmp' );

			if ( empty( $missing ) && empty( $extra ) ) {
				$this->pass( 'ACF', "Field group '{$spec['title']}' fields match expected definition", 'All ' . count( $spec['labels'] ) . ' expected fields present, no unexpected fields.' );
			} else {
				$detail = '';
				if ( $missing ) {
					$detail .= 'Missing: ' . implode( ', ', $missing ) . '. ';
				}
				if ( $extra ) {
					$detail .= 'Unexpected: ' . implode( ', ', $extra ) . '.';
				}
				$this->fail( 'ACF', "Field group '{$spec['title']}' fields match expected definition", trim( $detail ) );
			}

			// Field inventory (informational).
			$inventory = array();
			foreach ( $fields as $f ) {
				$inventory[] = $f['label'] . ' [' . $f['name'] . ':' . $f['type'] . ']';
			}
			$this->info( 'ACF', "Field group '{$spec['title']}' live field inventory", implode( ' | ', $inventory ) );
		}
	}

	/* ---------------------------------------------------------------------
	 * Rendering
	 * ------------------------------------------------------------------ */

	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'mayfair-runtime-diagnostics' ) );
		}

		$this->run_all_checks();

		$totals = array( 'PASS' => 0, 'FAIL' => 0, 'WARN' => 0, 'INFO' => 0 );
		foreach ( $this->results as $r ) {
			$totals[ $r['status'] ]++;
		}

		$colors = array(
			'PASS' => '#00a32a',
			'FAIL' => '#d63638',
			'WARN' => '#dba617',
			'INFO' => '#72777c',
		);

		echo '<div class="wrap">';
		echo '<h1>Mayfair Runtime Diagnostics</h1>';
		echo '<p><em>Read-only report generated ' . esc_html( date_i18n( 'Y-m-d H:i:s' ) ) . '. This plugin makes no changes to your site.</em></p>';

		echo '<p style="font-size:15px;">';
		foreach ( $totals as $status => $n ) {
			echo '<span style="display:inline-block;margin-right:16px;font-weight:600;color:' . esc_attr( $colors[ $status ] ) . ';">' . esc_html( $status . ': ' . $n ) . '</span>';
		}
		echo '</p>';

		if ( 0 === $totals['FAIL'] ) {
			echo '<div style="padding:12px 16px;border-left:4px solid #00a32a;background:#f0f6f0;margin:12px 0;"><strong>All structural checks passed.</strong> The live installation matches the intended Mayfair architecture.</div>';
		} else {
			echo '<div style="padding:12px 16px;border-left:4px solid #d63638;background:#fcf0f1;margin:12px 0;"><strong>' . (int) $totals['FAIL'] . ' check(s) failed.</strong> Copy this report (or screenshot it) and share it for analysis before changing anything.</div>';
		}

		$current_section = '';
		echo '<table class="widefat striped" style="max-width:1200px;">';
		echo '<thead><tr><th style="width:90px;">Status</th><th style="width:380px;">Check</th><th>Detail</th></tr></thead><tbody>';
		foreach ( $this->results as $r ) {
			if ( $r['section'] !== $current_section ) {
				$current_section = $r['section'];
				echo '<tr><td colspan="3" style="background:#f0f0f1;font-weight:700;">' . esc_html( $current_section ) . '</td></tr>';
			}
			echo '<tr>';
			echo '<td><strong style="color:' . esc_attr( $colors[ $r['status'] ] ) . ';">' . esc_html( $r['status'] ) . '</strong></td>';
			echo '<td>' . esc_html( $r['label'] ) . '</td>';
			echo '<td>' . esc_html( $r['detail'] ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table>';

		// Plain-text copy block for easy sharing.
		$plain = "MAYFAIR RUNTIME DIAGNOSTICS - " . date_i18n( 'Y-m-d H:i:s' ) . "\n";
		$plain .= sprintf( "PASS:%d FAIL:%d WARN:%d INFO:%d\n\n", $totals['PASS'], $totals['FAIL'], $totals['WARN'], $totals['INFO'] );
		$current_section = '';
		foreach ( $this->results as $r ) {
			if ( $r['section'] !== $current_section ) {
				$current_section = $r['section'];
				$plain          .= "== {$current_section} ==\n";
			}
			$plain .= sprintf( "[%s] %s%s\n", $r['status'], $r['label'], $r['detail'] ? ' -- ' . $r['detail'] : '' );
		}

		echo '<h2 style="margin-top:24px;">Copy-paste version</h2>';
		echo '<p>Select all text below and copy it to share the full report:</p>';
		echo '<textarea readonly style="width:100%;max-width:1200px;height:280px;font-family:monospace;font-size:12px;" onclick="this.select();">' . esc_textarea( $plain ) . '</textarea>';

		echo '</div>';
	}
}

add_action( 'plugins_loaded', array( 'Mayfair_Runtime_Diagnostics', 'init' ) );
