<?php
/**
 * Locked design system reference screen (read-only).
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpia_tokens = MPIA_Profile::design_tokens();
$mpia_shape  = MPIA_Profile::shape();
?>
<div class="wrap mpia-wrap">
	<h1><?php esc_html_e( 'Locked Design System — Mayfair Heritage', 'mayfair-implementation-assistant' ); ?></h1>
	<p><?php esc_html_e( 'This profile is LOCKED. Imported AI material that conflicts with it is flagged as DESIGN SYSTEM CONFLICT with a recommended replacement. The plugin never silently overwrites imported material — you decide, then implement the locked value.', 'mayfair-implementation-assistant' ); ?></p>

	<h2><?php esc_html_e( 'Color Tokens', 'mayfair-implementation-assistant' ); ?></h2>
	<table class="widefat striped" style="max-width:640px;">
		<thead><tr><th></th><th><?php esc_html_e( 'Token', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Hex', 'mayfair-implementation-assistant' ); ?></th></tr></thead>
		<tbody>
		<?php foreach ( $mpia_tokens as $mpia_name => $mpia_hex ) : ?>
			<tr>
				<td style="width:48px;"><span style="display:inline-block;width:28px;height:28px;border:1px solid #C4C7C7;background:<?php echo esc_attr( $mpia_hex ); ?>;"></span></td>
				<td><?php echo esc_html( ucwords( str_replace( '_', ' ', $mpia_name ) ) ); ?></td>
				<td><code><?php echo esc_html( strtoupper( $mpia_hex ) ); ?></code></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Typography', 'mayfair-implementation-assistant' ); ?></h2>
	<ul>
		<li><strong>Playfair Display</strong> — <?php esc_html_e( 'headings and editorial numerals', 'mayfair-implementation-assistant' ); ?></li>
		<li><strong>Inter</strong> — <?php esc_html_e( 'body text, UI, labels, buttons', 'mayfair-implementation-assistant' ); ?></li>
	</ul>
	<p class="description"><?php esc_html_e( 'Only these two families. Generic fallbacks (serif, sans-serif, Georgia, Arial, Helvetica) are tolerated inside font stacks.', 'mayfair-implementation-assistant' ); ?></p>

	<h2><?php esc_html_e( 'Shape & Motion', 'mayfair-implementation-assistant' ); ?></h2>
	<ul>
		<li><?php esc_html_e( 'Language:', 'mayfair-implementation-assistant' ); ?> <strong><?php echo esc_html( $mpia_shape['language'] ); ?></strong></li>
		<li><?php esc_html_e( 'Card/button radius: 2-4px maximum', 'mayfair-implementation-assistant' ); ?></li>
		<li><?php esc_html_e( 'Image radius: 0-2px', 'mayfair-implementation-assistant' ); ?></li>
		<li><?php esc_html_e( 'Motion: subtle transitions only; respect prefers-reduced-motion', 'mayfair-implementation-assistant' ); ?></li>
	</ul>
</div>
