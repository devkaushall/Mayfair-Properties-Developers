<?php
/**
 * Dashboard: projects overview, statuses, quick links.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpia_projects = MPIA_Projects::all();
$mpia_statuses = MPIA_Profile::project_statuses();
$mpia_counts   = array_fill_keys( array_keys( $mpia_statuses ), 0 );
foreach ( $mpia_projects as $mpia_p ) {
	if ( isset( $mpia_counts[ $mpia_p['status'] ] ) ) {
		$mpia_counts[ $mpia_p['status'] ]++;
	}
}
?>
<div class="wrap mpia-wrap">
	<h1><?php esc_html_e( 'Mayfair Implementation — Dashboard', 'mayfair-implementation-assistant' ); ?></h1>
	<?php if ( isset( $_GET['mpia_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpia_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<p class="mpia-intro"><?php esc_html_e( 'Paste or upload AI-generated design/code output. The assistant analyzes it against the locked Mayfair architecture and design system, flags conflicts, and produces click-by-click Elementor implementation guides. It never changes the website automatically.', 'mayfair-implementation-assistant' ); ?></p>

	<div class="mpia-cards">
		<div class="mpia-card"><span class="mpia-card__n"><?php echo esc_html( count( $mpia_projects ) ); ?></span><span class="mpia-card__l"><?php esc_html_e( 'Projects', 'mayfair-implementation-assistant' ); ?></span></div>
		<?php foreach ( array( 'ready', 'needs_review', 'implemented', 'draft' ) as $mpia_key ) : ?>
			<div class="mpia-card"><span class="mpia-card__n"><?php echo esc_html( $mpia_counts[ $mpia_key ] ); ?></span><span class="mpia-card__l"><?php echo esc_html( $mpia_statuses[ $mpia_key ] ); ?></span></div>
		<?php endforeach; ?>
	</div>

	<h2><?php esc_html_e( 'Recent Projects', 'mayfair-implementation-assistant' ); ?></h2>
	<table class="widefat striped">
		<thead><tr>
			<th><?php esc_html_e( 'Project', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Type', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Status', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Versions', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Updated', 'mayfair-implementation-assistant' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( array_slice( $mpia_projects, 0, 10 ) as $mpia_p ) : ?>
			<tr>
				<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-projects&project=' . (int) $mpia_p['id'] ) ); ?>"><?php echo esc_html( $mpia_p['name'] ); ?></a></strong></td>
				<td><?php echo esc_html( $mpia_p['project_type'] ); ?></td>
				<td><span class="mpia-badge mpia-badge--<?php echo esc_attr( $mpia_p['status'] ); ?>"><?php echo esc_html( isset( $mpia_statuses[ $mpia_p['status'] ] ) ? $mpia_statuses[ $mpia_p['status'] ] : $mpia_p['status'] ); ?></span></td>
				<td>v<?php echo esc_html( $mpia_p['current_version'] ); ?></td>
				<td><?php echo esc_html( $mpia_p['updated_at'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( empty( $mpia_projects ) ) : ?>
			<tr><td colspan="5"><?php esc_html_e( 'No projects yet — create one under Projects.', 'mayfair-implementation-assistant' ); ?></td></tr>
		<?php endif; ?>
		</tbody>
	</table>

	<p style="margin-top:16px;">
		<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-projects' ) ); ?>"><?php esc_html_e( 'Go to Projects', 'mayfair-implementation-assistant' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-design' ) ); ?>"><?php esc_html_e( 'View Locked Design System', 'mayfair-implementation-assistant' ); ?></a>
		<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-architecture' ) ); ?>"><?php esc_html_e( 'View Locked Architecture', 'mayfair-implementation-assistant' ); ?></a>
	</p>
</div>
