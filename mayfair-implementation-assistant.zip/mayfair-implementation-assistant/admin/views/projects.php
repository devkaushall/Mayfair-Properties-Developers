<?php
/**
 * Projects list + create form.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpia_statuses = MPIA_Profile::project_statuses();
?>
<div class="wrap mpia-wrap">
	<h1><?php esc_html_e( 'Projects', 'mayfair-implementation-assistant' ); ?></h1>
	<?php if ( isset( $_GET['mpia_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpia_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Create Project', 'mayfair-implementation-assistant' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mpia-createbar">
		<input type="hidden" name="action" value="mpia_admin_action">
		<input type="hidden" name="mpia_task" value="create_project">
		<?php wp_nonce_field( 'mpia_admin_create_project', '_mpianonce' ); ?>
		<input type="text" name="name" class="regular-text" placeholder="<?php esc_attr_e( 'Project name', 'mayfair-implementation-assistant' ); ?>" required>
		<select name="project_type">
			<?php foreach ( MPIA_Profile::project_types() as $mpia_k => $mpia_l ) : ?>
				<option value="<?php echo esc_attr( $mpia_k ); ?>"><?php echo esc_html( $mpia_l ); ?></option>
			<?php endforeach; ?>
		</select>
		<input type="text" name="description" class="regular-text" placeholder="<?php esc_attr_e( 'Description (optional)', 'mayfair-implementation-assistant' ); ?>">
		<?php submit_button( __( 'Create', 'mayfair-implementation-assistant' ), 'primary', 'submit', false ); ?>
	</form>

	<table class="widefat striped" style="margin-top:20px;">
		<thead><tr>
			<th>ID</th>
			<th><?php esc_html_e( 'Project', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Type', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Status', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Version', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Created', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Updated', 'mayfair-implementation-assistant' ); ?></th>
			<th><?php esc_html_e( 'Actions', 'mayfair-implementation-assistant' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( MPIA_Projects::all() as $mpia_p ) : ?>
			<tr>
				<td><?php echo esc_html( $mpia_p['id'] ); ?></td>
				<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-projects&project=' . (int) $mpia_p['id'] ) ); ?>"><?php echo esc_html( $mpia_p['name'] ); ?></a></strong></td>
				<td><?php echo esc_html( $mpia_p['project_type'] ); ?></td>
				<td><span class="mpia-badge mpia-badge--<?php echo esc_attr( $mpia_p['status'] ); ?>"><?php echo esc_html( isset( $mpia_statuses[ $mpia_p['status'] ] ) ? $mpia_statuses[ $mpia_p['status'] ] : $mpia_p['status'] ); ?></span></td>
				<td>v<?php echo esc_html( $mpia_p['current_version'] ); ?></td>
				<td><?php echo esc_html( $mpia_p['created_at'] ); ?></td>
				<td><?php echo esc_html( $mpia_p['updated_at'] ); ?></td>
				<td>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpia_admin_action">
						<input type="hidden" name="mpia_task" value="delete_project">
						<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_p['id'] ); ?>">
						<?php wp_nonce_field( 'mpia_admin_delete_project', '_mpianonce' ); ?>
						<button type="submit" class="button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this project and all its versions/analyses?', 'mayfair-implementation-assistant' ) ); ?>');"><?php esc_html_e( 'Delete', 'mayfair-implementation-assistant' ); ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
