<?php
/**
 * Project detail: import (paste/upload), versions, analysis review,
 * guide display, step tracker, exports.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpia_id = isset( $_GET['project'] ) ? (int) $_GET['project'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mpia_p  = MPIA_Projects::get( $mpia_id );
if ( ! $mpia_p ) {
	echo '<div class="wrap"><p>' . esc_html__( 'Project not found.', 'mayfair-implementation-assistant' ) . '</p></div>';
	return;
}
$mpia_versions   = MPIA_Projects::versions_for( $mpia_id );
$mpia_sel_ver    = isset( $_GET['ver'] ) ? (int) $_GET['ver'] : ( ! empty( $mpia_versions ) ? (int) $mpia_versions[0]['id'] : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mpia_version    = $mpia_sel_ver ? MPIA_Projects::get_version( $mpia_sel_ver ) : null;
$mpia_bundle     = $mpia_sel_ver ? MPIA_Projects::latest_analysis( $mpia_sel_ver ) : null;
$mpia_steps      = $mpia_sel_ver ? MPIA_Projects::steps_for( $mpia_sel_ver ) : array();
$mpia_progress   = $mpia_sel_ver ? MPIA_Projects::progress( $mpia_sel_ver ) : array( 'done' => 0, 'total' => 0 );
$mpia_statuses   = MPIA_Profile::project_statuses();
$mpia_step_stats = MPIA_Profile::step_statuses();
?>
<div class="wrap mpia-wrap">
	<h1><?php echo esc_html( $mpia_p['name'] ); ?>
		<span class="mpia-badge mpia-badge--<?php echo esc_attr( $mpia_p['status'] ); ?>"><?php echo esc_html( isset( $mpia_statuses[ $mpia_p['status'] ] ) ? $mpia_statuses[ $mpia_p['status'] ] : $mpia_p['status'] ); ?></span>
	</h1>
	<?php if ( isset( $_GET['mpia_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpia_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>
	<p><?php echo esc_html( $mpia_p['description'] ); ?></p>

	<div class="mpia-detail-grid">
		<div>
			<h2><?php esc_html_e( 'Import AI Output', 'mayfair-implementation-assistant' ); ?></h2>

			<h3><?php esc_html_e( 'Paste Content', 'mayfair-implementation-assistant' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="mpia_admin_action">
				<input type="hidden" name="mpia_task" value="paste_content">
				<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_id ); ?>">
				<?php wp_nonce_field( 'mpia_admin_paste_content', '_mpianonce' ); ?>
				<textarea name="content" rows="10" class="mpia-code" placeholder="<?php esc_attr_e( 'Paste CSS / HTML / JSON / Markdown / text here. The type is detected automatically. PHP is refused.', 'mayfair-implementation-assistant' ); ?>"></textarea>
				<?php submit_button( __( 'Import & Analyze', 'mayfair-implementation-assistant' ), 'primary', 'submit', false ); ?>
			</form>

			<h3 style="margin-top:18px;"><?php esc_html_e( 'Upload File or ZIP', 'mayfair-implementation-assistant' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="mpia_admin_action">
				<input type="hidden" name="mpia_task" value="upload_file">
				<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_id ); ?>">
				<?php wp_nonce_field( 'mpia_admin_upload_file', '_mpianonce' ); ?>
				<input type="file" name="import_file" accept=".css,.html,.htm,.json,.md,.markdown,.txt,.xml,.zip" required>
				<?php submit_button( __( 'Upload & Analyze', 'mayfair-implementation-assistant' ), 'secondary', 'submit', false ); ?>
				<p class="description"><?php esc_html_e( 'Allowed: CSS, HTML, JSON, MD, TXT, XML, ZIP (inspected safely — PHP/JS inside ZIPs is listed but never imported or executed).', 'mayfair-implementation-assistant' ); ?></p>
			</form>

			<?php if ( ! empty( $mpia_versions ) ) : ?>
				<h2 style="margin-top:24px;"><?php esc_html_e( 'Versions', 'mayfair-implementation-assistant' ); ?></h2>
				<table class="widefat striped">
					<thead><tr><th>v</th><th><?php esc_html_e( 'Type', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Source', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Imported', 'mayfair-implementation-assistant' ); ?></th><th></th></tr></thead>
					<tbody>
					<?php foreach ( $mpia_versions as $mpia_v ) : ?>
						<tr <?php echo ( (int) $mpia_v['id'] === $mpia_sel_ver ) ? 'style="background:#F5F0E7;"' : ''; ?>>
							<td><strong>v<?php echo esc_html( $mpia_v['version_number'] ); ?></strong></td>
							<td><?php echo esc_html( strtoupper( $mpia_v['input_type'] ) ); ?></td>
							<td><?php echo esc_html( $mpia_v['source'] . ( $mpia_v['original_filename'] ? ': ' . $mpia_v['original_filename'] : '' ) ); ?></td>
							<td><?php echo esc_html( $mpia_v['created_at'] ); ?></td>
							<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-projects&project=' . $mpia_id . '&ver=' . (int) $mpia_v['id'] ) ); ?>"><?php esc_html_e( 'Open', 'mayfair-implementation-assistant' ); ?></a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Every import becomes a new version. Open an older version to compare or re-export its analysis.', 'mayfair-implementation-assistant' ); ?></p>
			<?php endif; ?>

			<?php if ( $mpia_bundle && ! empty( $mpia_bundle['guide'] ) ) : ?>
				<?php $mpia_guide = $mpia_bundle['guide']; ?>

				<h2 style="margin-top:24px;"><?php esc_html_e( 'A. What This Output Is', 'mayfair-implementation-assistant' ); ?></h2>
				<p><strong><?php echo esc_html( $mpia_guide['summary']['what_this_is'] ); ?></strong></p>
				<p><?php esc_html_e( 'Classification:', 'mayfair-implementation-assistant' ); ?>
					<?php foreach ( (array) $mpia_guide['summary']['classification'] as $mpia_tag ) : ?>
						<span class="mpia-tag"><?php echo esc_html( $mpia_tag ); ?></span>
					<?php endforeach; ?>
				</p>

				<h2><?php esc_html_e( 'B. Where To Implement', 'mayfair-implementation-assistant' ); ?></h2>
				<p class="mpia-where"><?php echo esc_html( $mpia_guide['summary']['where'] ); ?></p>

				<h2><?php esc_html_e( 'Conflicts', 'mayfair-implementation-assistant' ); ?> (<?php echo esc_html( count( $mpia_bundle['conflicts'] ) ); ?>)</h2>
				<?php if ( empty( $mpia_bundle['conflicts'] ) ) : ?>
					<p><?php esc_html_e( 'None detected — material aligns with the locked Mayfair profile.', 'mayfair-implementation-assistant' ); ?></p>
				<?php else : ?>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Severity', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Category', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Found', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Expected', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Recommendation', 'mayfair-implementation-assistant' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $mpia_bundle['conflicts'] as $mpia_c ) : ?>
							<tr>
								<td><span class="mpia-sev mpia-sev--<?php echo esc_attr( $mpia_c['severity'] ); ?>"><?php echo esc_html( strtoupper( $mpia_c['severity'] ) ); ?></span></td>
								<td><?php echo esc_html( $mpia_c['category'] ); ?></td>
								<td><code><?php echo esc_html( $mpia_c['found'] ); ?></code></td>
								<td><?php echo esc_html( $mpia_c['expected'] ); ?></td>
								<td><?php echo esc_html( $mpia_c['recommendation'] ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>

				<h2><?php esc_html_e( 'C. Implementation Steps', 'mayfair-implementation-assistant' ); ?>
					<span class="mpia-progress"><?php echo esc_html( $mpia_progress['done'] . ' / ' . $mpia_progress['total'] . ' ' . __( 'completed', 'mayfair-implementation-assistant' ) ); ?></span>
				</h2>
				<table class="widefat striped">
					<tbody>
					<?php foreach ( $mpia_steps as $mpia_index => $mpia_step ) : ?>
						<tr>
							<td style="width:36px;"><strong><?php echo esc_html( $mpia_index + 1 ); ?>.</strong></td>
							<td><?php echo esc_html( $mpia_step['step_text'] ); ?></td>
							<td style="width:230px;">
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="mpia_admin_action">
									<input type="hidden" name="mpia_task" value="set_step_status">
									<input type="hidden" name="step_id" value="<?php echo esc_attr( $mpia_step['id'] ); ?>">
									<?php wp_nonce_field( 'mpia_admin_set_step_status', '_mpianonce' ); ?>
									<select name="status" onchange="this.form.submit();">
										<?php foreach ( $mpia_step_stats as $mpia_sk => $mpia_sl ) : ?>
											<option value="<?php echo esc_attr( $mpia_sk ); ?>" <?php selected( $mpia_step['status'], $mpia_sk ); ?>><?php echo esc_html( $mpia_sl ); ?></option>
										<?php endforeach; ?>
									</select>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ( ! empty( $mpia_guide['dynamic_map'] ) ) : ?>
					<h2><?php esc_html_e( 'Dynamic Data Validation', 'mayfair-implementation-assistant' ); ?></h2>
					<table class="widefat striped">
						<thead><tr><th><?php esc_html_e( 'Reference', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Result', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Binding', 'mayfair-implementation-assistant' ); ?></th></tr></thead>
						<tbody>
						<?php foreach ( $mpia_guide['dynamic_map'] as $mpia_row ) : ?>
							<tr>
								<td><code><?php echo esc_html( $mpia_row['reference'] ); ?></code></td>
								<td><span class="mpia-sev mpia-sev--<?php echo esc_attr( 'PASS' === $mpia_row['result'] ? 'low' : 'critical' ); ?>"><?php echo esc_html( $mpia_row['result'] ); ?></span></td>
								<td><?php echo esc_html( $mpia_row['binding'] ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>

				<?php if ( ! empty( $mpia_guide['css_guide'] ) ) : ?>
					<h2><?php esc_html_e( 'CSS Blocks', 'mayfair-implementation-assistant' ); ?></h2>
					<?php foreach ( $mpia_guide['css_guide'] as $mpia_bi => $mpia_block ) : ?>
						<div class="mpia-cssblock">
							<p><strong><?php echo esc_html( $mpia_block['selector'] ); ?></strong> — <?php echo esc_html( $mpia_block['purpose'] ); ?><br>
							<em><?php echo esc_html( $mpia_block['where'] ); ?></em><br>
							<?php echo esc_html( $mpia_block['required_class'] ); ?></p>
							<textarea readonly rows="3" class="mpia-code" onclick="this.select();"><?php echo esc_textarea( $mpia_block['css'] ); ?></textarea>
						</div>
					<?php endforeach; ?>
					<p class="description"><?php esc_html_e( 'Click any block to select it, then copy. The full source is available via Export → CSS file.', 'mayfair-implementation-assistant' ); ?></p>
				<?php endif; ?>

				<h2><?php esc_html_e( 'Responsive', 'mayfair-implementation-assistant' ); ?></h2>
				<p><?php echo esc_html( $mpia_guide['responsive']['note'] ); ?></p>
				<table class="widefat striped">
					<thead><tr><th></th><th><?php esc_html_e( 'Width', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Columns', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Type', 'mayfair-implementation-assistant' ); ?></th><th><?php esc_html_e( 'Visibility', 'mayfair-implementation-assistant' ); ?></th></tr></thead>
					<tbody>
					<?php foreach ( $mpia_guide['responsive']['devices'] as $mpia_dev => $mpia_spec ) : ?>
						<tr><td><strong><?php echo esc_html( ucfirst( $mpia_dev ) ); ?></strong></td><td><?php echo esc_html( $mpia_spec['width'] ); ?></td><td><?php echo esc_html( $mpia_spec['columns'] ); ?></td><td><?php echo esc_html( $mpia_spec['font'] ); ?></td><td><?php echo esc_html( $mpia_spec['visibility'] ); ?></td></tr>
					<?php endforeach; ?>
					</tbody>
				</table>

				<h2><?php esc_html_e( 'QA Checklist', 'mayfair-implementation-assistant' ); ?></h2>
				<ul class="mpia-qa">
					<?php foreach ( $mpia_guide['qa_checklist'] as $mpia_item ) : ?>
						<li>&#9744; <?php echo esc_html( $mpia_item ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div>
			<h2><?php esc_html_e( 'Project Status', 'mayfair-implementation-assistant' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="mpia_admin_action">
				<input type="hidden" name="mpia_task" value="set_project_status">
				<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_id ); ?>">
				<?php wp_nonce_field( 'mpia_admin_set_project_status', '_mpianonce' ); ?>
				<select name="status">
					<?php foreach ( $mpia_statuses as $mpia_sk => $mpia_sl ) : ?>
						<option value="<?php echo esc_attr( $mpia_sk ); ?>" <?php selected( $mpia_p['status'], $mpia_sk ); ?>><?php echo esc_html( $mpia_sl ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php submit_button( __( 'Update', 'mayfair-implementation-assistant' ), 'secondary', 'submit', false ); ?>
			</form>

			<?php if ( $mpia_version && $mpia_bundle ) : ?>
				<h2><?php esc_html_e( 'Export Guide', 'mayfair-implementation-assistant' ); ?></h2>
				<?php
				$mpia_formats = array( 'pdf' => 'PDF', 'txt' => 'TXT', 'md' => 'Markdown', 'json' => 'JSON', 'zip' => 'Project ZIP' );
				if ( 'css' === $mpia_version['input_type'] ) {
					$mpia_formats['css'] = 'CSS file';
				}
				if ( 'html' === $mpia_version['input_type'] ) {
					$mpia_formats['html'] = 'HTML reference';
				}
				foreach ( $mpia_formats as $mpia_fmt => $mpia_fl ) :
					?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin:0 6px 6px 0;">
						<input type="hidden" name="action" value="mpia_admin_action">
						<input type="hidden" name="mpia_task" value="export">
						<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_id ); ?>">
						<input type="hidden" name="version_id" value="<?php echo esc_attr( $mpia_sel_ver ); ?>">
						<input type="hidden" name="format" value="<?php echo esc_attr( $mpia_fmt ); ?>">
						<?php wp_nonce_field( 'mpia_admin_export', '_mpianonce' ); ?>
						<button type="submit" class="button"><?php echo esc_html( $mpia_fl ); ?></button>
					</form>
				<?php endforeach; ?>

				<h2><?php esc_html_e( 'Re-analyze', 'mayfair-implementation-assistant' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="mpia_admin_action">
					<input type="hidden" name="mpia_task" value="reanalyze">
					<input type="hidden" name="project_id" value="<?php echo esc_attr( $mpia_id ); ?>">
					<input type="hidden" name="version_id" value="<?php echo esc_attr( $mpia_sel_ver ); ?>">
					<?php wp_nonce_field( 'mpia_admin_reanalyze', '_mpianonce' ); ?>
					<button type="submit" class="button"><?php esc_html_e( 'Run analysis again', 'mayfair-implementation-assistant' ); ?></button>
					<p class="description"><?php esc_html_e( 'Useful after plugin updates improve the analyzer. Restores/regenerates the guide for this version.', 'mayfair-implementation-assistant' ); ?></p>
				</form>
			<?php endif; ?>

			<?php if ( $mpia_version ) : ?>
				<h2><?php esc_html_e( 'Imported Source (read-only)', 'mayfair-implementation-assistant' ); ?></h2>
				<textarea readonly rows="14" class="mpia-code" onclick="this.select();"><?php echo esc_textarea( (string) $mpia_version['content'] ); ?></textarea>
			<?php endif; ?>
		</div>
	</div>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpia-projects' ) ); ?>">&larr; <?php esc_html_e( 'Back to projects', 'mayfair-implementation-assistant' ); ?></a></p>
</div>
