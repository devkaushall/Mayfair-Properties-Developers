<?php
/**
 * Locked architecture reference screen (read-only).
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpia_stack  = MPIA_Profile::stack();
$mpia_fields = MPIA_Profile::acf_fields();
?>
<div class="wrap mpia-wrap">
	<h1><?php esc_html_e( 'Locked Architecture', 'mayfair-implementation-assistant' ); ?></h1>
	<p><?php esc_html_e( 'This is the authoritative reference the analyzer validates against. The plugin never modifies any of it.', 'mayfair-implementation-assistant' ); ?></p>

	<h2><?php esc_html_e( 'Stack', 'mayfair-implementation-assistant' ); ?></h2>
	<ul>
		<li><?php esc_html_e( 'Theme:', 'mayfair-implementation-assistant' ); ?> <strong><?php echo esc_html( $mpia_stack['theme'] ); ?></strong></li>
		<li><?php esc_html_e( 'Builder:', 'mayfair-implementation-assistant' ); ?> <strong><?php echo esc_html( $mpia_stack['builder'] ); ?></strong></li>
		<li>ACF: <strong><?php echo esc_html( $mpia_stack['acf'] ); ?></strong> (<?php esc_html_e( 'no Gallery / Repeater / Flexible Content / Clone', 'mayfair-implementation-assistant' ); ?>)</li>
		<li><?php esc_html_e( 'Mayfair plugins:', 'mayfair-implementation-assistant' ); ?> <?php echo esc_html( implode( ', ', $mpia_stack['plugins'] ) ); ?></li>
	</ul>

	<h2><?php esc_html_e( 'Custom Post Types', 'mayfair-implementation-assistant' ); ?></h2>
	<p><code>property</code> · <code>project</code> · <code>insight</code></p>

	<h2><?php esc_html_e( 'Taxonomies', 'mayfair-implementation-assistant' ); ?></h2>
	<p><code>property-type</code> (property) · <code>property-status</code> (property) · <code>location</code> (property + project, shared) · <code>project-type</code> (project) · <code>insight-topic</code> (insight)</p>

	<?php foreach ( $mpia_fields as $mpia_group => $mpia_list ) : ?>
		<h2><?php echo esc_html( ucfirst( $mpia_group ) ); ?> <?php esc_html_e( 'ACF Fields', 'mayfair-implementation-assistant' ); ?> (<?php echo esc_html( count( $mpia_list ) ); ?>)</h2>
		<p>
		<?php foreach ( $mpia_list as $mpia_f ) : ?>
			<code style="display:inline-block;margin:2px;"><?php echo esc_html( $mpia_f ); ?></code>
		<?php endforeach; ?>
		</p>
	<?php endforeach; ?>

	<p class="description"><?php esc_html_e( 'Any AI material referencing fields, taxonomies or post types outside these lists is flagged as a critical conflict.', 'mayfair-implementation-assistant' ); ?></p>
</div>
