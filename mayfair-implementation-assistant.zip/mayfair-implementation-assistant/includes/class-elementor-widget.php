<?php
/**
 * Elementor widget: Mayfair Implementation Reference.
 * Shows guide sections in the editor for the selected project.
 * Frontend visitors see nothing unless the user is an admin previewing.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class MPIA_Elementor_Widget extends Widget_Base {

	public function get_name() {
		return 'mayfair_impl_reference';
	}

	public function get_title() {
		return __( 'Mayfair Implementation Reference', 'mayfair-implementation-assistant' );
	}

	public function get_icon() {
		return 'eicon-checkbox';
	}

	public function get_categories() {
		return array( 'mayfair' );
	}

	private function project_options() {
		$options = array( 0 => __( '— Select project —', 'mayfair-implementation-assistant' ) );
		foreach ( MPIA_Projects::all() as $project ) {
			$options[ (int) $project['id'] ] = $project['name'];
		}
		return $options;
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_ref', array( 'label' => __( 'Reference', 'mayfair-implementation-assistant' ) ) );

		$this->add_control( 'project_id', array(
			'label'   => __( 'Project', 'mayfair-implementation-assistant' ),
			'type'    => Controls_Manager::SELECT,
			'options' => $this->project_options(),
			'default' => 0,
		) );

		$this->add_control( 'section', array(
			'label'   => __( 'Instruction Section', 'mayfair-implementation-assistant' ),
			'type'    => Controls_Manager::SELECT,
			'options' => array(
				'summary'   => __( 'Summary', 'mayfair-implementation-assistant' ),
				'steps'     => __( 'Implementation Steps', 'mayfair-implementation-assistant' ),
				'dynamic'   => __( 'Dynamic Mapping', 'mayfair-implementation-assistant' ),
				'conflicts' => __( 'Conflicts', 'mayfair-implementation-assistant' ),
				'qa'        => __( 'QA Checklist', 'mayfair-implementation-assistant' ),
			),
			'default' => 'steps',
		) );

		$this->add_control( 'note', array(
			'label' => '',
			'type'  => Controls_Manager::RAW_HTML,
			'raw'   => esc_html__( 'Editor/admin utility only: visitors without admin rights see nothing. Remove this widget before final launch.', 'mayfair-implementation-assistant' ),
		) );

		$this->end_controls_section();
	}

	protected function render() {
		// Utility widget: only render for users who can manage implementation
		// (covers editor preview); silent for normal visitors.
		if ( ! current_user_can( 'manage_mayfair_implementation' ) && ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$settings   = $this->get_settings_for_display();
		$project_id = (int) $settings['project_id'];
		if ( ! $project_id ) {
			echo '<div style="padding:12px;border:1px dashed #C4C7C7;font-size:13px;">' . esc_html__( 'Mayfair Implementation Reference: select a project in the widget settings.', 'mayfair-implementation-assistant' ) . '</div>';
			return;
		}
		$project = MPIA_Projects::get( $project_id );
		if ( ! $project ) {
			return;
		}
		$versions = MPIA_Projects::versions_for( $project_id );
		if ( empty( $versions ) ) {
			echo '<div style="padding:12px;border:1px dashed #C4C7C7;font-size:13px;">' . esc_html__( 'No imported versions in this project yet.', 'mayfair-implementation-assistant' ) . '</div>';
			return;
		}
		$bundle = MPIA_Projects::latest_analysis( (int) $versions[0]['id'] );
		if ( ! $bundle || empty( $bundle['guide'] ) ) {
			echo '<div style="padding:12px;border:1px dashed #C4C7C7;font-size:13px;">' . esc_html__( 'Run Analyze on the latest version first.', 'mayfair-implementation-assistant' ) . '</div>';
			return;
		}
		$guide = $bundle['guide'];

		echo '<div style="padding:16px;border:1px solid #E5E1D8;background:#F9F7F2;font-size:13px;line-height:1.6;">';
		echo '<strong style="display:block;margin-bottom:8px;">' . esc_html( $project['name'] ) . ' — ' . esc_html( ucfirst( $settings['section'] ) ) . '</strong>';

		switch ( $settings['section'] ) {
			case 'summary':
				echo '<p>' . esc_html( $guide['summary']['what_this_is'] ) . '</p>';
				echo '<p><strong>' . esc_html__( 'Where:', 'mayfair-implementation-assistant' ) . '</strong> ' . esc_html( $guide['summary']['where'] ) . '</p>';
				break;
			case 'dynamic':
				echo '<ul style="margin:0;padding-left:18px;">';
				foreach ( (array) $guide['dynamic_map'] as $row ) {
					echo '<li>[' . esc_html( $row['result'] ) . '] <code>' . esc_html( $row['reference'] ) . '</code> — ' . esc_html( $row['binding'] ) . '</li>';
				}
				echo '</ul>';
				break;
			case 'conflicts':
				echo '<ul style="margin:0;padding-left:18px;">';
				foreach ( (array) $bundle['conflicts'] as $c ) {
					echo '<li>[' . esc_html( strtoupper( $c['severity'] ) ) . '] ' . esc_html( $c['message'] ) . '</li>';
				}
				echo '</ul>';
				break;
			case 'qa':
				echo '<ul style="margin:0;padding-left:18px;list-style:none;">';
				foreach ( (array) $guide['qa_checklist'] as $item ) {
					echo '<li>&#9744; ' . esc_html( $item ) . '</li>';
				}
				echo '</ul>';
				break;
			default: // steps
				echo '<ol style="margin:0;padding-left:18px;">';
				foreach ( (array) $guide['steps'] as $step ) {
					echo '<li>' . esc_html( $step ) . '</li>';
				}
				echo '</ol>';
		}
		echo '</div>';
	}
}
