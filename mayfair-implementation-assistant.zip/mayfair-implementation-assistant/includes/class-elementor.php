<?php
/**
 * Optional Elementor widget: Mayfair Implementation Reference.
 * Editor-facing utility that shows a project's guide/steps while building.
 * Renders nothing meaningful for normal visitors.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Elementor {

	public static function init() {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widget' ) );
	}

	public static function register_category( $elements_manager ) {
		// Re-uses the 'mayfair' category if Mayfair Forms & Leads already registered it.
		$elements_manager->add_category( 'mayfair', array(
			'title' => __( 'Mayfair', 'mayfair-implementation-assistant' ),
			'icon'  => 'fa fa-building',
		) );
	}

	public static function register_widget( $widgets_manager ) {
		require_once MPIA_DIR . 'includes/class-elementor-widget.php';
		$widgets_manager->register( new MPIA_Elementor_Widget() );
	}
}
