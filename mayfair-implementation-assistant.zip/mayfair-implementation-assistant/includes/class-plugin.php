<?php
/**
 * Orchestrator: admin menu, pages, action dispatcher (nonce+cap checked).
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		if ( did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ) ) {
			MPIA_Elementor::init();
		} else {
			add_action( 'elementor/loaded', array( 'MPIA_Elementor', 'init' ) );
		}

		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'admin_menu' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
			add_action( 'admin_post_mpia_admin_action', array( $this, 'handle_admin_action' ) );
		}

		if ( get_option( 'mpia_db_version' ) !== MPIA_DB_VERSION ) {
			MPIA_Database::create_tables();
			update_option( 'mpia_db_version', MPIA_DB_VERSION );
		}
	}

	public function admin_menu() {
		add_menu_page(
			__( 'Mayfair Implementation', 'mayfair-implementation-assistant' ),
			__( 'Mayfair Implementation', 'mayfair-implementation-assistant' ),
			'manage_mayfair_implementation',
			'mpia-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-hammer',
			27
		);
		add_submenu_page( 'mpia-dashboard', __( 'Dashboard', 'mayfair-implementation-assistant' ), __( 'Dashboard', 'mayfair-implementation-assistant' ), 'manage_mayfair_implementation', 'mpia-dashboard', array( $this, 'render_dashboard' ) );
		add_submenu_page( 'mpia-dashboard', __( 'Projects', 'mayfair-implementation-assistant' ), __( 'Projects', 'mayfair-implementation-assistant' ), 'manage_mayfair_implementation', 'mpia-projects', array( $this, 'render_projects' ) );
		add_submenu_page( 'mpia-dashboard', __( 'Design System', 'mayfair-implementation-assistant' ), __( 'Design System', 'mayfair-implementation-assistant' ), 'manage_mayfair_implementation', 'mpia-design', array( $this, 'render_design' ) );
		add_submenu_page( 'mpia-dashboard', __( 'Architecture', 'mayfair-implementation-assistant' ), __( 'Architecture', 'mayfair-implementation-assistant' ), 'manage_mayfair_implementation', 'mpia-architecture', array( $this, 'render_architecture' ) );
	}

	public function admin_assets( $hook ) {
		if ( false === strpos( $hook, 'mpia-' ) ) {
			return;
		}
		wp_enqueue_style( 'mpia-admin', MPIA_URL . 'admin/assets/mpia-admin.css', array(), MPIA_VERSION );
	}

	public function render_dashboard() {
		$this->cap();
		require MPIA_DIR . 'admin/views/dashboard.php';
	}

	public function render_projects() {
		$this->cap();
		$view = isset( $_GET['project'] ) ? (int) $_GET['project'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing
		if ( $view ) {
			require MPIA_DIR . 'admin/views/project-detail.php';
		} else {
			require MPIA_DIR . 'admin/views/projects.php';
		}
	}

	public function render_design() {
		$this->cap();
		require MPIA_DIR . 'admin/views/design-system.php';
	}

	public function render_architecture() {
		$this->cap();
		require MPIA_DIR . 'admin/views/architecture.php';
	}

	private function cap() {
		if ( ! current_user_can( 'manage_mayfair_implementation' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-implementation-assistant' ) );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Actions                                                            */
	/* ------------------------------------------------------------------ */

	public function handle_admin_action() {
		$this->cap();
		$task = isset( $_POST['mpia_task'] ) ? sanitize_key( wp_unslash( $_POST['mpia_task'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified next line
		check_admin_referer( 'mpia_admin_' . $task, '_mpianonce' );

		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=mpia-projects' );

		switch ( $task ) {

			case 'create_project':
				$id = MPIA_Projects::create(
					isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
					isset( $_POST['project_type'] ) ? sanitize_key( wp_unslash( $_POST['project_type'] ) ) : 'custom',
					isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : ''
				);
				$this->finish( admin_url( 'admin.php?page=mpia-projects&project=' . (int) $id ), __( 'Project created.', 'mayfair-implementation-assistant' ) );
				break;

			case 'set_project_status':
				MPIA_Projects::set_status(
					isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0,
					isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : ''
				);
				$this->finish( $redirect, __( 'Status updated.', 'mayfair-implementation-assistant' ) );
				break;

			case 'delete_project':
				MPIA_Projects::delete( isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0 );
				$this->finish( admin_url( 'admin.php?page=mpia-projects' ), __( 'Project deleted.', 'mayfair-implementation-assistant' ) );
				break;

			case 'paste_content':
				$project_id = isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0;
				// Content is stored as inert data: unslash but do NOT strip — analysis needs it verbatim. Never executed; escaped on output.
				$content = isset( $_POST['content'] ) ? wp_unslash( $_POST['content'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- stored as data, refused if PHP, escaped on every output
				if ( MPIA_Uploads::looks_like_php( $content ) ) {
					$this->finish( $redirect, __( 'Content contains PHP code and was refused.', 'mayfair-implementation-assistant' ) );
				}
				if ( strlen( $content ) > MPIA_Uploads::MAX_FILE_BYTES ) {
					$this->finish( $redirect, __( 'Content exceeds the 2 MB limit.', 'mayfair-implementation-assistant' ) );
				}
				$type       = MPIA_Analyzer::detect_type( $content );
				$version_id = MPIA_Projects::add_version( $project_id, $content, $type, 'paste' );
				if ( ! is_wp_error( $version_id ) ) {
					MPIA_Projects::run_analysis( $project_id, $version_id );
				}
				$this->finish( $redirect, is_wp_error( $version_id ) ? $version_id->get_error_message() : sprintf( /* translators: %s type */ __( 'Content imported as %s and analyzed.', 'mayfair-implementation-assistant' ), strtoupper( $type ) ) );
				break;

			case 'upload_file':
				$project_id = isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0;
				if ( empty( $_FILES['import_file'] ) ) {
					$this->finish( $redirect, __( 'No file received.', 'mayfair-implementation-assistant' ) );
				}
				$result = MPIA_Uploads::handle_text_upload( array_map( 'wp_unslash', $_FILES['import_file'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated inside handler
				if ( is_wp_error( $result ) ) {
					$this->finish( $redirect, $result->get_error_message() );
				}
				$source     = ( 'zip' === strtolower( pathinfo( $result['filename'], PATHINFO_EXTENSION ) ) ) ? 'zip' : 'file';
				$version_id = MPIA_Projects::add_version( $project_id, $result['content'], $result['type'], $source, $result['filename'] );
				if ( ! is_wp_error( $version_id ) ) {
					MPIA_Projects::run_analysis( $project_id, $version_id );
				}
				$this->finish( $redirect, sprintf( /* translators: %s type */ __( 'File imported as %s and analyzed.', 'mayfair-implementation-assistant' ), strtoupper( $result['type'] ) ) );
				break;

			case 'reanalyze':
				$project_id = isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0;
				$version_id = isset( $_POST['version_id'] ) ? (int) $_POST['version_id'] : 0;
				MPIA_Projects::run_analysis( $project_id, $version_id );
				$this->finish( $redirect, __( 'Analysis regenerated.', 'mayfair-implementation-assistant' ) );
				break;

			case 'set_step_status':
				MPIA_Projects::set_step_status(
					isset( $_POST['step_id'] ) ? (int) $_POST['step_id'] : 0,
					isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : ''
				);
				$this->finish( $redirect, __( 'Step updated.', 'mayfair-implementation-assistant' ) );
				break;

			case 'export':
				$this->handle_export();
				break;

			default:
				wp_die( esc_html__( 'Unknown action.', 'mayfair-implementation-assistant' ) );
		}
	}

	private function handle_export() {
		$format     = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'txt'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in dispatcher
		$project_id = isset( $_POST['project_id'] ) ? (int) $_POST['project_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$version_id = isset( $_POST['version_id'] ) ? (int) $_POST['version_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$project = MPIA_Projects::get( $project_id );
		$version = MPIA_Projects::get_version( $version_id );
		$bundle  = $version ? MPIA_Projects::latest_analysis( $version_id ) : null;
		if ( ! $project || ! $version || ! $bundle ) {
			wp_die( esc_html__( 'Nothing to export — run analysis first.', 'mayfair-implementation-assistant' ) );
		}
		$base = sanitize_file_name( sanitize_title( $project['name'] ) . '-guide-v' . $version['version_number'] );

		switch ( $format ) {
			case 'pdf':
				MPIA_Exports::stream( MPIA_Exports::guide_pdf( $project, $version, $bundle ), $base . '.pdf', 'application/pdf' );
				break;
			case 'md':
				MPIA_Exports::stream( MPIA_Exports::guide_markdown( $project, $version, $bundle ), $base . '.md', 'text/markdown; charset=utf-8' );
				break;
			case 'json':
				MPIA_Exports::stream( MPIA_Exports::guide_json( $project, $version, $bundle ), $base . '.json', 'application/json; charset=utf-8' );
				break;
			case 'css':
				MPIA_Exports::stream( MPIA_Exports::css_file( $version ), $base . '.css', 'text/css; charset=utf-8' );
				break;
			case 'html':
				MPIA_Exports::stream( MPIA_Exports::html_reference( $version ), $base . '-reference.html.txt', 'text/plain; charset=utf-8' );
				break;
			case 'zip':
				$zip = MPIA_Exports::project_zip( $project, $version, $bundle );
				if ( is_wp_error( $zip ) ) {
					$this->finish( wp_get_referer(), $zip->get_error_message() );
				}
				MPIA_Exports::stream( $zip, $base . '-package.zip', 'application/zip' );
				break;
			case 'txt':
			default:
				MPIA_Exports::stream( MPIA_Exports::guide_text( $project, $version, $bundle ), $base . '.txt', 'text/plain; charset=utf-8' );
		}
	}

	private function finish( $redirect, $message ) {
		wp_safe_redirect( add_query_arg( 'mpia_notice', rawurlencode( $message ), $redirect ) );
		exit;
	}
}
