<?php
/**
 * The LOCKED Mayfair implementation profile: architecture + design system.
 * This is the single source of truth every analysis is validated against.
 * Nothing in this class writes anything anywhere.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Profile {

	/** Stack. */
	public static function stack() {
		return array(
			'theme'   => 'Hello Elementor',
			'builder' => 'Elementor Pro',
			'acf'     => 'ACF Free',
			'plugins' => array( 'Mayfair Properties & Developers Core', 'Mayfair Forms & Leads' ),
		);
	}

	/** Locked CPTs. */
	public static function cpts() {
		return array( 'property', 'project', 'insight' );
	}

	/** Locked taxonomies. */
	public static function taxonomies() {
		return array( 'property-type', 'property-status', 'location', 'project-type', 'insight-topic' );
	}

	/** Locked ACF fields, grouped. */
	public static function acf_fields() {
		return array(
			'property' => array(
				'mpd_property_id', 'mpd_price', 'mpd_price_label', 'mpd_area_sqft',
				'mpd_bedrooms', 'mpd_bathrooms', 'mpd_floor_level', 'mpd_furnishing',
				'mpd_possession_status', 'mpd_locality', 'mpd_latitude', 'mpd_longitude',
				'mpd_floor_plan', 'mpd_brochure', 'mpd_video_url', 'mpd_featured', 'mpd_verified',
			),
			'project'  => array(
				'mpd_developer_name', 'mpd_possession_date', 'mpd_min_price', 'mpd_max_price',
				'mpd_rera_number', 'mpd_project_brochure', 'mpd_latitude', 'mpd_longitude', 'mpd_featured',
			),
			'insight'  => array(
				'mpi_subtitle', 'mpi_reading_time', 'mpi_author_name', 'mpi_author_image',
				'mpi_featured', 'mpi_source_url', 'mpi_source_name', 'mpi_cta_text', 'mpi_cta_url',
			),
		);
	}

	/** Flat list of every known field. */
	public static function all_fields() {
		$all = array();
		foreach ( self::acf_fields() as $fields ) {
			$all = array_merge( $all, $fields );
		}
		return array_values( array_unique( $all ) );
	}

	/** ACF Pro-only field types — always conflicts. */
	public static function acf_pro_types() {
		return array( 'gallery', 'repeater', 'flexible_content', 'flexible content', 'clone' );
	}

	/** Locked Mayfair Heritage design tokens. */
	public static function design_tokens() {
		return array(
			'primary'         => '#1A1A1A',
			'secondary'       => '#725B2F',
			'accent'          => '#A68B5B',
			'background'      => '#F9F7F2',
			'surface'         => '#FFFFFF',
			'cream'           => '#F5F0E7',
			'surface_soft'    => '#F7F3EA',
			'surface_mid'     => '#F2EDE4',
			'surface_high'    => '#ECE8DF',
			'surface_highest' => '#E6E2D9',
			'border'          => '#E5E1D8',
			'border_strong'   => '#C4C7C7',
			'bronze_light'    => '#FFDEA7',
			'muted_text'      => '#444748',
		);
	}

	/** Approved hexes (uppercase, incl. common short forms). */
	public static function approved_hexes() {
		$hexes = array_map( 'strtoupper', array_values( self::design_tokens() ) );
		$hexes[] = '#FFF';
		$hexes[] = '#000000'; // pure black tolerated as informational
		return $hexes;
	}

	/** Locked typography. */
	public static function fonts() {
		return array( 'Playfair Display', 'Inter' );
	}

	/** Font families tolerated as generic fallbacks (not conflicts). */
	public static function fallback_fonts() {
		return array( 'georgia', 'serif', 'sans-serif', 'monospace', 'arial', 'helvetica', 'inherit', 'system-ui', '-apple-system' );
	}

	/** Shape rules. */
	public static function shape() {
		return array(
			'radius_min'   => 0,
			'radius_max'   => 4,
			'image_radius' => 2,
			'language'     => 'Architectural Sharp',
			'motion'       => 'subtle',
		);
	}

	/** Widgets available in the stack (Elementor + Pro core set, lowercase). */
	public static function known_widgets() {
		return array(
			'container', 'heading', 'text editor', 'image', 'button', 'icon', 'icon list',
			'video', 'divider', 'spacer', 'google maps', 'html', 'shortcode',
			'post title', 'post content', 'post excerpt', 'featured image', 'post info',
			'form', 'loop grid', 'loop item', 'posts', 'archive title', 'archive posts',
			'nav menu', 'search form', 'breadcrumbs', 'taxonomy filter', 'mayfair form',
		);
	}

	/** Project types offered in the UI. */
	public static function project_types() {
		return array(
			'homepage'         => 'Mayfair Homepage',
			'single_property'  => 'Mayfair Single Property',
			'property_archive' => 'Mayfair Property Archive',
			'single_project'   => 'Mayfair Single Project',
			'project_archive'  => 'Mayfair Project Archive',
			'insight_archive'  => 'Mayfair Insight Archive',
			'single_insight'   => 'Mayfair Single Insight',
			'header'           => 'Mayfair Header',
			'footer'           => 'Mayfair Footer',
			'forms'            => 'Mayfair Forms',
			'global_css'       => 'Mayfair Global CSS',
			'custom'           => 'Custom Component',
		);
	}

	/** Project statuses. */
	public static function project_statuses() {
		return array(
			'draft'        => 'Draft',
			'analyzing'    => 'Analyzing',
			'ready'        => 'Ready',
			'implemented'  => 'Implemented',
			'needs_review' => 'Needs Review',
			'archived'     => 'Archived',
		);
	}

	/** Per-step implementation statuses. */
	public static function step_statuses() {
		return array(
			'not_started' => 'Not Started',
			'in_progress' => 'In Progress',
			'implemented' => 'Implemented',
			'verified'    => 'Verified',
			'needs_fix'   => 'Needs Fix',
		);
	}

	/** Where each project type is implemented (used by the guide generator). */
	public static function implementation_location( $project_type ) {
		$map = array(
			'homepage'         => array( 'Pages → your Homepage → Edit with Elementor', 'Elementor editor' ),
			'single_property'  => array( 'Templates → Theme Builder → Single Post → condition: Property', 'Theme Builder' ),
			'property_archive' => array( 'Templates → Theme Builder → Archive → condition: Property Archive', 'Theme Builder' ),
			'single_project'   => array( 'Templates → Theme Builder → Single Post → condition: Project', 'Theme Builder' ),
			'project_archive'  => array( 'Templates → Theme Builder → Archive → condition: Project Archive', 'Theme Builder' ),
			'insight_archive'  => array( 'Templates → Theme Builder → Archive → condition: Insight Archive', 'Theme Builder' ),
			'single_insight'   => array( 'Templates → Theme Builder → Single Post → condition: Insight', 'Theme Builder' ),
			'header'           => array( 'Templates → Theme Builder → Header', 'Theme Builder' ),
			'footer'           => array( 'Templates → Theme Builder → Footer', 'Theme Builder' ),
			'forms'            => array( 'Mayfair Forms → Forms (builder) + Mayfair Form widget for placement', 'Mayfair Forms & Leads' ),
			'global_css'       => array( 'Elementor → Site Settings → Custom CSS', 'Site Settings' ),
			'custom'           => array( 'Depends on component — see generated steps', 'Elementor editor' ),
		);
		return isset( $map[ $project_type ] ) ? $map[ $project_type ] : $map['custom'];
	}
}
