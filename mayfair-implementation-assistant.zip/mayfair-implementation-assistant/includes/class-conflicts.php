<?php
/**
 * Conflict detector: validates an analysis result against the locked
 * Mayfair profile. Pure logic — flags, never overwrites.
 *
 * Severities: critical | high | medium | low | info
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Conflicts {

	/**
	 * Run all conflict checks against an analysis array (from MPIA_Analyzer::analyze).
	 *
	 * @return array[] each: { severity, category, found, expected, message, recommendation }
	 */
	public static function detect( $analysis, $raw_content = '' ) {
		return array_merge(
			self::check_colors( $analysis ),
			self::check_fonts( $analysis ),
			self::check_acf_fields( $analysis ),
			self::check_taxonomies( $analysis ),
			self::check_cpts( $analysis ),
			self::check_acf_pro( $raw_content ),
			self::check_radius( $analysis ),
			self::check_js( $analysis ),
			self::check_widgets( $raw_content ),
			self::check_plugins( $raw_content ),
			self::check_invented_data( $raw_content )
		);
	}

	private static function conflict( $severity, $category, $found, $expected, $message, $recommendation ) {
		return compact( 'severity', 'category', 'found', 'expected', 'message', 'recommendation' );
	}

	/** DESIGN SYSTEM CONFLICT: colors not in the locked palette. */
	public static function check_colors( $analysis ) {
		$out      = array();
		$approved = MPIA_Profile::approved_hexes();
		$tokens   = MPIA_Profile::design_tokens();

		foreach ( (array) $analysis['colors'] as $hex ) {
			if ( in_array( strtoupper( $hex ), $approved, true ) ) {
				continue;
			}
			$nearest = self::nearest_token( $hex, $tokens );
			$out[]   = self::conflict(
				'high',
				'DESIGN SYSTEM CONFLICT',
				$hex,
				$nearest['hex'] . ' (' . $nearest['name'] . ')',
				sprintf( 'Color %s is not part of the locked Mayfair Heritage palette.', $hex ),
				sprintf( 'Replace imported token %s with locked Mayfair token %s (%s). Do not carry foreign colors into the site.', $hex, $nearest['hex'], $nearest['name'] )
			);
		}
		return $out;
	}

	/** Nearest locked token by RGB distance — recommendation only, never auto-applied. */
	public static function nearest_token( $hex, $tokens ) {
		$rgb  = self::hex_to_rgb( $hex );
		$best = array( 'name' => 'primary', 'hex' => '#1A1A1A', 'dist' => PHP_INT_MAX );
		foreach ( $tokens as $name => $thex ) {
			$trgb = self::hex_to_rgb( $thex );
			$dist = pow( $rgb[0] - $trgb[0], 2 ) + pow( $rgb[1] - $trgb[1], 2 ) + pow( $rgb[2] - $trgb[2], 2 );
			if ( $dist < $best['dist'] ) {
				$best = array( 'name' => $name, 'hex' => strtoupper( $thex ), 'dist' => $dist );
			}
		}
		return $best;
	}

	private static function hex_to_rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
	}

	public static function check_fonts( $analysis ) {
		$out      = array();
		$locked   = array_map( 'strtolower', MPIA_Profile::fonts() );
		$fallback = MPIA_Profile::fallback_fonts();
		foreach ( (array) $analysis['fonts'] as $font ) {
			$lf = strtolower( $font );
			if ( in_array( $lf, $locked, true ) || in_array( $lf, $fallback, true ) ) {
				continue;
			}
			$out[] = self::conflict(
				'high',
				'DESIGN SYSTEM CONFLICT',
				$font,
				'Playfair Display (headings) / Inter (body & UI)',
				sprintf( 'Font "%s" is not part of the locked Mayfair typography.', $font ),
				sprintf( 'Replace "%s" with Playfair Display for headings or Inter for body/UI text.', $font )
			);
		}
		return $out;
	}

	public static function check_acf_fields( $analysis ) {
		$out   = array();
		$known = MPIA_Profile::all_fields();
		foreach ( (array) $analysis['acf_refs'] as $ref ) {
			if ( in_array( $ref, $known, true ) ) {
				continue;
			}
			$out[] = self::conflict(
				'critical',
				'INVENTED FIELD',
				$ref,
				'the 35 locked Mayfair ACF fields',
				sprintf( 'Field "%s" does not exist in the Mayfair ACF architecture.', $ref ),
				'Remove this binding or map it to a real field. NEVER create new ACF fields to satisfy imported material — the data model is locked.'
			);
		}
		return $out;
	}

	public static function check_taxonomies( $analysis ) {
		$out = array();
		foreach ( (array) $analysis['taxonomy_refs'] as $ref ) {
			if ( 0 === strpos( $ref, 'unknown:' ) ) {
				$slug  = substr( $ref, 8 );
				$out[] = self::conflict(
					'critical',
					'WRONG TAXONOMY',
					$slug,
					implode( ', ', MPIA_Profile::taxonomies() ),
					sprintf( 'Taxonomy "%s" does not exist on this site.', $slug ),
					'Map to one of the five locked taxonomies or drop the reference. Do not register new taxonomies.'
				);
			}
		}
		return $out;
	}

	public static function check_cpts( $analysis ) {
		$out = array();
		foreach ( (array) $analysis['cpt_refs'] as $ref ) {
			if ( 0 === strpos( $ref, 'unknown:' ) ) {
				$slug  = substr( $ref, 8 );
				$out[] = self::conflict(
					'critical',
					'WRONG CPT',
					$slug,
					'property, project, insight',
					sprintf( 'Post type "%s" does not exist on this site.', $slug ),
					'Use property, project or insight. Do not register new post types.'
				);
			}
		}
		return $out;
	}

	public static function check_acf_pro( $content ) {
		$out      = array();
		$flat     = strtolower( (string) $content );
		$hits     = array(
			'repeater'           => 'Repeater',
			'flexible_content'   => 'Flexible Content',
			'flexible content'   => 'Flexible Content',
			'acf gallery'        => 'Gallery',
			'gallery field'      => 'Gallery',
			'clone field'        => 'Clone',
			'"type": "gallery"'  => 'Gallery',
			'"type": "repeater"' => 'Repeater',
			'"type": "clone"'    => 'Clone',
		);
		$reported = array();
		foreach ( $hits as $needle => $label ) {
			if ( false !== strpos( $flat, $needle ) && ! isset( $reported[ $label ] ) ) {
				$reported[ $label ] = true;
				$out[]              = self::conflict(
					'critical',
					'ACF PRO FEATURE',
					$label,
					'ACF Free field types only',
					sprintf( 'Imported material relies on the ACF Pro-only "%s" feature.', $label ),
					'Redesign around ACF Free: native WordPress galleries in post content, individual fields instead of repeaters, separate field groups instead of clones.'
				);
			}
		}
		return $out;
	}

	public static function check_radius( $analysis ) {
		$out   = array();
		$shape = MPIA_Profile::shape();
		foreach ( (array) $analysis['radius_values'] as $radius ) {
			if ( preg_match_all( '/(\d+(?:\.\d+)?)(px|rem|em|%)/', $radius, $m, PREG_SET_ORDER ) ) {
				foreach ( $m as $val ) {
					$px = ( 'px' === $val[2] ) ? (float) $val[1] : ( ( '%' === $val[2] ) ? 999 : (float) $val[1] * 16 );
					if ( $px > $shape['radius_max'] && $px < 990 ) {
						$out[] = self::conflict(
							'medium',
							'SHAPE CONFLICT',
							$radius,
							'0-4px (Architectural Sharp)',
							sprintf( 'Border radius "%s" exceeds the locked 2-4px shape language.', $radius ),
							'Reduce to 2-4px for cards/buttons, 0-2px for images. Rounded/pill shapes are off-brand.'
						);
						break;
					}
					if ( $px >= 990 ) {
						$out[] = self::conflict(
							'medium',
							'SHAPE CONFLICT',
							$radius,
							'0-4px (Architectural Sharp)',
							'Percentage/pill radius conflicts with the Architectural Sharp shape language.',
							'Replace pill radii with 2-4px.'
						);
						break;
					}
				}
			}
		}
		return $out;
	}

	public static function check_js( $analysis ) {
		if ( empty( $analysis['has_js'] ) ) {
			return array();
		}
		return array( self::conflict(
			'high',
			'JAVASCRIPT REQUIREMENT',
			'Custom JavaScript detected',
			'Stock Elementor/plugin behaviour (no custom JS)',
			'The imported material includes or requires custom JavaScript.',
			'Prefer native Elementor behaviour. If the interaction is essential, isolate the minimal JS, review it manually, and add it deliberately — never paste unreviewed AI JavaScript into the site.'
		) );
	}

	public static function check_widgets( $content ) {
		$out         = array();
		$flat        = strtolower( (string) $content );
		$unsupported = array(
			'slider revolution' => 'Slider Revolution (not installed)',
			'wpbakery'          => 'WPBakery (different builder)',
			'divi'              => 'Divi (different builder)',
			'jetengine'         => 'JetEngine (not installed, paid)',
			'crocoblock'        => 'Crocoblock (not installed, paid)',
			'acf pro'           => 'ACF Pro (not installed by policy)',
		);
		foreach ( $unsupported as $needle => $label ) {
			if ( false !== strpos( $flat, $needle ) ) {
				$out[] = self::conflict(
					'high',
					'UNSUPPORTED DEPENDENCY',
					$label,
					'Hello Elementor + Elementor Pro + ACF Free + Mayfair plugins',
					sprintf( 'Imported material references %s, which is not part of the locked stack.', $label ),
					'Re-express the requirement with stock Elementor Pro widgets or the Mayfair plugins. Do not install new page builders or paid addons.'
				);
			}
		}
		return $out;
	}

	public static function check_plugins( $content ) {
		$out  = array();
		$flat = strtolower( (string) $content );
		foreach ( array( 'contact form 7', 'wpforms', 'gravity forms', 'ninja forms' ) as $form_plugin ) {
			if ( false !== strpos( $flat, $form_plugin ) ) {
				$out[] = self::conflict(
					'medium',
					'UNSUPPORTED DEPENDENCY',
					ucwords( $form_plugin ),
					'Mayfair Forms & Leads',
					sprintf( 'Material references %s for forms.', ucwords( $form_plugin ) ),
					'Use the Mayfair Forms & Leads plugin (Mayfair Form widget / [mayfair_form] shortcode) instead — it owns lead capture on this site.'
				);
			}
		}
		return $out;
	}

	/** Invented business data heuristics — flags, human decides. */
	public static function check_invented_data( $content ) {
		$out      = array();
		$flat     = strtolower( (string) $content );
		$suspects = array(
			'amenities'          => 'No structured amenities field exists (editor-authored content only).',
			'carpet area'        => 'No carpet-area field exists (only mpd_area_sqft).',
			'parking'            => 'No parking field exists.',
			'maintenance charge' => 'No maintenance field exists.',
			'testimonial'        => 'No testimonial data structure exists - do not fabricate reviews.',
			'rating'             => 'No rating system exists - do not fabricate ratings/stars.',
		);
		foreach ( $suspects as $needle => $why ) {
			if ( false !== strpos( $flat, $needle ) ) {
				$out[] = self::conflict(
					'medium',
					'POSSIBLY INVENTED DATA',
					$needle,
					'Locked ACF fields + native WP data only',
					sprintf( 'Material mentions "%s" - %s', $needle, $why ),
					'If the design shows this data, either remove that section or source it from real editor-authored content. Never display fabricated business data.'
				);
			}
		}
		return $out;
	}

	/** Summarise counts by severity. */
	public static function summary( $conflicts ) {
		$sum = array( 'critical' => 0, 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0 );
		foreach ( $conflicts as $c ) {
			if ( isset( $sum[ $c['severity'] ] ) ) {
				$sum[ $c['severity'] ]++;
			}
		}
		return $sum;
	}
}
