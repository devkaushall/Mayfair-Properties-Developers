<?php
/**
 * Safe upload handling: text file types + ZIP inspection.
 * Uploaded content is ALWAYS treated as inert data — never executed,
 * never written to executable locations, never included.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Uploads {

	const MAX_FILE_BYTES  = 2097152;  // 2 MB per text file
	const MAX_ZIP_BYTES   = 10485760; // 10 MB archive
	const MAX_ZIP_ENTRIES = 50;
	const MAX_ENTRY_BYTES = 1048576;  // 1 MB per extracted entry (read into memory only)

	/** Allowed text upload extensions => canonical type. */
	public static function allowed_extensions() {
		return array(
			'css'      => 'css',
			'html'     => 'html',
			'htm'      => 'html',
			'json'     => 'json',
			'md'       => 'markdown',
			'markdown' => 'markdown',
			'txt'      => 'text',
			'xml'      => 'xml',
		);
	}

	/**
	 * Process an uploaded text file: validate, read content into memory.
	 * The temp file is never moved anywhere web-accessible or executable.
	 *
	 * @return array|WP_Error { content, type, filename }
	 */
	public static function handle_text_upload( $file ) {
		if ( empty( $file['name'] ) || empty( $file['tmp_name'] ) ) {
			return new WP_Error( 'mpia_upload', __( 'No file received.', 'mayfair-implementation-assistant' ) );
		}
		if ( ! empty( $file['error'] ) ) {
			return new WP_Error( 'mpia_upload', __( 'Upload failed. Try again.', 'mayfair-implementation-assistant' ) );
		}
		if ( (int) $file['size'] > self::MAX_FILE_BYTES ) {
			return new WP_Error( 'mpia_upload_size', __( 'File exceeds the 2 MB limit for text inputs.', 'mayfair-implementation-assistant' ) );
		}

		$filename = sanitize_file_name( $file['name'] );
		$ext      = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		$allowed  = self::allowed_extensions();

		if ( 'zip' === $ext ) {
			return self::handle_zip_upload( $file );
		}
		if ( ! isset( $allowed[ $ext ] ) ) {
			return new WP_Error( 'mpia_upload_type', __( 'File type not allowed. Allowed: CSS, HTML, JSON, MD, TXT, XML, ZIP.', 'mayfair-implementation-assistant' ) );
		}

		// Reject anything that smells like PHP regardless of extension.
		$content = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local tmp upload
		if ( false === $content ) {
			return new WP_Error( 'mpia_upload_read', __( 'Could not read the uploaded file.', 'mayfair-implementation-assistant' ) );
		}
		if ( self::looks_like_php( $content ) ) {
			return new WP_Error( 'mpia_upload_php', __( 'File contains PHP code. PHP uploads are refused — this tool never stores or executes code files.', 'mayfair-implementation-assistant' ) );
		}
		if ( ! self::is_textual( $content ) ) {
			return new WP_Error( 'mpia_upload_binary', __( 'File appears to be binary. Only text-based files are analyzable.', 'mayfair-implementation-assistant' ) );
		}

		return array(
			'content'  => $content,
			'type'     => MPIA_Analyzer::detect_type( $content, $filename ),
			'filename' => $filename,
		);
	}

	/**
	 * Inspect a ZIP safely:
	 * - open read-only via ZipArchive, never extract to disk
	 * - entry count / size caps, zip-bomb ratio guard
	 * - path traversal entries skipped
	 * - PHP/JS/binary entries listed but their content NOT imported
	 * - allowed text entries concatenated (annotated) into one analyzable body
	 *
	 * @return array|WP_Error { content, type, filename, manifest }
	 */
	public static function handle_zip_upload( $file ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'mpia_zip', __( 'ZIP inspection requires the PHP zip extension. Upload individual text files instead.', 'mayfair-implementation-assistant' ) );
		}
		if ( (int) $file['size'] > self::MAX_ZIP_BYTES ) {
			return new WP_Error( 'mpia_zip_size', __( 'ZIP exceeds the 10 MB inspection limit.', 'mayfair-implementation-assistant' ) );
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $file['tmp_name'] ) ) {
			return new WP_Error( 'mpia_zip_open', __( 'Could not open the ZIP archive.', 'mayfair-implementation-assistant' ) );
		}
		if ( $zip->numFiles > self::MAX_ZIP_ENTRIES ) {
			$zip->close();
			return new WP_Error( 'mpia_zip_entries', __( 'ZIP has too many entries (max 50).', 'mayfair-implementation-assistant' ) );
		}

		$allowed  = self::allowed_extensions();
		$manifest = array();
		$bodies   = array();

		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			if ( false === $stat ) {
				continue;
			}
			$name = $stat['name'];

			// Path traversal / absolute path guard.
			if ( false !== strpos( $name, '..' ) || 0 === strpos( $name, '/' ) || preg_match( '/^[a-zA-Z]:/', $name ) ) {
				$manifest[] = array( 'name' => $name, 'status' => 'SKIPPED — unsafe path' );
				continue;
			}
			if ( '/' === substr( $name, -1 ) ) {
				continue; // directory entry
			}
			// Zip-bomb guard: uncompressed size cap + ratio check.
			if ( $stat['size'] > self::MAX_ENTRY_BYTES ) {
				$manifest[] = array( 'name' => $name, 'status' => 'SKIPPED — too large to inspect' );
				continue;
			}
			if ( $stat['comp_size'] > 0 && ( $stat['size'] / max( 1, $stat['comp_size'] ) ) > 200 ) {
				$manifest[] = array( 'name' => $name, 'status' => 'SKIPPED — suspicious compression ratio' );
				continue;
			}

			$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			if ( in_array( $ext, array( 'php', 'phtml', 'php3', 'php4', 'php5', 'phar' ), true ) ) {
				$manifest[] = array( 'name' => $name, 'status' => 'LISTED ONLY — PHP is never imported or executed' );
				continue;
			}
			if ( 'js' === $ext ) {
				$manifest[] = array( 'name' => $name, 'status' => 'LISTED ONLY — JavaScript is flagged, not imported' );
				continue;
			}
			if ( ! isset( $allowed[ $ext ] ) ) {
				$manifest[] = array( 'name' => $name, 'status' => 'LISTED ONLY — non-text type' );
				continue;
			}

			$content = $zip->getFromIndex( $i, self::MAX_ENTRY_BYTES );
			if ( false === $content || self::looks_like_php( $content ) || ! self::is_textual( $content ) ) {
				$manifest[] = array( 'name' => $name, 'status' => 'SKIPPED — unreadable, binary, or contains PHP' );
				continue;
			}
			$manifest[] = array( 'name' => $name, 'status' => 'IMPORTED for analysis' );
			$bodies[]   = "/* ===== FILE: " . $name . " ===== */\n" . $content;
		}
		$zip->close();

		if ( empty( $bodies ) ) {
			return new WP_Error( 'mpia_zip_empty', __( 'No analyzable text files found in the ZIP. See the manifest for what was skipped.', 'mayfair-implementation-assistant' ) );
		}

		$combined = implode( "\n\n", $bodies );
		return array(
			'content'  => $combined,
			'type'     => MPIA_Analyzer::detect_type( $combined, '' ),
			'filename' => sanitize_file_name( $file['name'] ),
			'manifest' => $manifest,
		);
	}

	/** PHP sniff: opening tags anywhere in content. */
	public static function looks_like_php( $content ) {
		return (bool) preg_match( '/<\?php|<\?=|<\?\s/i', (string) $content );
	}

	/** Textual heuristic: no NUL bytes, mostly printable. */
	public static function is_textual( $content ) {
		if ( false !== strpos( (string) $content, "\0" ) ) {
			return false;
		}
		$sample = substr( (string) $content, 0, 4096 );
		if ( '' === $sample ) {
			return true;
		}
		$printable = preg_match_all( '/[\x20-\x7E\x09\x0A\x0D\x80-\xFF]/', $sample );
		return ( $printable / strlen( $sample ) ) > 0.9;
	}
}
