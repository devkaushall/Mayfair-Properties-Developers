<?php
/**
 * Implementation guide generator: turns an analysis + conflicts into
 * "what this is / where to implement / exact click-by-click steps",
 * plus responsive guidance and a QA checklist.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Guide {

	/**
	 * Build the full guide structure.
	 *
	 * @param array  $analysis   From MPIA_Analyzer::analyze().
	 * @param array  $conflicts  From MPIA_Conflicts::detect().
	 * @param string $project_type Project type key.
	 * @param string $project_name Project name.
	 * @return array guide structure.
	 */
	public static function generate( $analysis, $conflicts, $project_type, $project_name ) {
		$location = MPIA_Profile::implementation_location( $project_type );

		return array(
			'summary'      => array(
				'project'        => $project_name,
				'project_type'   => $project_type,
				'what_this_is'   => self::what_this_is( $analysis, $project_type ),
				'where'          => $location[0],
				'where_context'  => $location[1],
				'classification' => $analysis['classification'],
				'conflict_count' => count( $conflicts ),
			),
			'conflicts'    => $conflicts,
			'steps'        => self::steps( $analysis, $project_type ),
			'dynamic_map'  => self::dynamic_map( $analysis ),
			'css_guide'    => self::css_guide( $analysis, $project_type ),
			'responsive'   => self::responsive_guide( $analysis ),
			'qa_checklist' => self::qa_checklist( $analysis, $project_type ),
		);
	}

	/** A. WHAT THIS OUTPUT IS. */
	public static function what_this_is( $analysis, $project_type ) {
		$type = $analysis['type'];
		if ( 'css' === $type ) {
			$scope = isset( $analysis['css']['scope_guess'] ) ? $analysis['css']['scope_guess'] : 'component';
			$map   = array(
				'global'    => 'Global CSS — site-wide styling rules (tokens, resets, base typography).',
				'page'      => 'Page CSS — styles for one full page/template with several components.',
				'component' => 'Component CSS — styles for a single reusable component.',
			);
			return $map[ $scope ];
		}
		if ( 'html' === $type ) {
			$sections = isset( $analysis['html']['sections'] ) ? $analysis['html']['sections'] : 0;
			if ( $sections > 3 ) {
				return 'Full page/section HTML mock — to be rebuilt as Elementor containers and widgets (never pasted as raw HTML).';
			}
			return 'Component HTML mock — to be rebuilt as one Elementor component using the widget mapping below.';
		}
		if ( 'json' === $type ) {
			$kind = isset( $analysis['json']['kind'] ) ? $analysis['json']['kind'] : 'unknown';
			$map  = array(
				'design_tokens'  => 'Design token set — implemented through Elementor Site Settings.',
				'data_map'       => 'Dynamic data mapping — the binding reference for widget dynamic tags.',
				'elementor_like' => 'Elementor-like structure — NOT verified importable; treat as a build specification.',
				'configuration'  => 'Configuration data — follow the matching settings steps.',
				'unknown'        => 'Unclassified JSON — review manually before implementing.',
			);
			return $map[ $kind ];
		}
		if ( 'markdown' === $type ) {
			return 'Specification/guide document — read alongside the generated steps.';
		}
		return 'Text material — review the extracted references and follow the generated steps.';
	}

	/** C. EXACT STEPS — click-by-click, beginner language. */
	public static function steps( $analysis, $project_type ) {
		$steps = array();
		$type  = $analysis['type'];

		// Shared opening steps per destination.
		if ( 'global_css' === $project_type || ( 'css' === $type && 'global' === ( isset( $analysis['css']['scope_guess'] ) ? $analysis['css']['scope_guess'] : '' ) ) ) {
			$steps[] = 'Open your WordPress Admin (yoursite.com/wp-admin) and log in.';
			$steps[] = 'Open any page with Elementor (Pages → any page → Edit with Elementor).';
			$steps[] = 'Click the hamburger menu (three lines, top-left of the Elementor panel).';
			$steps[] = 'Click "Site Settings".';
			$steps[] = 'Scroll the left panel to "Custom CSS" and click it.';
			$steps[] = 'BEFORE pasting: copy everything already in the box into a text file on your computer (this is your backup).';
			$steps[] = 'Paste the reviewed CSS at the END of the box. Never delete existing CSS.';
			$steps[] = 'Click "Save Changes" (bottom of the panel).';
			$steps[] = 'Open the affected pages on the front end and confirm styling. If something breaks, restore your backup.';
			return $steps;
		}

		if ( 'css' === $type ) {
			$steps[] = 'This CSS belongs to a specific component, not the whole site. First identify which template/page contains that component (see "Where to implement" above).';
			$steps[] = 'Open that template: WordPress Admin → Templates → Theme Builder → open the template, or Pages → the page → Edit with Elementor.';
			$steps[] = 'Add the CSS classes to the right elements: click the element → Advanced tab → "CSS Classes" box → type the class name WITHOUT the leading dot (e.g. type mfp-card, not .mfp-card).';
			$steps[] = 'Paste the CSS itself into Elementor → Site Settings → Custom CSS (append at the end — same backup rule as always).';
			$steps[] = 'Alternative for one-off tweaks: select the specific container → Advanced → Custom CSS (Elementor Pro) and paste only the rules for that container there.';
			$steps[] = 'Click Update/Save and check the component on desktop, tablet and mobile preview (the monitor icon at the bottom of the Elementor panel switches devices).';
			return $steps;
		}

		if ( 'html' === $type ) {
			$steps[] = 'DO NOT paste this HTML into the site. It is a visual specification: you will rebuild it with Elementor widgets, which keeps the site editable and safe.';
			$steps[] = 'Open the destination (see "Where to implement"): for templates go to Templates → Theme Builder; for pages go to Pages → Edit with Elementor.';
			$steps[] = 'For each HTML element, add its Elementor equivalent from the mapping table in this guide (e.g. <section> becomes a Container; <h2> becomes a Heading widget set to H2).';
			$steps[] = 'Build top-to-bottom: create the outer Container first, set its direction (Layout → Direction: Row or Column) and gap, then add child widgets inside it.';
			$steps[] = 'Wherever the mock shows real data (title, price, image), do NOT type the text in — click the dynamic tag icon (small database symbol) on the widget content field and select the matching source from the Dynamic Map section of this guide.';
			$steps[] = 'Add each CSS class from the mock to its widget: Advanced tab → CSS Classes (no leading dot).';
			$steps[] = 'Any <form> in the mock: place the "Mayfair Form" widget instead and choose the right form — never rebuild forms as raw HTML.';
			$steps[] = 'Set responsive behaviour per the Responsive section: use the device switcher (monitor icon, bottom of panel) and adjust sizes for Tablet and Mobile.';
			$steps[] = 'Click Publish/Update, then run the QA checklist at the end of this guide.';
			return $steps;
		}

		if ( 'json' === $type ) {
			$kind = isset( $analysis['json']['kind'] ) ? $analysis['json']['kind'] : 'unknown';
			if ( 'design_tokens' === $kind ) {
				$steps[] = 'These are design tokens. They are implemented in Elementor Site Settings — NOT imported as a file.';
				$steps[] = 'Open any page with Elementor → hamburger menu → Site Settings → Global Colors.';
				$steps[] = 'Compare each token in the JSON with the locked Mayfair palette shown in this plugin (Design System screen). Where the JSON conflicts, USE THE MAYFAIR TOKEN — the conflicts list in this guide tells you each replacement.';
				$steps[] = 'Repeat for Global Fonts (only Playfair Display and Inter are allowed).';
				$steps[] = 'Click Save Changes.';
				return $steps;
			}
			if ( 'elementor_like' === $kind ) {
				$steps[] = 'IMPORTANT: this JSON looks like Elementor structure but was NOT exported from your Elementor installation, so importing it is not reliable — dynamic field bindings would silently break.';
				$steps[] = 'Treat it as a build specification instead: open the JSON side by side and rebuild the structure with real widgets.';
				$steps[] = 'Follow the element hierarchy in the JSON top-to-bottom: each "container" element becomes an Elementor Container; each widget entry becomes the matching widget.';
				$steps[] = 'Rebind every dynamic value manually via the dynamic tag icon, using the Dynamic Map section of this guide.';
				$steps[] = 'Publish and run the QA checklist.';
				return $steps;
			}
			$steps[] = 'This JSON is a data/configuration reference. Keep it open while you build; it does not get pasted anywhere.';
			$steps[] = 'Use the Dynamic Map section of this guide to bind each listed field to its widget via the dynamic tag icon.';
			return $steps;
		}

		// Markdown / text.
		$steps[] = 'This is a written specification. Read it once fully before touching Elementor.';
		$steps[] = 'Open the destination shown in "Where to implement".';
		$steps[] = 'Work through the specification section by section, creating Containers and widgets as described.';
		$steps[] = 'Bind all dynamic data via dynamic tags per the Dynamic Map below — never type real property data by hand.';
		$steps[] = 'Apply CSS classes from the spec via Advanced → CSS Classes, and paste any CSS into Site Settings → Custom CSS (with backup).';
		$steps[] = 'Publish and run the QA checklist.';
		return $steps;
	}

	/** Dynamic data validation table. */
	public static function dynamic_map( $analysis ) {
		$known = MPIA_Profile::all_fields();
		$map   = array();
		foreach ( (array) $analysis['acf_refs'] as $ref ) {
			$pass  = in_array( $ref, $known, true );
			$map[] = array(
				'reference' => $ref,
				'result'    => $pass ? 'PASS' : 'FAIL',
				'binding'   => $pass
					? 'Widget content → dynamic tag icon → ACF Field → ' . $ref
					: 'No such field exists. Remove this binding or map to a real field — do not create new fields.',
			);
		}
		foreach ( (array) $analysis['taxonomy_refs'] as $ref ) {
			if ( 0 === strpos( $ref, 'unknown:' ) ) {
				$map[] = array(
					'reference' => substr( $ref, 8 ),
					'result'    => 'FAIL',
					'binding'   => 'Taxonomy does not exist. Use one of: ' . implode( ', ', MPIA_Profile::taxonomies() ),
				);
			} else {
				$map[] = array(
					'reference' => $ref,
					'result'    => 'PASS',
					'binding'   => 'Widget content → dynamic tag icon → Post Terms → taxonomy: ' . $ref,
				);
			}
		}
		return $map;
	}

	/** CSS implementation guidance per block. */
	public static function css_guide( $analysis, $project_type ) {
		if ( empty( $analysis['css'] ) || empty( $analysis['css']['blocks'] ) ) {
			return array();
		}
		$scope  = isset( $analysis['css']['scope_guess'] ) ? $analysis['css']['scope_guess'] : 'component';
		$where  = ( 'global' === $scope || 'global_css' === $project_type )
			? 'Elementor → Site Settings → Custom CSS (append at the end)'
			: 'Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS';
		$blocks = array();
		foreach ( $analysis['css']['blocks'] as $block ) {
			$classes  = array();
			if ( preg_match_all( '/\.([a-zA-Z_][a-zA-Z0-9_-]*)/', $block['selector'], $m ) ) {
				$classes = array_values( array_unique( $m[1] ) );
			}
			$blocks[] = array(
				'selector'       => $block['selector'],
				'purpose'        => $block['purpose'],
				'where'          => $where,
				'required_class' => $classes ? 'Add class "' . $classes[0] . '" to the target element (Advanced → CSS Classes, no dot)' : 'Targets elements directly — no class needed',
				'css'            => $block['css'],
			);
		}
		return $blocks;
	}

	/** Responsive guidance derived from breakpoints found (or Elementor defaults). */
	public static function responsive_guide( $analysis ) {
		$bps  = ! empty( $analysis['breakpoints'] ) ? $analysis['breakpoints'] : array( 767, 1024 );
		$note = ! empty( $analysis['breakpoints'] )
			? 'The imported CSS uses breakpoints at ' . implode( 'px, ', $bps ) . 'px. Elementor defaults are 767px (mobile) and 1024px (tablet) — align to Elementor defaults unless there is a strong reason not to.'
			: 'No explicit breakpoints found — use Elementor defaults: desktop above 1024px, tablet 768-1024px, mobile below 768px.';
		return array(
			'note'    => $note,
			'devices' => array(
				'desktop' => array( 'width' => 'Content width 1200px max', 'columns' => 'As designed (e.g. 3-column grids)', 'font' => 'Full type scale', 'visibility' => 'All elements' ),
				'tablet'  => array( 'width' => 'Full width minus 24px side padding', 'columns' => 'Reduce grids one step (3 to 2)', 'font' => 'Headings one step smaller', 'visibility' => 'Optional secondary elements may hide' ),
				'mobile'  => array( 'width' => 'Full width minus 18-20px side padding', 'columns' => 'Single column; CTAs full width', 'font' => 'Headings two steps smaller, body 16px minimum', 'visibility' => 'Hide only decorative elements; never hide content' ),
			),
			'how'     => 'In Elementor, click the monitor icon at the bottom of the left panel to switch device, then change any value — it saves per-device automatically. Check "no horizontal scrolling" on mobile every time.',
		);
	}

	/** Project-specific QA checklist. */
	public static function qa_checklist( $analysis, $project_type ) {
		$items = array(
			'Desktop appearance matches the approved design',
			'Tablet appearance (grids reduce correctly, nothing overlaps)',
			'Mobile appearance (single column, comfortable tap targets)',
			'No horizontal overflow on mobile (swipe left-right — page must not move)',
			'Typography: only Playfair Display + Inter render',
			'Colors: only locked Mayfair palette values appear',
			'Hover states work on interactive elements',
			'Keyboard focus visible on links/buttons/inputs',
			'All links navigate correctly',
			'Accessibility: heading order logical, one H1, no color-only meaning',
		);
		if ( ! empty( $analysis['acf_refs'] ) ) {
			$items[] = 'Dynamic fields populated on a real post (open 2-3 different posts)';
			$items[] = 'Empty field behaviour: post with missing optional data still looks correct';
		}
		if ( $analysis['forms'] > 0 || 'forms' === $project_type ) {
			$items[] = 'Form submits successfully and the lead appears in Mayfair Forms → Submissions';
			$items[] = 'Form error states readable (submit empty required field)';
		}
		if ( in_array( $project_type, array( 'single_property', 'single_project', 'single_insight' ), true ) ) {
			$items[] = 'Template condition applies to the right post type only';
			$items[] = 'Exactly one H1 in page source';
		}
		if ( in_array( $project_type, array( 'property_archive', 'project_archive', 'insight_archive' ), true ) ) {
			$items[] = 'Pagination/loop shows correct posts';
			$items[] = 'Empty archive state acceptable';
		}
		return $items;
	}
}
