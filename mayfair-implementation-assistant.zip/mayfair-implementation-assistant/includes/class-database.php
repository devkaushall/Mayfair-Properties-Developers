<?php
/**
 * Database: 5 custom tables via $wpdb->prefix + dbDelta. Never destructive.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Database {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'mayfair_impl_' . $name;
	}

	public static function activate() {
		self::create_tables();
		$role = get_role( 'administrator' );
		if ( $role ) {
			$role->add_cap( 'manage_mayfair_implementation' );
		}
		update_option( 'mpia_db_version', MPIA_DB_VERSION );
		if ( ! get_option( 'mpia_demo_seeded' ) ) {
			MPIA_Projects::seed_demo();
			update_option( 'mpia_demo_seeded', 1 );
		}
	}

	public static function deactivate() {
		// Nothing destructive.
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$projects = self::table( 'projects' );
		$versions = self::table( 'versions' );
		$assets   = self::table( 'assets' );
		$analysis = self::table( 'analysis' );
		$steps    = self::table( 'steps' );

		dbDelta( "CREATE TABLE {$projects} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			project_type VARCHAR(60) NOT NULL DEFAULT 'custom',
			description TEXT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'draft',
			current_version INT(11) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY project_type (project_type)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$versions} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			project_id BIGINT(20) UNSIGNED NOT NULL,
			version_number INT(11) UNSIGNED NOT NULL DEFAULT 1,
			input_type VARCHAR(20) NOT NULL DEFAULT 'text',
			source VARCHAR(20) NOT NULL DEFAULT 'paste',
			original_filename VARCHAR(190) NOT NULL DEFAULT '',
			content LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY project_id (project_id),
			KEY version_number (version_number)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$assets} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			project_id BIGINT(20) UNSIGNED NOT NULL,
			version_id BIGINT(20) UNSIGNED NOT NULL,
			filename VARCHAR(190) NOT NULL,
			file_type VARCHAR(20) NOT NULL DEFAULT '',
			file_size BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			content LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY project_id (project_id),
			KEY version_id (version_id)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$analysis} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			project_id BIGINT(20) UNSIGNED NOT NULL,
			version_id BIGINT(20) UNSIGNED NOT NULL,
			analysis_json LONGTEXT NULL,
			conflicts_json LONGTEXT NULL,
			guide_json LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY project_id (project_id),
			KEY version_id (version_id)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$steps} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			project_id BIGINT(20) UNSIGNED NOT NULL,
			version_id BIGINT(20) UNSIGNED NOT NULL,
			step_index INT(11) UNSIGNED NOT NULL DEFAULT 0,
			step_text TEXT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'not_started',
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY project_id (project_id),
			KEY version_id (version_id)
		) {$charset};" );
	}
}
