<?php
/**
 * Project + version + analysis persistence, step tracker, demo seed.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Projects {

	/* ---------------- Projects ---------------- */

	public static function create( $name, $type, $description = '' ) {
		global $wpdb;
		$types = MPIA_Profile::project_types();
		$now   = current_time( 'mysql' );
		$wpdb->insert(
			MPIA_Database::table( 'projects' ),
			array(
				'name'         => sanitize_text_field( $name ),
				'project_type' => isset( $types[ $type ] ) ? $type : 'custom',
				'description'  => sanitize_textarea_field( $description ),
				'status'       => 'draft',
				'created_at'   => $now,
				'updated_at'   => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function get( $id ) {
		global $wpdb;
		$t = MPIA_Database::table( 'projects' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function all() {
		global $wpdb;
		$t = MPIA_Database::table( 'projects' );
		return $wpdb->get_results( "SELECT * FROM {$t} ORDER BY updated_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function set_status( $id, $status ) {
		global $wpdb;
		$statuses = MPIA_Profile::project_statuses();
		if ( ! isset( $statuses[ $status ] ) ) {
			return new WP_Error( 'mpia_status', __( 'Unknown status.', 'mayfair-implementation-assistant' ) );
		}
		$wpdb->update(
			MPIA_Database::table( 'projects' ),
			array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		return true;
	}

	public static function delete( $id ) {
		global $wpdb;
		foreach ( array( 'versions', 'assets', 'analysis', 'steps' ) as $suffix ) {
			$wpdb->delete( MPIA_Database::table( $suffix ), array( 'project_id' => (int) $id ), array( '%d' ) );
		}
		$wpdb->delete( MPIA_Database::table( 'projects' ), array( 'id' => (int) $id ), array( '%d' ) );
		return true;
	}

	/* ---------------- Versions ---------------- */

	/** Add an imported content version. Every import = new version. */
	public static function add_version( $project_id, $content, $input_type, $source = 'paste', $filename = '' ) {
		global $wpdb;
		$project = self::get( $project_id );
		if ( ! $project ) {
			return new WP_Error( 'mpia_project', __( 'Project not found.', 'mayfair-implementation-assistant' ) );
		}
		$next = (int) $project['current_version'] + 1;
		$wpdb->insert(
			MPIA_Database::table( 'versions' ),
			array(
				'project_id'        => (int) $project_id,
				'version_number'    => $next,
				'input_type'        => sanitize_key( $input_type ),
				'source'            => in_array( $source, array( 'paste', 'file', 'zip' ), true ) ? $source : 'paste',
				'original_filename' => sanitize_file_name( $filename ),
				'content'           => $content, // stored as data, never executed; escaped on output
				'created_at'        => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		$version_id = (int) $wpdb->insert_id;
		$wpdb->update(
			MPIA_Database::table( 'projects' ),
			array( 'current_version' => $next, 'status' => 'analyzing', 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $project_id ),
			array( '%d', '%s', '%s' ),
			array( '%d' )
		);
		return $version_id;
	}

	public static function get_version( $version_id ) {
		global $wpdb;
		$t = MPIA_Database::table( 'versions' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $version_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function versions_for( $project_id ) {
		global $wpdb;
		$t = MPIA_Database::table( 'versions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT id, project_id, version_number, input_type, source, original_filename, created_at FROM {$t} WHERE project_id = %d ORDER BY version_number DESC", $project_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/* ---------------- Analysis persistence ---------------- */

	public static function run_analysis( $project_id, $version_id ) {
		global $wpdb;
		$project = self::get( $project_id );
		$version = self::get_version( $version_id );
		if ( ! $project || ! $version ) {
			return new WP_Error( 'mpia_missing', __( 'Project or version not found.', 'mayfair-implementation-assistant' ) );
		}

		$analysis  = MPIA_Analyzer::analyze( (string) $version['content'], $version['input_type'] );
		$conflicts = MPIA_Conflicts::detect( $analysis, (string) $version['content'] );
		$guide     = MPIA_Guide::generate( $analysis, $conflicts, $project['project_type'], $project['name'] );

		$wpdb->insert(
			MPIA_Database::table( 'analysis' ),
			array(
				'project_id'     => (int) $project_id,
				'version_id'     => (int) $version_id,
				'analysis_json'  => wp_json_encode( $analysis ),
				'conflicts_json' => wp_json_encode( $conflicts ),
				'guide_json'     => wp_json_encode( $guide ),
				'created_at'     => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s' )
		);
		$analysis_id = (int) $wpdb->insert_id;

		// Seed step tracker rows from the guide steps.
		$wpdb->delete( MPIA_Database::table( 'steps' ), array( 'version_id' => (int) $version_id ), array( '%d' ) );
		foreach ( $guide['steps'] as $index => $text ) {
			$wpdb->insert(
				MPIA_Database::table( 'steps' ),
				array(
					'project_id' => (int) $project_id,
					'version_id' => (int) $version_id,
					'step_index' => (int) $index,
					'step_text'  => $text,
					'status'     => 'not_started',
					'updated_at' => current_time( 'mysql' ),
				),
				array( '%d', '%d', '%d', '%s', '%s', '%s' )
			);
		}

		$new_status = MPIA_Conflicts::summary( $conflicts );
		self::set_status( $project_id, ( $new_status['critical'] > 0 || $new_status['high'] > 0 ) ? 'needs_review' : 'ready' );

		return $analysis_id;
	}

	public static function latest_analysis( $version_id ) {
		global $wpdb;
		$t   = MPIA_Database::table( 'analysis' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE version_id = %d ORDER BY id DESC LIMIT 1", $version_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $row ) {
			return null;
		}
		$row['analysis']  = json_decode( (string) $row['analysis_json'], true );
		$row['conflicts'] = json_decode( (string) $row['conflicts_json'], true );
		$row['guide']     = json_decode( (string) $row['guide_json'], true );
		return $row;
	}

	/* ---------------- Step tracker ---------------- */

	public static function steps_for( $version_id ) {
		global $wpdb;
		$t = MPIA_Database::table( 'steps' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE version_id = %d ORDER BY step_index ASC", $version_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function set_step_status( $step_id, $status ) {
		global $wpdb;
		$statuses = MPIA_Profile::step_statuses();
		if ( ! isset( $statuses[ $status ] ) ) {
			return new WP_Error( 'mpia_step', __( 'Unknown step status.', 'mayfair-implementation-assistant' ) );
		}
		$wpdb->update(
			MPIA_Database::table( 'steps' ),
			array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $step_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		return true;
	}

	public static function progress( $version_id ) {
		$steps = self::steps_for( $version_id );
		$done  = 0;
		foreach ( $steps as $step ) {
			if ( in_array( $step['status'], array( 'implemented', 'verified' ), true ) ) {
				$done++;
			}
		}
		return array( 'done' => $done, 'total' => count( $steps ) );
	}

	/* ---------------- Demo seed ---------------- */

	/** Seed the demo project with a demo CSS import + analysis on activation. */
	public static function seed_demo() {
		$demo_css = "/* Demo import: AI-generated card CSS with deliberate conflicts */\n"
			. ".prop-card { background: #FFFFFF; border: 1px solid #E5E1D8; border-radius: 12px; }\n"
			. ".prop-card__title { font-family: 'Montserrat', sans-serif; color: #0B192C; font-size: 22px; }\n"
			. ".prop-card__price { color: #725B2F; font-family: 'Playfair Display', serif; }\n"
			. ".prop-card__cta:hover { background: #A68B5B; }\n"
			. "@media (max-width: 767px) { .prop-card { padding: 16px; } }\n"
			. "/* binds: mpd_price, mpd_locality, mpd_amenities */\n";

		$project_id = self::create(
			'DEMO — Property Card CSS',
			'custom',
			'Demo project seeded on activation. Shows a typical AI CSS import with three deliberate conflicts: an off-palette color (#0B192C), a foreign font (Montserrat), an over-round radius (12px) and one invented field (mpd_amenities). Safe to delete.'
		);
		if ( is_wp_error( $project_id ) || ! $project_id ) {
			return;
		}
		$version_id = self::add_version( $project_id, $demo_css, 'css', 'paste', '' );
		if ( ! is_wp_error( $version_id ) ) {
			self::run_analysis( $project_id, $version_id );
		}
	}
}
