<?php
/**
 * Minimal dependency-free PDF 1.4 writer (Helvetica core fonts, A4).
 * Same engine pattern as Mayfair Forms & Leads; no external library,
 * no licensing question. Latin-1 output (transliterated).
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_PDF {

	private $lines = array();

	public function line( $text, $size = 10, $bold = false, $indent = 0 ) {
		$text = remove_accents( (string) $text );
		$text = preg_replace( '/[^\x20-\x7E]/', '?', $text );
		// Wrap long lines at ~95 chars for readability.
		foreach ( str_split( $text, 95 ) as $chunk ) {
			$this->lines[] = array( 'text' => $chunk, 'size' => $size, 'bold' => $bold, 'indent' => $indent );
		}
		return $this;
	}

	public function spacer() {
		$this->lines[] = array( 'text' => '', 'size' => 6, 'bold' => false, 'indent' => 0 );
		return $this;
	}

	public function rule() {
		$this->lines[] = array( 'text' => str_repeat( '_', 78 ), 'size' => 8, 'bold' => false, 'indent' => 0 );
		return $this;
	}

	public function output() {
		$pages   = array();
		$current = array();
		$y_used  = 0;
		$max_h   = 730;

		foreach ( $this->lines as $ln ) {
			$h = $ln['size'] + 6;
			if ( $y_used + $h > $max_h && ! empty( $current ) ) {
				$pages[] = $current;
				$current = array();
				$y_used  = 0;
			}
			$current[] = $ln;
			$y_used   += $h;
		}
		if ( ! empty( $current ) ) {
			$pages[] = $current;
		}
		if ( empty( $pages ) ) {
			$pages[] = array( array( 'text' => '', 'size' => 10, 'bold' => false, 'indent' => 0 ) );
		}

		$objects   = array();
		$objects[] = '<< /Type /Catalog /Pages 2 0 R >>';
		$kids      = array();
		$start     = 5;
		$n         = count( $pages );
		for ( $i = 0; $i < $n; $i++ ) {
			$kids[] = ( $start + $i * 2 ) . ' 0 R';
		}
		$objects[] = '<< /Type /Pages /Kids [' . implode( ' ', $kids ) . '] /Count ' . $n . ' >>';
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';

		foreach ( $pages as $i => $page_lines ) {
			$content = "BT\n";
			$y       = 786;
			foreach ( $page_lines as $ln ) {
				$y       -= ( $ln['size'] + 6 );
				$font     = $ln['bold'] ? '/F2' : '/F1';
				$x        = 56 + (int) $ln['indent'];
				$text     = str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), $ln['text'] );
				$content .= sprintf( "%s %d Tf\n1 0 0 1 %d %d Tm\n(%s) Tj\n", $font, (int) $ln['size'], $x, $y, $text );
			}
			$content .= 'ET';

			$pn        = $start + $i * 2;
			$cn        = $pn + 1;
			$objects[] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' . $cn . ' 0 R >>';
			$objects[] = '__STREAM__' . $content;
		}

		$pdf     = "%PDF-1.4\n";
		$offsets = array();
		foreach ( $objects as $index => $body ) {
			$num       = $index + 1;
			$offsets[] = strlen( $pdf );
			if ( 0 === strpos( $body, '__STREAM__' ) ) {
				$stream = substr( $body, 10 );
				$pdf   .= $num . " 0 obj\n<< /Length " . strlen( $stream ) . " >>\nstream\n" . $stream . "\nendstream\nendobj\n";
			} else {
				$pdf .= $num . " 0 obj\n" . $body . "\nendobj\n";
			}
		}
		$xref = strlen( $pdf );
		$cnt  = count( $objects ) + 1;
		$pdf .= "xref\n0 " . $cnt . "\n0000000000 65535 f \n";
		foreach ( $offsets as $off ) {
			$pdf .= sprintf( "%010d 00000 n \n", $off );
		}
		$pdf .= "trailer\n<< /Size " . $cnt . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
		return $pdf;
	}
}
