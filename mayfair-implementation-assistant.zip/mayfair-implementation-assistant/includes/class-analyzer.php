<?php
/**
 * Content analyzer: input-type detection, CSS/HTML/JSON parsing,
 * reference extraction, classification. Pure functions — no I/O, no writes.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPIA_Analyzer {

	/**
	 * Detect input type from content (and optional filename).
	 *
	 * @return string css|html|json|markdown|xml|text
	 */
	public static function detect_type( $content, $filename = '' ) {
		$ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'css', 'html', 'htm', 'json', 'md', 'markdown', 'xml', 'txt' ), true ) ) {
			$map = array( 'htm' => 'html', 'md' => 'markdown', 'markdown' => 'markdown', 'txt' => 'text' );
			return isset( $map[ $ext ] ) ? $map[ $ext ] : $ext;
		}

		$trim = ltrim( (string) $content );
		if ( '' === $trim ) {
			return 'text';
		}
		// JSON?
		if ( ( '{' === $trim[0] || '[' === $trim[0] ) && null !== json_decode( $trim, true ) ) {
			return 'json';
		}
		// XML?
		if ( 0 === strpos( $trim, '<?xml' ) ) {
			return 'xml';
		}
		// HTML? (tags present including doctype/common elements)
		if ( preg_match( '/<(!DOCTYPE|html|body|div|section|header|footer|h[1-6]|p|img|a|span|form|ul|table)\b/i', $trim ) ) {
			return 'html';
		}
		// CSS? (selector { prop: value } patterns, or @media/@import/:root)
		$css_score = preg_match_all( '/[.#:\[\w][^{}]*\{[^{}]*:[^{}]*\}/s', $trim )
			+ preg_match_all( '/@(media|import|font-face|keyframes|supports)\b/', $trim )
			+ preg_match_all( '/:root\s*\{/', $trim );
		if ( $css_score > 0 && ! preg_match( '/^#{1,6}\s/m', $trim ) ) {
			return 'css';
		}
		// Markdown? (headings, lists, code fences)
		if ( preg_match( '/^#{1,6}\s/m', $trim ) || preg_match( '/^```/m', $trim ) || preg_match( '/^[-*]\s/m', $trim ) ) {
			return 'markdown';
		}
		return 'text';
	}

	/**
	 * Full analysis entry point.
	 *
	 * @return array structured analysis result.
	 */
	public static function analyze( $content, $type ) {
		$result = array(
			'type'            => $type,
			'classification'  => array(),
			'css'             => array(),
			'html'            => array(),
			'json'            => array(),
			'colors'          => array(),
			'fonts'           => array(),
			'breakpoints'     => array(),
			'classes'         => array(),
			'acf_refs'        => array(),
			'taxonomy_refs'   => array(),
			'cpt_refs'        => array(),
			'headings'        => array(),
			'buttons'         => 0,
			'forms'           => 0,
			'has_js'          => false,
			'spacing_values'  => array(),
			'radius_values'   => array(),
		);

		// Universal extractions (work on any text).
		$result['colors']        = self::extract_colors( $content );
		$result['fonts']         = self::extract_fonts( $content );
		$result['acf_refs']      = self::extract_acf_refs( $content );
		$result['taxonomy_refs'] = self::extract_taxonomy_refs( $content );
		$result['cpt_refs']      = self::extract_cpt_refs( $content );
		$result['has_js']        = (bool) preg_match( '/<script\b|addEventListener\s*\(|document\.querySelector|jQuery\s*\(|\$\(\s*[\'"]/i', $content );

		if ( 'css' === $type ) {
			$result['css']            = self::analyze_css( $content );
			$result['classes']        = $result['css']['classes'];
			$result['breakpoints']    = $result['css']['breakpoints'];
			$result['spacing_values'] = $result['css']['spacing'];
			$result['radius_values']  = $result['css']['radii'];
		} elseif ( 'html' === $type ) {
			$result['html']     = self::analyze_html( $content );
			$result['classes']  = $result['html']['classes'];
			$result['headings'] = $result['html']['headings'];
			$result['buttons']  = $result['html']['buttons'];
			$result['forms']    = $result['html']['forms'];
			// Inline <style> blocks get CSS analysis too.
			if ( preg_match_all( '/<style[^>]*>(.*?)<\/style>/is', $content, $m ) ) {
				$result['css'] = self::analyze_css( implode( "\n", $m[1] ) );
			}
		} elseif ( 'json' === $type ) {
			$result['json'] = self::analyze_json( $content );
		}

		$result['classification'] = self::classify( $content, $type, $result );
		return $result;
	}

	/* ------------------------------------------------------------------ */
	/* CSS                                                                */
	/* ------------------------------------------------------------------ */

	public static function analyze_css( $css ) {
		$out = array(
			'selectors'   => array(),
			'classes'     => array(),
			'variables'   => array(),
			'breakpoints' => array(),
			'spacing'     => array(),
			'radii'       => array(),
			'rules_count' => 0,
			'scope_guess' => 'component',
			'blocks'      => array(),
		);

		$clean = preg_replace( '#/\*.*?\*/#s', '', (string) $css );

		// Custom properties.
		if ( preg_match_all( '/(--[a-zA-Z0-9_-]+)\s*:/', $clean, $m ) ) {
			$out['variables'] = array_values( array_unique( $m[1] ) );
		}

		// Breakpoints.
		if ( preg_match_all( '/@media[^{]*\(\s*(?:max|min)-width\s*:\s*(\d+)px/', $clean, $m ) ) {
			$out['breakpoints'] = array_values( array_unique( array_map( 'intval', $m[1] ) ) );
			sort( $out['breakpoints'] );
		}

		// Selectors + classes (top-level and inside media).
		if ( preg_match_all( '/([^{}@]+)\{/', $clean, $m ) ) {
			foreach ( $m[1] as $sel ) {
				$sel = trim( $sel );
				if ( '' === $sel || 0 === strpos( $sel, '@' ) ) {
					continue;
				}
				$out['selectors'][] = $sel;
			}
			$out['selectors'] = array_values( array_unique( $out['selectors'] ) );
		}
		if ( preg_match_all( '/\.([a-zA-Z_][a-zA-Z0-9_-]*)/', $clean, $m ) ) {
			$out['classes'] = array_values( array_unique( $m[1] ) );
		}

		// Spacing values.
		if ( preg_match_all( '/(?:padding|margin|gap)[^:;{}]*:\s*([^;{}]+);/', $clean, $m ) ) {
			$out['spacing'] = array_values( array_unique( array_map( 'trim', $m[1] ) ) );
		}

		// Border radii.
		if ( preg_match_all( '/border-radius\s*:\s*([^;{}]+);/', $clean, $m ) ) {
			$out['radii'] = array_values( array_unique( array_map( 'trim', $m[1] ) ) );
		}

		$out['rules_count'] = substr_count( $clean, '{' );

		// Scope guess: :root/body/html/universal resets => global; many distinct prefixes => page; else component.
		if ( preg_match( '/(^|\s)(:root|html|body|\*)\s*[,{]/m', $clean ) ) {
			$out['scope_guess'] = 'global';
		} else {
			$prefixes = array();
			foreach ( $out['classes'] as $cls ) {
				$prefixes[ preg_replace( '/(__|--|-).*$/', '', $cls ) ] = true;
			}
			$out['scope_guess'] = count( $prefixes ) > 4 ? 'page' : 'component';
		}

		// Block-level breakdown (rule + guessed purpose) for the CSS engine UI.
		if ( preg_match_all( '/([^{}@]+)\{([^{}]*)\}/s', $clean, $mm, PREG_SET_ORDER ) ) {
			foreach ( array_slice( $mm, 0, 100 ) as $rule ) {
				$sel  = trim( $rule[1] );
				$body = trim( $rule[2] );
				if ( '' === $sel ) {
					continue;
				}
				$out['blocks'][] = array(
					'selector' => $sel,
					'purpose'  => self::guess_rule_purpose( $sel, $body ),
					'css'      => $sel . ' { ' . $body . ' }',
				);
			}
		}

		return $out;
	}

	private static function guess_rule_purpose( $sel, $body ) {
		if ( false !== strpos( $body, 'font-family' ) || false !== strpos( $body, 'font-size' ) ) {
			return 'Typography';
		}
		if ( false !== strpos( $body, 'grid' ) || false !== strpos( $body, 'flex' ) ) {
			return 'Layout';
		}
		if ( false !== strpos( $sel, ':hover' ) || false !== strpos( $sel, ':focus' ) ) {
			return 'Interaction state';
		}
		if ( false !== strpos( $body, 'background' ) || false !== strpos( $body, 'color' ) ) {
			return 'Color/surface';
		}
		if ( false !== strpos( $body, 'padding' ) || false !== strpos( $body, 'margin' ) ) {
			return 'Spacing';
		}
		return 'General styling';
	}

	/* ------------------------------------------------------------------ */
	/* HTML                                                               */
	/* ------------------------------------------------------------------ */

	public static function analyze_html( $html ) {
		$out = array(
			'elements'    => array(),
			'headings'    => array(),
			'classes'     => array(),
			'buttons'     => 0,
			'forms'       => 0,
			'images'      => 0,
			'links'       => 0,
			'sections'    => 0,
			'widget_tree' => array(),
		);

		if ( preg_match_all( '/<([a-zA-Z][a-zA-Z0-9]*)\b/', $html, $m ) ) {
			$counts = array_count_values( array_map( 'strtolower', $m[1] ) );
			arsort( $counts );
			$out['elements'] = $counts;
		}
		foreach ( array( 1, 2, 3, 4, 5, 6 ) as $level ) {
			if ( preg_match_all( '/<h' . $level . '[^>]*>(.*?)<\/h' . $level . '>/is', $html, $hm ) ) {
				foreach ( $hm[1] as $text ) {
					$out['headings'][] = array( 'level' => $level, 'text' => trim( wp_strip_all_tags( $text ) ) );
				}
			}
		}
		if ( preg_match_all( '/class\s*=\s*["\']([^"\']+)["\']/', $html, $cm ) ) {
			$all = array();
			foreach ( $cm[1] as $list ) {
				foreach ( preg_split( '/\s+/', trim( $list ) ) as $cls ) {
					if ( '' !== $cls ) {
						$all[ $cls ] = true;
					}
				}
			}
			$out['classes'] = array_keys( $all );
		}
		$out['buttons']  = preg_match_all( '/<button\b|class\s*=\s*["\'][^"\']*(btn|button|cta)[^"\']*["\']/i', $html );
		$out['forms']    = preg_match_all( '/<form\b/i', $html );
		$out['images']   = preg_match_all( '/<img\b/i', $html );
		$out['links']    = preg_match_all( '/<a\b/i', $html );
		$out['sections'] = preg_match_all( '/<(section|header|footer|main|article)\b/i', $html );

		$out['widget_tree'] = self::html_to_elementor_tree( $html );
		return $out;
	}

	/** Map HTML elements to Elementor equivalents (guidance, not conversion). */
	public static function html_to_elementor_tree( $html ) {
		$map = array(
			'section' => 'Container (full-width section)',
			'header'  => 'Container (or Theme Builder Header template)',
			'footer'  => 'Container (or Theme Builder Footer template)',
			'main'    => 'Container',
			'article' => 'Container',
			'div'     => 'Container (Flexbox)',
			'h1'      => 'Heading widget (HTML tag H1 — only one per page)',
			'h2'      => 'Heading widget (H2)',
			'h3'      => 'Heading widget (H3)',
			'h4'      => 'Heading widget (H4)',
			'p'       => 'Text Editor widget',
			'img'     => 'Image widget (or Featured Image dynamic widget)',
			'a'       => 'Button widget (for CTAs) or inline link in Text Editor',
			'button'  => 'Button widget',
			'form'    => 'Mayfair Form widget (never rebuild forms in raw HTML)',
			'ul'      => 'Icon List widget (or Text Editor list)',
			'ol'      => 'Text Editor (ordered list)',
			'iframe'  => 'Video widget (if video) or HTML widget (last resort)',
			'svg'     => 'Icon widget (upload as custom icon) or Image widget',
			'span'    => '(usually styling only — handled by parent widget settings)',
			'nav'     => 'Nav Menu widget (Elementor Pro)',
			'table'   => 'Text Editor (tables) — or restructure as Icon List',
		);

		$tree = array();
		if ( preg_match_all( '/<([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/', $html, $m ) ) {
			$seen = array();
			foreach ( array_map( 'strtolower', $m[1] ) as $tag ) {
				if ( isset( $map[ $tag ] ) && ! isset( $seen[ $tag ] ) ) {
					$tree[]        = array( 'html' => '<' . $tag . '>', 'elementor' => $map[ $tag ] );
					$seen[ $tag ]  = true;
				}
			}
		}
		return $tree;
	}

	/* ------------------------------------------------------------------ */
	/* JSON                                                               */
	/* ------------------------------------------------------------------ */

	public static function analyze_json( $json ) {
		$data = json_decode( (string) $json, true );
		$out  = array(
			'valid'    => null !== $data,
			'kind'     => 'unknown',
			'keys'     => array(),
			'importable_elementor' => false,
			'note'     => '',
		);
		if ( ! $out['valid'] ) {
			$out['note'] = 'JSON does not parse. Fix syntax before analysis.';
			return $out;
		}
		$out['keys'] = is_array( $data ) ? array_slice( array_keys( $data ), 0, 40 ) : array();
		$flat        = strtolower( wp_json_encode( $data ) );

		// Native Elementor exports carry specific structural markers.
		$elementor_markers = ( false !== strpos( $flat, '"eltype"' ) ) + ( false !== strpos( $flat, '"widgettype"' ) ) + ( false !== strpos( $flat, '"elements"' ) );
		if ( $elementor_markers >= 2 ) {
			$out['kind'] = 'elementor_like';
			$out['note'] = 'Structure resembles Elementor, but only a file exported by YOUR Elementor installation is safely importable. Dynamic ACF bindings reference database-specific field keys, so treat this as a specification and rebuild bindings manually.';
		} elseif ( preg_match( '/"#[0-9a-f]{3,6}"/', $flat ) || false !== strpos( $flat, 'colors' ) || false !== strpos( $flat, 'tokens' ) || false !== strpos( $flat, 'typography' ) ) {
			$out['kind'] = 'design_tokens';
			$out['note'] = 'Design token set — implement via Elementor Site Settings (Global Colors / Global Fonts), validated against the locked Mayfair system.';
		} elseif ( false !== strpos( $flat, 'mpd_' ) || false !== strpos( $flat, 'mpi_' ) || false !== strpos( $flat, 'dynamic' ) || false !== strpos( $flat, 'acf' ) ) {
			$out['kind'] = 'data_map';
			$out['note'] = 'Dynamic data mapping — use it as the binding reference while building widgets.';
		} elseif ( false !== strpos( $flat, 'settings' ) || false !== strpos( $flat, 'config' ) ) {
			$out['kind'] = 'configuration';
			$out['note'] = 'Configuration data — follow the matching implementation guide section.';
		}
		// Never claim importability for non-native files.
		$out['importable_elementor'] = false;
		return $out;
	}

	/* ------------------------------------------------------------------ */
	/* Reference extraction                                               */
	/* ------------------------------------------------------------------ */

	public static function extract_colors( $content ) {
		$colors = array();
		if ( preg_match_all( '/#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b/', (string) $content, $m ) ) {
			foreach ( $m[0] as $hex ) {
				$colors[ strtoupper( $hex ) ] = true;
			}
		}
		return array_keys( $colors );
	}

	public static function extract_fonts( $content ) {
		$fonts = array();
		if ( preg_match_all( '/font-family\s*:\s*([^;}{"]+)[;}]/i', (string) $content, $m ) ) {
			foreach ( $m[1] as $stack ) {
				foreach ( explode( ',', $stack ) as $f ) {
					$f = trim( trim( trim( $f ), '"\'' ) );
					if ( '' !== $f ) {
						$fonts[ $f ] = true;
					}
				}
			}
		}
		// Also catch named fonts in JSON/markdown specs.
		foreach ( array( 'Playfair Display', 'Inter', 'Roboto', 'Poppins', 'Montserrat', 'Lato', 'Open Sans', 'DM Sans', 'Cormorant Garamond', 'Raleway', 'Oswald', 'Merriweather' ) as $known ) {
			if ( false !== stripos( (string) $content, $known ) ) {
				$fonts[ $known ] = true;
			}
		}
		return array_keys( $fonts );
	}

	public static function extract_acf_refs( $content ) {
		$refs = array();
		if ( preg_match_all( '/\b(mp[di]_[a-z0-9_]+)\b/i', (string) $content, $m ) ) {
			foreach ( $m[1] as $ref ) {
				$refs[ strtolower( $ref ) ] = true;
			}
		}
		return array_keys( $refs );
	}

	public static function extract_taxonomy_refs( $content ) {
		$known = MPIA_Profile::taxonomies();
		$found = array();
		foreach ( $known as $tax ) {
			if ( false !== stripos( (string) $content, $tax ) ) {
				$found[] = $tax;
			}
		}
		// Suspicious taxonomy-like slugs not in the architecture.
		if ( preg_match_all( '/taxonomy["\'\s:=]+([a-z0-9-]+)/i', (string) $content, $m ) ) {
			foreach ( $m[1] as $slug ) {
				$slug = strtolower( $slug );
				if ( ! in_array( $slug, $known, true ) && ! in_array( 'unknown:' . $slug, $found, true ) && strlen( $slug ) > 2 ) {
					$found[] = 'unknown:' . $slug;
				}
			}
		}
		return $found;
	}

	public static function extract_cpt_refs( $content ) {
		$found = array();
		foreach ( MPIA_Profile::cpts() as $cpt ) {
			if ( preg_match( '/\b' . preg_quote( $cpt, '/' ) . '\b/i', (string) $content ) ) {
				$found[] = $cpt;
			}
		}
		if ( preg_match_all( '/post[_-]?type["\'\s:=]+([a-z0-9_-]+)/i', (string) $content, $m ) ) {
			foreach ( $m[1] as $slug ) {
				$slug = strtolower( $slug );
				if ( ! in_array( $slug, MPIA_Profile::cpts(), true ) && ! in_array( $slug, array( 'post', 'page', 'attachment' ), true ) && ! in_array( 'unknown:' . $slug, $found, true ) ) {
					$found[] = 'unknown:' . $slug;
				}
			}
		}
		return $found;
	}

	/* ------------------------------------------------------------------ */
	/* Classification                                                     */
	/* ------------------------------------------------------------------ */

	public static function classify( $content, $type, $result ) {
		$tags = array();
		$flat = strtolower( (string) $content );

		if ( ! empty( $result['colors'] ) && ( false !== strpos( $flat, 'token' ) || false !== strpos( $flat, ':root' ) || 'design_tokens' === ( isset( $result['json']['kind'] ) ? $result['json']['kind'] : '' ) ) ) {
			$tags[] = 'Design System';
		}
		if ( false !== strpos( $flat, 'elementor' ) || false !== strpos( $flat, 'widget' ) || false !== strpos( $flat, 'container' ) ) {
			$tags[] = 'Elementor';
		}
		if ( false !== strpos( $flat, 'wordpress' ) || false !== strpos( $flat, 'wp-' ) || ! empty( $result['cpt_refs'] ) ) {
			$tags[] = 'WordPress';
		}
		if ( ! empty( $result['acf_refs'] ) || false !== strpos( $flat, 'acf' ) ) {
			$tags[] = 'ACF';
		}
		if ( 'css' === $type || ! empty( $result['css'] ) ) {
			$tags[] = 'CSS';
		}
		if ( 'html' === $type ) {
			$tags[] = 'HTML';
		}
		if ( $result['has_js'] ) {
			$tags[] = 'JavaScript';
		}
		if ( $result['forms'] > 0 || false !== strpos( $flat, 'form' ) ) {
			$tags[] = 'Forms';
		}
		if ( false !== strpos( $flat, 'seo' ) || false !== strpos( $flat, 'schema' ) || false !== strpos( $flat, 'meta description' ) ) {
			$tags[] = 'SEO';
		}
		if ( ! empty( $result['breakpoints'] ) || false !== strpos( $flat, 'responsive' ) || false !== strpos( $flat, 'mobile' ) ) {
			$tags[] = 'Responsive';
		}
		if ( preg_match( '/\.(jpg|jpeg|png|webp|svg|woff2?)\b/i', $flat ) ) {
			$tags[] = 'Assets';
		}
		if ( empty( $tags ) ) {
			$tags[] = 'Unknown';
		}
		return $tags;
	}
}
