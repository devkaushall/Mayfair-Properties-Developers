<?php
/**
 * Plugin Name:       Mayfair Implementation Assistant
 * Description:       Implementation guidance system for the Mayfair Properties & Developers website. Paste or upload AI-generated design/code output; the plugin analyzes it against the locked Mayfair architecture and design system, flags conflicts, and generates click-by-click WordPress + Elementor implementation guides. It never edits the live site automatically.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Mayfair Properties & Developers
 * License:           GPL-2.0-or-later
 * Text Domain:       mayfair-implementation-assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MPIA_VERSION', '1.0.0' );
define( 'MPIA_DB_VERSION', '1.0.0' );
define( 'MPIA_FILE', __FILE__ );
define( 'MPIA_DIR', plugin_dir_path( __FILE__ ) );
define( 'MPIA_URL', plugin_dir_url( __FILE__ ) );

require_once MPIA_DIR . 'includes/class-profile.php';
require_once MPIA_DIR . 'includes/class-database.php';
require_once MPIA_DIR . 'includes/class-analyzer.php';
require_once MPIA_DIR . 'includes/class-conflicts.php';
require_once MPIA_DIR . 'includes/class-guide.php';
require_once MPIA_DIR . 'includes/class-uploads.php';
require_once MPIA_DIR . 'includes/class-pdf.php';
require_once MPIA_DIR . 'includes/class-exports.php';
require_once MPIA_DIR . 'includes/class-projects.php';
require_once MPIA_DIR . 'includes/class-elementor.php';
require_once MPIA_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'MPIA_Database', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MPIA_Database', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'MPIA_Plugin', 'instance' ) );
