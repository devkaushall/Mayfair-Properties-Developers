# User Guide — Mayfair Implementation Assistant
*For non-coders. The plugin never changes your website — it tells you exactly what to do, you do it.*

## The one-minute version
1. **Mayfair Implementation → Projects** → create a project (pick the right type — it determines the "where to implement" guidance).
2. Open the project → **paste** the AI output into the big box (or **upload** the file/ZIP) → click **Import & Analyze**.
3. Read three things, in order:
   - **A. What This Output Is** — plain-English identification.
   - **Conflicts** — anything that clashes with your locked design/architecture, each with the exact replacement to use.
   - **C. Implementation Steps** — numbered clicks. Follow them top to bottom.
4. As you work, set each step's dropdown (In Progress → Implemented → Verified). The counter shows `n / total completed`.
5. Need it outside WordPress? **Export** the guide as PDF, TXT, Markdown or a complete ZIP.

## Understanding conflicts
| Severity | Meaning | What you do |
|---|---|---|
| CRITICAL | Would break or fabricate data (invented field, wrong CPT, ACF Pro feature) | Do NOT implement that part; use the recommendation |
| HIGH | Off-brand or unsupported (foreign color/font, custom JS, paid addon) | Replace with the locked value shown |
| MEDIUM | Style drift (radius too round, suspicious data like "amenities") | Adjust per recommendation |
| LOW / INFO | Notes | Read, proceed |

The plugin **never silently fixes** imported material — it shows `Found → Expected → Recommendation` and you decide.

## The demo project
"DEMO — Property Card CSS" is pre-loaded with intentional mistakes so you can see the full workflow. Open it, look at the 4+ conflicts it catches, skim the generated guide, then delete it whenever you like.

## Versions
Each import becomes v1, v2, v3… under the same project. Click **Open** on any older version to see its analysis, compare by eye, export it, or re-run analysis. Nothing is ever overwritten.

## Reference screens
- **Design System** — the 14 locked colors (with swatches), the two fonts, the shape rules. This is what all imports are checked against.
- **Architecture** — the locked CPTs, taxonomies, and all 35 ACF fields.

## Tips
- Paste CSS separately from HTML when you can — cleaner analyses.
- If a guide step doesn't match what you see in Elementor (versions change), the intent of the step still applies; the ELEMENTOR-GUIDE.md doc maps terminology.
- Uploading a ZIP? Only text files inside are read. PHP/JS files are listed but never imported — that's a safety feature, not a bug.
