# Security Documentation

## Threat model: AI-generated and user-uploaded content is untrusted
1. **No execution, ever.** Uploads/pastes are stored as LONGTEXT data. There is no include/require/eval path, no writing uploads to disk in executable locations (in fact uploads are never written to disk at all — content is read into memory and stored in the DB).
2. **PHP refusal.** Any pasted or uploaded content containing PHP open tags is rejected outright (paste, file, and per-ZIP-entry).
3. **ZIP inspection safety.** ZipArchive read-only, in-memory: entry cap (50), per-entry size cap (1 MB), archive cap (10 MB), compression-ratio zip-bomb guard (200:1), path-traversal/absolute-path entries skipped, PHP/JS/binary entries listed in a manifest but never imported.
4. **MIME/extension allowlist** for text uploads (css/html/json/md/txt/xml/zip) + binary detection (NUL byte + printable-ratio heuristic).
5. **Filenames** sanitized with sanitize_file_name() everywhere.

## WordPress hardening
- Nonce per admin task (check_admin_referer('mpia_admin_{task}')) + capability manage_mayfair_implementation on every page and action; widget renders only for that capability.
- All SQL prepared or via $wpdb->insert/update/delete with format arrays; tables from $wpdb->prefix + fixed suffixes.
- All admin output escaped (esc_html/esc_attr/esc_url/esc_textarea); imported content is always rendered inside esc_textarea() — displayed as text, never as HTML.
- ABSPATH guard in every file; uninstall guarded by WP_UNINSTALL_PLUGIN.

## What the plugin cannot do by construction
No Elementor mutation APIs, no update_option on site settings, no register_post_type/register_taxonomy, no acf_* writes, no file writes outside wp_tempnam scratch for ZIP export (immediately deleted), no remote calls (v1 has no AI API).
