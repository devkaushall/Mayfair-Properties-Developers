# Elementor Guide — how generated instructions map to the Elementor UI

## Terminology the guides use
| Guide says | In Elementor |
|---|---|
| Container | The Flexbox Container element (Elementor's layout block) |
| dynamic tag icon | The small stacked-cylinders (database) icon that appears on a content field hover |
| Advanced → CSS Classes | Select element → Advanced tab → "CSS Classes" input (enter class names WITHOUT the dot) |
| Site Settings → Custom CSS | Hamburger menu (top-left of panel) → Site Settings → Custom CSS |
| Theme Builder | Templates → Theme Builder in wp-admin |
| Display Conditions | Element → Advanced → Display Conditions (Elementor Pro) |
| device switcher | Monitor icon at the bottom of the Elementor panel (Desktop/Tablet/Mobile) |

## HTML → Elementor mapping used by the analyzer
section/header/footer/main/article/div → Container · h1–h4 → Heading (matching tag; ONE h1 per page) · p → Text Editor · img → Image (or Featured Image dynamic) · a/button → Button · form → **Mayfair Form widget** (never raw HTML forms) · ul → Icon List · iframe → Video widget · svg → Icon widget · nav → Nav Menu (Pro)

## Dynamic bindings
Property fields: widget field → dynamic icon → ACF Field → pick the field (e.g. Price = mpd_price).
Taxonomies: dynamic icon → Post Terms → choose taxonomy (location / property-type / property-status…).
Native: Post Title, Post Content, Featured Image, Post URL.
The Dynamic Data Validation table in each guide marks every reference PASS/FAIL before you build.

## The optional reference widget
"Mayfair Implementation Reference" (Mayfair category) shows a project's steps/conflicts/QA inside the editor while you build. It renders ONLY for logged-in implementation admins — visitors see nothing. Remove it before final launch anyway.
