# QA Guide

## Part A — Static validation performed before delivery (generation environment)
- PHP syntax: 19/19 files clean (php -l, PHP 8.4)
- 48/48 functional tests on the analyzer/conflict/guide/PDF engines in PHP CLI:
  type detection (8), CSS analysis (8), conflict detection (9), ACF/taxonomy validation (6),
  HTML analysis + Elementor mapping (8), JSON classification (5), nearest-token math (2), PDF structure (3)
- Automated source audit: ABSPATH guards, nonce-per-task, capability checks, prepared SQL,
  escaping density, upload safety (no move to executable paths, no include/require of uploads,
  PHP refusal, ZIP in-memory inspection), no CPT/taxonomy/ACF registration or mutation calls
- These are STATIC results. No live WordPress testing occurred anywhere.

## Part B — Live checklist (run on staging after manual install)
- [ ] Activate: 5 mayfair_impl_* tables exist; demo project visible with analysis + conflicts
- [ ] Create project of each type; statuses change; delete works
- [ ] Paste CSS with a wrong color → DESIGN SYSTEM CONFLICT with correct replacement token
- [ ] Paste text containing <?php → refused
- [ ] Upload .css/.json/.md → detected types correct; upload .exe → refused
- [ ] Upload ZIP containing a .php file → PHP listed as "LISTED ONLY", not imported
- [ ] Analysis: classes/colors/fonts/breakpoints extracted correctly on a real AI output
- [ ] Guide renders: what-is / where / steps / dynamic map / responsive / QA
- [ ] Step tracker: statuses persist; progress counter updates
- [ ] Versions: second import becomes v2; v1 still opens with its own analysis
- [ ] Exports: PDF opens in a viewer; TXT/MD/JSON download; CSS file matches source; project ZIP contains all files
- [ ] Elementor: Mayfair Implementation Reference widget appears under Mayfair category; renders for admin, silent for logged-out visitor
- [ ] Uninstall with mpia_keep_data unset → tables removed; with option set → preserved
- [ ] Confirm nothing on the site changed: CPTs, taxonomies, ACF, Elementor templates all untouched
