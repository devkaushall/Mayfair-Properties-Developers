# Demo Implementation Guide — DEMO Property Card CSS

*Sample of the guide the plugin generates and exports (Markdown flavour), produced by the real guide engine.*

## A. What This Output Is
Component CSS — styles for a single reusable component.

## B. Where To Implement
Depends on component — see generated steps

## C. Implementation Steps
1. This CSS belongs to a specific component, not the whole site. First identify which template/page contains that component (see "Where to implement" above).
2. Open that template: WordPress Admin → Templates → Theme Builder → open the template, or Pages → the page → Edit with Elementor.
3. Add the CSS classes to the right elements: click the element → Advanced tab → "CSS Classes" box → type the class name WITHOUT the leading dot (e.g. type mfp-card, not .mfp-card).
4. Paste the CSS itself into Elementor → Site Settings → Custom CSS (append at the end — same backup rule as always).
5. Alternative for one-off tweaks: select the specific container → Advanced → Custom CSS (Elementor Pro) and paste only the rules for that container there.
6. Click Update/Save and check the component on desktop, tablet and mobile preview (the monitor icon at the bottom of the Elementor panel switches devices).

## CSS Blocks
**`.prop-card`** — Color/surface
- Where: Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS
- Add class "prop-card" to the target element (Advanced → CSS Classes, no dot)

**`.prop-card__title`** — Typography
- Where: Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS
- Add class "prop-card__title" to the target element (Advanced → CSS Classes, no dot)

**`.prop-card__price`** — Typography
- Where: Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS
- Add class "prop-card__price" to the target element (Advanced → CSS Classes, no dot)

**`.prop-card__cta:hover`** — Interaction state
- Where: Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS
- Add class "prop-card__cta" to the target element (Advanced → CSS Classes, no dot)

**`.prop-card`** — Spacing
- Where: Site Settings → Custom CSS (preferred) OR the specific container → Advanced → Custom CSS
- Add class "prop-card" to the target element (Advanced → CSS Classes, no dot)

## Responsive
The imported CSS uses breakpoints at 767px. Elementor defaults are 767px (mobile) and 1024px (tablet) — align to Elementor defaults unless there is a strong reason not to.

## QA Checklist
- [ ] Desktop appearance matches the approved design
- [ ] Tablet appearance (grids reduce correctly, nothing overlaps)
- [ ] Mobile appearance (single column, comfortable tap targets)
- [ ] No horizontal overflow on mobile (swipe left-right — page must not move)
- [ ] Typography: only Playfair Display + Inter render
- [ ] Colors: only locked Mayfair palette values appear
- [ ] Hover states work on interactive elements
- [ ] Keyboard focus visible on links/buttons/inputs
- [ ] All links navigate correctly
- [ ] Accessibility: heading order logical, one H1, no color-only meaning
- [ ] Dynamic fields populated on a real post (open 2-3 different posts)
- [ ] Empty field behaviour: post with missing optional data still looks correct
