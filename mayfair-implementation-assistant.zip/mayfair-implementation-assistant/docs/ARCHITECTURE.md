# Developer Architecture — Mayfair Implementation Assistant

## Principles
1. Guidance only: zero write-paths to Elementor, site settings, CPTs, taxonomies, ACF, or content.
2. Uploaded/pasted material is inert data: stored in LONGTEXT, escaped on output, refused if PHP, never included/executed.
3. Pure-logic core (Profile/Analyzer/Conflicts/Guide) — fully unit-testable outside WordPress.
4. MPIA_ prefix everywhere; prepared SQL; capability manage_mayfair_implementation.

## File map
```
mayfair-implementation-assistant/
├── mayfair-implementation-assistant.php   Bootstrap
├── uninstall.php                          Table cleanup (guarded by mpia_keep_data option)
├── includes/
│   ├── class-profile.php        LOCKED profile: stack, CPTs, taxonomies, 35 fields, tokens, shape
│   ├── class-analyzer.php       Type detection + CSS/HTML/JSON analysis + reference extraction
│   ├── class-conflicts.php      11 conflict checks vs the locked profile; severity model
│   ├── class-guide.php          What-is/where/steps + dynamic map + responsive + QA generator
│   ├── class-projects.php       Project/version/analysis/step persistence + demo seed
│   ├── class-uploads.php        Safe text/ZIP intake (no execution, no disk extraction)
│   ├── class-database.php       5 tables via dbDelta + $wpdb->prefix
│   ├── class-pdf.php            Dependency-free PDF 1.4 writer
│   ├── class-exports.php        PDF/TXT/MD/JSON/CSS/HTML-ref/ZIP exports
│   ├── class-elementor.php      Category + optional reference widget (lazy)
│   ├── class-elementor-widget.php
│   └── class-plugin.php         Menu, views, nonce+cap-checked action dispatcher
├── admin/views/                 dashboard, projects, project-detail, design-system, architecture
├── admin/assets/mpia-admin.css
└── docs/
```

## Data flow
```
paste/upload → MPIA_Uploads (validate, refuse PHP, inspect ZIP in memory)
            → MPIA_Projects::add_version (stores content verbatim as data)
            → MPIA_Projects::run_analysis:
                MPIA_Analyzer::analyze  → structure/reference extraction
                MPIA_Conflicts::detect  → flags vs locked profile
                MPIA_Guide::generate    → steps/dynamic map/responsive/QA
              persisted as JSON in analysis table; steps seeded into tracker
            → project status: needs_review (critical/high conflicts) or ready
```

## Tables
wp_mayfair_impl_projects / _versions / _assets / _analysis / _steps — see class-database.php; all $wpdb->prefix, dbDelta, indexed FKs, never destroyed on update.

## Extension seams
- Add conflict checks: new method in MPIA_Conflicts + merge in detect().
- Add project types: MPIA_Profile::project_types() + implementation_location().
- v2 candidates: AI API integration, diff view between versions, per-block copy buttons with JS.
