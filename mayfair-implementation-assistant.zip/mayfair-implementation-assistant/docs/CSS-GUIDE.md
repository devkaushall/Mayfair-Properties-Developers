# CSS Guide — how the CSS engine decides placement

## Scope detection
- **Global CSS** — contains :root/html/body/universal rules → paste destination: Elementor → Site Settings → Custom CSS (append at END, after backing up existing CSS).
- **Page CSS** — many distinct class prefixes → Site Settings (preferred) with classes applied across the page's elements.
- **Component CSS** — one class family (e.g. .prop-card__*) → Site Settings, or the specific container's Advanced → Custom CSS for one-offs.

## Per-block guidance
Every rule block in an analysis shows: selector · purpose (Typography/Layout/Interaction/Color/Spacing) · where to paste · which class must be added to which element (Advanced → CSS Classes, no dot). Blocks are click-to-select for copying; the full file exports via Export → CSS file.

## Golden rules the guides enforce
1. Never delete existing Custom CSS — always append, always back up first.
2. Class names in Elementor's CSS Classes box have NO leading dot.
3. Conflicting colors/fonts/radii are replaced with locked tokens BEFORE pasting (the conflict table gives the exact substitution).
4. If a rule targets bare elements (h1, body), prefer expressing it through Elementor Site Settings controls instead of CSS where possible.
