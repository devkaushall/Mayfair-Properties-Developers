# Mayfair Implementation Assistant

**Version 1.0.0 — Generated for manual installation. Not installed, activated, or tested on the live website.**

An implementation guidance system for the Mayfair Properties & Developers website. Paste or upload AI-generated output (Google Stitch, AI Studio, coding agents…) and the plugin analyzes it against the **locked Mayfair architecture and design system**, flags every conflict, and produces click-by-click WordPress + Elementor implementation guides.

> **"Give me the AI output, and I will tell you exactly where and how to implement it inside your Mayfair WordPress + Elementor website."**

## What it is — and is not

| It IS | It is NOT |
|---|---|
| A controlled implementation assistant | A website builder |
| An analyzer + conflict detector + guide generator | An autonomous website editor |
| A project/version/progress tracker | An AI API integration (v1 has none) |
| A safe inspector of pasted/uploaded material | An executor of any uploaded code — PHP/JS is never run |

**It never**: edits Elementor, changes site settings, modifies CPTs/taxonomies/ACF, or touches the live site in any way. Every change to the website remains a deliberate manual action by you, guided step-by-step.

## Core workflow

1. **Mayfair Implementation → Projects → Create Project** (e.g. "Mayfair Homepage", type: Homepage).
2. **Paste content** or **upload a file/ZIP** (CSS, HTML, JSON, MD, TXT, XML, ZIP). Type is auto-detected.
3. The plugin **analyzes** instantly: selectors, tokens, colors, fonts, breakpoints, classes, headings, forms, ACF/taxonomy/CPT references, JS requirements.
4. **Review conflicts**: off-palette colors (with the nearest locked token as the recommended replacement), foreign fonts, invented fields, wrong taxonomies/CPTs, ACF Pro features, over-round radii, unsupported dependencies — classified Critical → Informational.
5. **Follow the generated guide**: what this output is → where to implement → exact click-by-click steps → dynamic data validation (PASS/FAIL per field) → CSS block placement → responsive spec → project-specific QA checklist.
6. **Track progress** per step (Not Started → In Progress → Implemented → Verified / Needs Fix) with a `7 / 18 completed` indicator.
7. **Export** the guide as PDF / TXT / Markdown / JSON, the source CSS, an HTML reference, or a complete project ZIP.

Every import becomes a **version** (v1, v2, v3…) — open old versions any time, re-run analysis, export any version's guide.

## The locked profile (built in, read-only)

- **Stack:** Hello Elementor · Elementor Pro · ACF Free · Mayfair Core · Mayfair Forms & Leads
- **CPTs:** property, project, insight · **Taxonomies:** property-type, property-status, location (shared), project-type, insight-topic
- **35 ACF fields** (17 property / 9 project / 9 insight) — listed under *Architecture*
- **Mayfair Heritage design system:** 14 color tokens (#1A1A1A / #725B2F / #A68B5B…), Playfair Display + Inter, Architectural Sharp (2–4px radii), subtle motion — listed under *Design System*

Conflicting imported material is **flagged, never silently overwritten**: `Found: #0B192C → Expected: #1A1A1A → Recommendation: replace with locked token.`

## Demo content

Activation seeds **"DEMO — Property Card CSS"**: a realistic AI CSS import containing four deliberate problems (off-palette `#0B192C`, foreign font Montserrat, 12px radius, invented `mpd_amenities`). Open it to see a full analysis, conflict report, generated guide and step tracker. Safe to delete.

## Security highlights

Uploads are read into the database as inert text — never executed, never written to executable locations. PHP content is refused outright (paste and upload). ZIPs are inspected in memory with entry/size/ratio caps and path-traversal guards; PHP/JS entries are listed but never imported. Full details in `docs/SECURITY.md`.

## Install

Plugins → Add New → Upload Plugin → `mayfair-implementation-assistant.zip` → Install → Activate. Requires WordPress 6.0+, PHP 7.4+. The optional Elementor reference widget appears only when Elementor is active; the whole admin works without Elementor.

## Documentation

`docs/`: ARCHITECTURE.md · USER-GUIDE.md · ELEMENTOR-GUIDE.md · CSS-GUIDE.md · QA-GUIDE.md · SECURITY.md · demo-analysis.md (walkthrough of the seeded demo) · demo-implementation-guide.md (sample export)

## Status honesty

Generated and statically validated only: PHP lint on all 19 files, 48 functional tests on the analyzer/conflict/PDF engines in PHP CLI. **Not tested inside a live WordPress installation** — run `docs/QA-GUIDE.md` on staging first.
