<?php
/**
 * Uninstall handler. Project/analysis data is guidance material, not
 * business-critical leads — but we still never delete silently:
 * tables are removed only on explicit uninstall (this file runs only
 * when the user clicks Delete in the Plugins screen), and the option
 * guard below allows preserving data if 'mpia_keep_data' was set.
 *
 * @package Mayfair_Implementation_Assistant
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( get_option( 'mpia_keep_data' ) ) {
	return;
}

global $wpdb;

foreach ( array( 'projects', 'versions', 'assets', 'analysis', 'steps' ) as $mpia_suffix ) {
	$mpia_table = $wpdb->prefix . 'mayfair_impl_' . $mpia_suffix;
	$wpdb->query( "DROP TABLE IF EXISTS `{$mpia_table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- uninstall cleanup, trusted prefix + fixed suffix
}

delete_option( 'mpia_db_version' );
delete_option( 'mpia_demo_seeded' );
