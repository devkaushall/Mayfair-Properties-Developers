# Mayfair Forms & Leads

**Version 1.0.0 — Generated for manual installation. Not installed, activated, or tested on the live website.**

A self-contained form builder + submission database + lead dashboard + export system for Mayfair Properties & Developers. Built as a lightweight real-estate lead platform inside WordPress — not just a contact form.

## The core concept

> Build the form once → place it anywhere with Elementor → capture every submission into one independent database → manage it from one dashboard → export it in whatever format the business needs.

## What it does

- **Form Builder** (WP Admin → Mayfair Forms → Forms): create/edit/duplicate/delete/publish forms; 24 curated field types incl. Property/Project/Location/Type/Status/Bedrooms selectors, Budget Range, Consent, File Upload; per-field validation, conditional visibility (AND/OR), widths, privacy flags.
- **12 built-in real-estate templates** seeded on activation (General/Property/Project Enquiry, Site Visit, Buyer Requirement, Callback, Sell/Valuation, Home Loan, Rental, Investor, Channel Partner, Vendor) — all editable, never locked.
- **Automatic property/project context**: a form on a property page captures post ID, Property ID (`mpd_property_id` meta, ACF optional), title, URL, type, location, status, page URL and referrer as hidden metadata. Visitors never type the property name.
- **Independent submission database**: 5 custom tables via `$wpdb->prefix` + `dbDelta()`; leads survive plugin deactivation and (by default) even uninstall.
- **Lead dashboard**: overview cards (total/new/contacted/qualified/site visits/won/lost + today/week/month), inbox with filters + search, detail view with timeline, private notes, capability-gated assignment, configurable statuses.
- **Exports** (never require Elementor): CSV (UTF-8 + BOM), genuine XLSX (minimal OOXML via ZipArchive — not renamed CSV), JSON, PDF (dependency-free built-in writer), TXT/copy-paste; single/bulk/filtered/date-range/preset exports; config backup/restore.
- **Notifications**: `wp_mail()` admin + optional visitor emails, every attempt logged to the submission timeline; a failed email never loses the lead.
- **Webhook**: configurable https URL/method/headers (CRM/Sheets/Zapier/Make-ready, nothing hardcoded).
- **Anti-spam**: nonce, honeypot, signed timing check, rate limiting, server-side validation; `mpfl_extra_spam_check` filter ready for Turnstile/reCAPTCHA.
- **Privacy**: consent text + version + timestamp stored; IP stored as salted hash or not at all (raw IP never stored); "delete data on uninstall" default OFF.
- **Elementor**: `Mayfair Form` widget under a `Mayfair` category — form selection + presentation/style controls that default to Elementor Global Colors/Fonts. Also `[mayfair_form id="123"]` shortcode. Elementor is never required for the backend.

## What it does NOT touch

- CPTs (`property`, `project`, `insight`), taxonomies, ACF fields — read-only context detection only.
- No ACF Pro, no paid plugins, no React/Vue, no third-party services.

## Install

WordPress Admin → Plugins → Add New → Upload Plugin → `mayfair-forms-leads.zip` → Install → Activate. Tables are created and the 12 templates seeded on activation. See `docs/user-guide.md`.

## Requirements

WordPress 6.0+, PHP 7.4+ (8.x recommended). XLSX export needs the PHP `zip` extension (standard on almost all hosts); if absent the plugin returns a clear message directing you to CSV.

## Documentation

| File | Contents |
|---|---|
| `docs/user-guide.md` | Non-coder guide: forms, placement, inbox, exports |
| `docs/architecture.md` | Developer guide: classes, hooks, flow |
| `docs/database-schema.md` | Table definitions + relationships |
| `docs/elementor-widget.md` | Widget controls reference |
| `docs/exports.md` | Export formats, presets, fallbacks |
| `docs/security.md` | Security & privacy model |
| `docs/qa-checklist.md` | Static results + live test checklist |
| `docs/changelog.md` | Version history |
| `docs/samples/` | Sample CSV/XLSX/JSON/PDF/TXT export files |

## Status honesty

This plugin was **generated and statically validated only** (PHP lint on all 23 files, functional tests on the PDF/CSV/XLSX/conditional-logic engines outside WordPress). It has **not** run inside a live WordPress installation. Run through `docs/qa-checklist.md` on a staging site before production use.
