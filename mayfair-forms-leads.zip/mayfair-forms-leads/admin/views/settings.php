<?php
/**
 * Settings: notifications, privacy, anti-spam, statuses, webhook, uninstall.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpfl_set     = MPFL_Database::get_settings();
$mpfl_webhook = MPFL_Webhooks::config();
?>
<div class="wrap mpfl-wrap">
	<h1><?php esc_html_e( 'Mayfair Forms — Settings', 'mayfair-forms-leads' ); ?></h1>
	<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="save_settings">
		<?php wp_nonce_field( 'mpfl_admin_save_settings', '_mpflnonce' ); ?>

		<h2><?php esc_html_e( 'Email Notifications (wp_mail — SMTP configured separately)', 'mayfair-forms-leads' ); ?></h2>
		<table class="form-table">
			<tr><th><label for="mpfl-to"><?php esc_html_e( 'Notify To', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-to" type="email" class="regular-text" name="notify_to" value="<?php echo esc_attr( $mpfl_set['notify_to'] ); ?>"></td></tr>
			<tr><th><label for="mpfl-fromname"><?php esc_html_e( 'From Name', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-fromname" type="text" class="regular-text" name="notify_from_name" value="<?php echo esc_attr( $mpfl_set['notify_from_name'] ); ?>"></td></tr>
			<tr><th><label for="mpfl-fromemail"><?php esc_html_e( 'From Email', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-fromemail" type="email" class="regular-text" name="notify_from_email" value="<?php echo esc_attr( $mpfl_set['notify_from_email'] ); ?>"></td></tr>
			<tr><th><label for="mpfl-subject"><?php esc_html_e( 'Subject Template', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-subject" type="text" class="large-text" name="notify_subject" value="<?php echo esc_attr( $mpfl_set['notify_subject'] ); ?>">
				<p class="description"><?php esc_html_e( 'Placeholders: {form_name} {submission_id} {name}', 'mayfair-forms-leads' ); ?></p></td></tr>
			<tr><th><?php esc_html_e( 'Visitor Confirmation', 'mayfair-forms-leads' ); ?></th>
				<td><label><input type="checkbox" name="visitor_confirm" value="1" <?php checked( ! empty( $mpfl_set['visitor_confirm'] ) ); ?>> <?php esc_html_e( 'Send confirmation email to visitors (per-form setting must also be enabled)', 'mayfair-forms-leads' ); ?></label></td></tr>
		</table>

		<h2><?php esc_html_e( 'Privacy', 'mayfair-forms-leads' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'IP Storage', 'mayfair-forms-leads' ); ?></th>
				<td>
					<label><input type="radio" name="store_ip" value="hash" <?php checked( 'hash', $mpfl_set['store_ip'] ); ?>> <?php esc_html_e( 'Store salted hash only (default — raw IP is never stored)', 'mayfair-forms-leads' ); ?></label><br>
					<label><input type="radio" name="store_ip" value="off" <?php checked( 'off', $mpfl_set['store_ip'] ); ?>> <?php esc_html_e( 'Do not store any IP representation', 'mayfair-forms-leads' ); ?></label>
				</td></tr>
			<tr><th><label for="mpfl-consent"><?php esc_html_e( 'Consent Text', 'mayfair-forms-leads' ); ?></label></th>
				<td><textarea id="mpfl-consent" class="large-text" rows="2" name="consent_text"><?php echo esc_textarea( $mpfl_set['consent_text'] ); ?></textarea></td></tr>
			<tr><th><label for="mpfl-cver"><?php esc_html_e( 'Consent Version', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-cver" type="text" name="consent_version" value="<?php echo esc_attr( $mpfl_set['consent_version'] ); ?>">
				<p class="description"><?php esc_html_e( 'Bump this when the consent text changes; stored with each consenting submission.', 'mayfair-forms-leads' ); ?></p></td></tr>
			<tr><th><?php esc_html_e( 'Uninstall', 'mayfair-forms-leads' ); ?></th>
				<td><label><input type="checkbox" name="delete_on_uninstall" value="1" <?php checked( ! empty( $mpfl_set['delete_on_uninstall'] ) ); ?>> <?php esc_html_e( 'Delete ALL plugin data on uninstall (default OFF — leads survive uninstall)', 'mayfair-forms-leads' ); ?></label></td></tr>
		</table>

		<h2><?php esc_html_e( 'Anti-Spam', 'mayfair-forms-leads' ); ?></h2>
		<table class="form-table">
			<tr><th><label for="mpfl-rlmax"><?php esc_html_e( 'Rate Limit (submissions)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-rlmax" type="number" name="rate_limit_max" min="1" max="100" value="<?php echo esc_attr( $mpfl_set['rate_limit_max'] ); ?>">
					<?php esc_html_e( 'per', 'mayfair-forms-leads' ); ?>
					<input type="number" name="rate_limit_window" min="60" max="86400" value="<?php echo esc_attr( $mpfl_set['rate_limit_window'] ); ?>"> <?php esc_html_e( 'seconds', 'mayfair-forms-leads' ); ?></td></tr>
			<tr><th><label for="mpfl-mins"><?php esc_html_e( 'Minimum Fill Time (seconds)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-mins" type="number" name="min_submit_seconds" min="0" max="60" value="<?php echo esc_attr( $mpfl_set['min_submit_seconds'] ); ?>"></td></tr>
			<tr><th><label for="mpfl-upmax"><?php esc_html_e( 'Max Upload Size (MB)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-upmax" type="number" name="upload_max_mb" min="1" max="64" value="<?php echo esc_attr( $mpfl_set['upload_max_mb'] ); ?>"></td></tr>
		</table>
		<p class="description"><?php esc_html_e( 'Honeypot, nonce and timing checks are always on. Cloudflare Turnstile / reCAPTCHA can be added later via the mpfl_extra_spam_check filter.', 'mayfair-forms-leads' ); ?></p>

		<h2><?php esc_html_e( 'Custom Lead Statuses', 'mayfair-forms-leads' ); ?></h2>
		<table class="form-table">
			<tr><th><label for="mpfl-statuses"><?php esc_html_e( 'Additional statuses (one per line)', 'mayfair-forms-leads' ); ?></label></th>
				<td><textarea id="mpfl-statuses" name="custom_statuses" rows="3" class="regular-text" placeholder="<?php esc_attr_e( "e.g.\nNegotiating\nToken Received", 'mayfair-forms-leads' ); ?>"></textarea>
				<p class="description"><?php esc_html_e( 'Default statuses always remain available.', 'mayfair-forms-leads' ); ?></p></td></tr>
		</table>

		<h2><?php esc_html_e( 'Webhook (CRM / Sheets / Zapier / Make — no service hardcoded)', 'mayfair-forms-leads' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'Enabled', 'mayfair-forms-leads' ); ?></th>
				<td><label><input type="checkbox" name="webhook_enabled" value="1" <?php checked( ! empty( $mpfl_webhook['enabled'] ) ); ?>> <?php esc_html_e( 'Send submissions to webhook (also enable per form)', 'mayfair-forms-leads' ); ?></label></td></tr>
			<tr><th><label for="mpfl-whurl"><?php esc_html_e( 'Webhook URL (https only)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-whurl" type="url" class="large-text" name="webhook_url" value="<?php echo esc_attr( $mpfl_webhook['url'] ); ?>" placeholder="https://"></td></tr>
		</table>

		<?php submit_button( __( 'Save Settings', 'mayfair-forms-leads' ) ); ?>
	</form>
</div>
