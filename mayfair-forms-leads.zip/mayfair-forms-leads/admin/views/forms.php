<?php
/**
 * Forms list + form editor (fields).
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpfl_edit_id = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- routing only
?>
<div class="wrap mpfl-wrap">
<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
	<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
<?php endif; ?>

<?php if ( $mpfl_edit_id ) : ?>
	<?php
	$mpfl_form   = MPFL_Form_Builder::get_form( $mpfl_edit_id );
	$mpfl_fields = MPFL_Form_Builder::get_fields( $mpfl_edit_id );
	if ( ! $mpfl_form ) {
		echo '<p>' . esc_html__( 'Form not found.', 'mayfair-forms-leads' ) . '</p></div>';
		return;
	}
	$mpfl_settings = json_decode( (string) $mpfl_form['settings'], true );
	$mpfl_settings = is_array( $mpfl_settings ) ? $mpfl_settings : array();
	?>
	<h1><?php echo esc_html( sprintf( /* translators: %s form name */ __( 'Edit Form: %s', 'mayfair-forms-leads' ), $mpfl_form['name'] ) ); ?></h1>
	<p>
		<code>[mayfair_form id="<?php echo esc_attr( $mpfl_form['id'] ); ?>"]</code>
		— <?php esc_html_e( 'or select this form in the Mayfair Form Elementor widget.', 'mayfair-forms-leads' ); ?>
		<?php esc_html_e( 'Version:', 'mayfair-forms-leads' ); ?> <?php echo esc_html( $mpfl_form['version'] ); ?> ·
		<?php esc_html_e( 'Created:', 'mayfair-forms-leads' ); ?> <?php echo esc_html( $mpfl_form['created_at'] ); ?> ·
		<?php esc_html_e( 'Modified:', 'mayfair-forms-leads' ); ?> <?php echo esc_html( $mpfl_form['updated_at'] ); ?>
	</p>

	<h2><?php esc_html_e( 'Form Settings', 'mayfair-forms-leads' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="update_form">
		<input type="hidden" name="form_id" value="<?php echo esc_attr( $mpfl_form['id'] ); ?>">
		<?php wp_nonce_field( 'mpfl_admin_update_form', '_mpflnonce' ); ?>
		<table class="form-table">
			<tr><th><label for="mpfl-name"><?php esc_html_e( 'Form Name', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-name" class="regular-text" type="text" name="name" value="<?php echo esc_attr( $mpfl_form['name'] ); ?>"></td></tr>
			<tr><th><label for="mpfl-desc"><?php esc_html_e( 'Internal Description', 'mayfair-forms-leads' ); ?></label></th>
				<td><textarea id="mpfl-desc" class="large-text" rows="2" name="description"><?php echo esc_textarea( $mpfl_form['description'] ); ?></textarea></td></tr>
			<tr><th><label for="mpfl-status"><?php esc_html_e( 'Status', 'mayfair-forms-leads' ); ?></label></th>
				<td><select id="mpfl-status" name="status">
					<?php foreach ( array( 'draft' => __( 'Draft', 'mayfair-forms-leads' ), 'published' => __( 'Published', 'mayfair-forms-leads' ), 'inactive' => __( 'Inactive', 'mayfair-forms-leads' ) ) as $mpfl_s => $mpfl_l ) : ?>
						<option value="<?php echo esc_attr( $mpfl_s ); ?>" <?php selected( $mpfl_form['status'], $mpfl_s ); ?>><?php echo esc_html( $mpfl_l ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><label for="mpfl-success"><?php esc_html_e( 'Success Message', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-success" class="large-text" type="text" name="settings[success_message]" value="<?php echo esc_attr( isset( $mpfl_settings['success_message'] ) ? $mpfl_settings['success_message'] : '' ); ?>"></td></tr>
			<tr><th><label for="mpfl-redirect"><?php esc_html_e( 'Redirect URL (optional)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-redirect" class="large-text" type="url" name="settings[redirect_url]" value="<?php echo esc_attr( isset( $mpfl_settings['redirect_url'] ) ? $mpfl_settings['redirect_url'] : '' ); ?>"></td></tr>
			<tr><th><label for="mpfl-button"><?php esc_html_e( 'Button Text', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-button" type="text" name="settings[button_text]" value="<?php echo esc_attr( isset( $mpfl_settings['button_text'] ) ? $mpfl_settings['button_text'] : 'Submit' ); ?>"></td></tr>
			<tr><th><?php esc_html_e( 'Notifications', 'mayfair-forms-leads' ); ?></th>
				<td>
					<label><input type="checkbox" name="settings[notify_admin]" value="1" <?php checked( ! empty( $mpfl_settings['notify_admin'] ) ); ?>> <?php esc_html_e( 'Email admin on submission', 'mayfair-forms-leads' ); ?></label><br>
					<label><input type="checkbox" name="settings[notify_visitor]" value="1" <?php checked( ! empty( $mpfl_settings['notify_visitor'] ) ); ?>> <?php esc_html_e( 'Send visitor confirmation', 'mayfair-forms-leads' ); ?></label><br>
					<label><input type="checkbox" name="settings[webhook_enabled]" value="1" <?php checked( ! empty( $mpfl_settings['webhook_enabled'] ) ); ?>> <?php esc_html_e( 'Send to webhook (configure in Settings)', 'mayfair-forms-leads' ); ?></label>
				</td></tr>
		</table>
		<?php submit_button( __( 'Save Form', 'mayfair-forms-leads' ) ); ?>
	</form>

	<h2><?php esc_html_e( 'Fields', 'mayfair-forms-leads' ); ?></h2>
	<table class="widefat striped">
		<thead><tr>
			<th><?php esc_html_e( 'Order', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Label', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Key', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Type', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Required', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Width', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Actions', 'mayfair-forms-leads' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( $mpfl_fields as $mpfl_f ) : ?>
			<tr>
				<td><?php echo esc_html( $mpfl_f['sort_order'] ); ?></td>
				<td><?php echo esc_html( $mpfl_f['label'] ); ?></td>
				<td><code><?php echo esc_html( $mpfl_f['field_key'] ); ?></code></td>
				<td><?php echo esc_html( $mpfl_f['field_type'] ); ?></td>
				<td><?php echo $mpfl_f['required'] ? '&#10003;' : '—'; ?></td>
				<td><?php echo esc_html( $mpfl_f['width'] ); ?>%</td>
				<td>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="delete_field">
						<input type="hidden" name="field_id" value="<?php echo esc_attr( $mpfl_f['id'] ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_delete_field', '_mpflnonce' ); ?>
						<button type="submit" class="button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this field?', 'mayfair-forms-leads' ) ); ?>');"><?php esc_html_e( 'Delete', 'mayfair-forms-leads' ); ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<h3><?php esc_html_e( 'Add Field', 'mayfair-forms-leads' ); ?></h3>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="add_field">
		<input type="hidden" name="form_id" value="<?php echo esc_attr( $mpfl_form['id'] ); ?>">
		<?php wp_nonce_field( 'mpfl_admin_add_field', '_mpflnonce' ); ?>
		<table class="form-table">
			<tr><th><label for="mpfl-ftype"><?php esc_html_e( 'Type', 'mayfair-forms-leads' ); ?></label></th>
				<td><select id="mpfl-ftype" name="field_type">
					<?php foreach ( MPFL_Form_Builder::field_types() as $mpfl_t => $mpfl_tl ) : ?>
						<option value="<?php echo esc_attr( $mpfl_t ); ?>"><?php echo esc_html( $mpfl_tl ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><label for="mpfl-flabel"><?php esc_html_e( 'Label', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-flabel" type="text" name="label" class="regular-text"></td></tr>
			<tr><th><label for="mpfl-fkey"><?php esc_html_e( 'Field Key (optional)', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-fkey" type="text" name="field_key" class="regular-text" placeholder="auto"></td></tr>
			<tr><th><label for="mpfl-fph"><?php esc_html_e( 'Placeholder', 'mayfair-forms-leads' ); ?></label></th>
				<td><input id="mpfl-fph" type="text" name="placeholder" class="regular-text"></td></tr>
			<tr><th><label for="mpfl-fopts"><?php esc_html_e( 'Options (one per line, for select/radio/checkbox group)', 'mayfair-forms-leads' ); ?></label></th>
				<td><textarea id="mpfl-fopts" name="options" rows="3" class="large-text"></textarea></td></tr>
			<tr><th><label for="mpfl-fwidth"><?php esc_html_e( 'Width', 'mayfair-forms-leads' ); ?></label></th>
				<td><select id="mpfl-fwidth" name="width">
					<?php foreach ( array( '100', '75', '66', '50', '33', '25' ) as $mpfl_w ) : ?>
						<option value="<?php echo esc_attr( $mpfl_w ); ?>"><?php echo esc_html( $mpfl_w ); ?>%</option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Flags', 'mayfair-forms-leads' ); ?></th>
				<td>
					<label><input type="checkbox" name="required" value="1"> <?php esc_html_e( 'Required', 'mayfair-forms-leads' ); ?></label>&nbsp;&nbsp;
					<label><input type="checkbox" name="admin_only" value="1"> <?php esc_html_e( 'Admin only', 'mayfair-forms-leads' ); ?></label>&nbsp;&nbsp;
					<label><input type="checkbox" name="privacy_flag" value="1"> <?php esc_html_e( 'Privacy-sensitive', 'mayfair-forms-leads' ); ?></label>
				</td></tr>
		</table>
		<?php submit_button( __( 'Add Field', 'mayfair-forms-leads' ), 'secondary' ); ?>
	</form>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpfl-forms' ) ); ?>">&larr; <?php esc_html_e( 'Back to all forms', 'mayfair-forms-leads' ); ?></a></p>

<?php else : ?>
	<h1><?php esc_html_e( 'Forms', 'mayfair-forms-leads' ); ?></h1>

	<h2><?php esc_html_e( 'Create New Form', 'mayfair-forms-leads' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:24px;">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="create_form">
		<?php wp_nonce_field( 'mpfl_admin_create_form', '_mpflnonce' ); ?>
		<input type="text" name="name" placeholder="<?php esc_attr_e( 'Form name', 'mayfair-forms-leads' ); ?>" class="regular-text" required>
		<?php submit_button( __( 'Create Form', 'mayfair-forms-leads' ), 'primary', 'submit', false ); ?>
	</form>

	<table class="widefat striped">
		<thead><tr>
			<th><?php esc_html_e( 'ID', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Name', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Type', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Status', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Shortcode', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Modified', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Actions', 'mayfair-forms-leads' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( MPFL_Form_Builder::get_forms() as $mpfl_form ) : ?>
			<tr>
				<td><?php echo esc_html( $mpfl_form['id'] ); ?></td>
				<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpfl-forms&edit=' . (int) $mpfl_form['id'] ) ); ?>"><?php echo esc_html( $mpfl_form['name'] ); ?></a></strong></td>
				<td><?php echo esc_html( $mpfl_form['form_type'] ); ?></td>
				<td><span class="mpfl-badge mpfl-badge--<?php echo esc_attr( $mpfl_form['status'] ); ?>"><?php echo esc_html( ucfirst( $mpfl_form['status'] ) ); ?></span></td>
				<td><code>[mayfair_form id="<?php echo esc_attr( $mpfl_form['id'] ); ?>"]</code></td>
				<td><?php echo esc_html( $mpfl_form['updated_at'] ); ?></td>
				<td>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="duplicate_form">
						<input type="hidden" name="form_id" value="<?php echo esc_attr( $mpfl_form['id'] ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_duplicate_form', '_mpflnonce' ); ?>
						<button type="submit" class="button-link"><?php esc_html_e( 'Duplicate', 'mayfair-forms-leads' ); ?></button>
					</form> |
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="delete_form">
						<input type="hidden" name="form_id" value="<?php echo esc_attr( $mpfl_form['id'] ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_delete_form', '_mpflnonce' ); ?>
						<button type="submit" class="button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this form? Its submissions are preserved.', 'mayfair-forms-leads' ) ); ?>');"><?php esc_html_e( 'Delete', 'mayfair-forms-leads' ); ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>
</div>
