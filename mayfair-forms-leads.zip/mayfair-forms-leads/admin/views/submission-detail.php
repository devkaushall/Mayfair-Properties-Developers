<?php
/**
 * Single submission detail: lead info, context, answers, source, consent,
 * timeline, notes, status change, assignment, single exports.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpfl_id = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mpfl_s  = MPFL_Submissions::get( $mpfl_id );
if ( ! $mpfl_s ) {
	echo '<div class="wrap"><p>' . esc_html__( 'Submission not found.', 'mayfair-forms-leads' ) . '</p></div>';
	return;
}
$mpfl_values   = MPFL_Submissions::get_values( $mpfl_id );
$mpfl_timeline = MPFL_Leads::timeline( $mpfl_id );
$mpfl_statuses = MPFL_Leads::statuses();
$mpfl_txt      = MPFL_Exports::build_txt_single( $mpfl_id );
?>
<div class="wrap mpfl-wrap">
	<h1><?php echo esc_html( sprintf( /* translators: %d id */ __( 'Submission #%d', 'mayfair-forms-leads' ), $mpfl_id ) ); ?>
		<span class="mpfl-badge mpfl-badge--<?php echo esc_attr( $mpfl_s['status'] ); ?>"><?php echo esc_html( MPFL_Leads::status_label( $mpfl_s['status'] ) ); ?></span>
	</h1>
	<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<div class="mpfl-detail-grid">
		<div>
			<h2><?php esc_html_e( 'Lead', 'mayfair-forms-leads' ); ?></h2>
			<table class="widefat striped">
				<tr><th><?php esc_html_e( 'Name', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['name'] ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Phone', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['phone'] ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Email', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['email'] ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Form', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['form_name'] ); ?> (#<?php echo esc_html( $mpfl_s['form_id'] ); ?>)</td></tr>
				<tr><th><?php esc_html_e( 'Date', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( mysql2date( 'j F Y, H:i', $mpfl_s['created_at'] ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Lead Type', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['lead_type'] ? $mpfl_s['lead_type'] : '—' ); ?></td></tr>
			</table>

			<?php if ( $mpfl_s['property_post_id'] || $mpfl_s['project_post_id'] || $mpfl_s['property_id'] ) : ?>
				<h2><?php esc_html_e( 'Property / Project Context', 'mayfair-forms-leads' ); ?></h2>
				<table class="widefat striped">
					<?php if ( $mpfl_s['property_post_id'] ) : ?>
						<tr><th><?php esc_html_e( 'Property', 'mayfair-forms-leads' ); ?></th>
							<td><a href="<?php echo esc_url( get_permalink( (int) $mpfl_s['property_post_id'] ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_the_title( (int) $mpfl_s['property_post_id'] ) ); ?></a></td></tr>
					<?php endif; ?>
					<?php if ( $mpfl_s['property_id'] ) : ?>
						<tr><th><?php esc_html_e( 'Property Ref', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['property_id'] ); ?></td></tr>
					<?php endif; ?>
					<?php if ( $mpfl_s['project_post_id'] ) : ?>
						<tr><th><?php esc_html_e( 'Project', 'mayfair-forms-leads' ); ?></th>
							<td><a href="<?php echo esc_url( get_permalink( (int) $mpfl_s['project_post_id'] ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_the_title( (int) $mpfl_s['project_post_id'] ) ); ?></a></td></tr>
					<?php endif; ?>
				</table>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Submitted Fields', 'mayfair-forms-leads' ); ?></h2>
			<table class="widefat striped">
				<?php foreach ( $mpfl_values as $mpfl_v ) : ?>
					<?php if ( 0 === strpos( $mpfl_v['field_key'], '_ctx_' ) ) { continue; } ?>
					<tr>
						<th><?php echo esc_html( $mpfl_v['field_label'] ? $mpfl_v['field_label'] : $mpfl_v['field_key'] ); ?></th>
						<td>
						<?php
						if ( 'file' === $mpfl_v['field_type'] ) {
							$mpfl_meta = json_decode( (string) $mpfl_v['value'], true );
							if ( is_array( $mpfl_meta ) && ! empty( $mpfl_meta['url'] ) && current_user_can( 'view_mayfair_leads' ) ) {
								echo '<a href="' . esc_url( $mpfl_meta['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $mpfl_meta['name'] ) . '</a> (' . esc_html( size_format( (int) $mpfl_meta['size'] ) ) . ')';
							}
						} else {
							$mpfl_dec = json_decode( (string) $mpfl_v['value'], true );
							echo esc_html( is_array( $mpfl_dec ) ? implode( ', ', $mpfl_dec ) : $mpfl_v['value'] );
						}
						?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>

			<h2><?php esc_html_e( 'Source Attribution', 'mayfair-forms-leads' ); ?></h2>
			<table class="widefat striped">
				<tr><th><?php esc_html_e( 'Source', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['source'] ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Page', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['page_url'] ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Referrer', 'mayfair-forms-leads' ); ?></th><td><?php echo esc_html( $mpfl_s['referrer'] ? $mpfl_s['referrer'] : '—' ); ?></td></tr>
				<tr><th>UTM</th><td><?php echo esc_html( trim( $mpfl_s['utm_source'] . ' / ' . $mpfl_s['utm_medium'] . ' / ' . $mpfl_s['utm_campaign'], ' /' ) ); ?></td></tr>
				<tr><th><?php esc_html_e( 'Consent', 'mayfair-forms-leads' ); ?></th>
					<td><?php echo $mpfl_s['consent_state'] ? esc_html( sprintf( /* translators: 1 version, 2 time */ __( 'Given — v%1$s at %2$s', 'mayfair-forms-leads' ), $mpfl_s['consent_version'], $mpfl_s['consent_at'] ) ) : esc_html__( 'Not given', 'mayfair-forms-leads' ); ?></td></tr>
			</table>

			<h2><?php esc_html_e( 'Copy Full Submission', 'mayfair-forms-leads' ); ?></h2>
			<textarea readonly rows="10" style="width:100%;font-family:monospace;" onclick="this.select();"><?php echo esc_textarea( is_wp_error( $mpfl_txt ) ? '' : $mpfl_txt ); ?></textarea>
		</div>

		<div>
			<?php if ( current_user_can( 'edit_mayfair_leads' ) ) : ?>
				<h2><?php esc_html_e( 'Status', 'mayfair-forms-leads' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="mpfl_admin_action">
					<input type="hidden" name="mpfl_task" value="set_status">
					<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
					<?php wp_nonce_field( 'mpfl_admin_set_status', '_mpflnonce' ); ?>
					<select name="status">
						<?php foreach ( $mpfl_statuses as $mpfl_k => $mpfl_l ) : ?>
							<option value="<?php echo esc_attr( $mpfl_k ); ?>" <?php selected( $mpfl_s['status'], $mpfl_k ); ?>><?php echo esc_html( $mpfl_l ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php submit_button( __( 'Update', 'mayfair-forms-leads' ), 'secondary', 'submit', false ); ?>
				</form>

				<h2><?php esc_html_e( 'Assign', 'mayfair-forms-leads' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="mpfl_admin_action">
					<input type="hidden" name="mpfl_task" value="assign">
					<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
					<?php wp_nonce_field( 'mpfl_admin_assign', '_mpflnonce' ); ?>
					<select name="user_id">
						<option value="0"><?php esc_html_e( '— Unassigned —', 'mayfair-forms-leads' ); ?></option>
						<?php foreach ( MPFL_Leads::assignable_users() as $mpfl_u ) : ?>
							<option value="<?php echo esc_attr( $mpfl_u->ID ); ?>" <?php selected( (int) $mpfl_s['assigned_user'], (int) $mpfl_u->ID ); ?>><?php echo esc_html( $mpfl_u->display_name ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php submit_button( __( 'Assign', 'mayfair-forms-leads' ), 'secondary', 'submit', false ); ?>
				</form>

				<h2><?php esc_html_e( 'Add Internal Note', 'mayfair-forms-leads' ); ?></h2>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="mpfl_admin_action">
					<input type="hidden" name="mpfl_task" value="add_note">
					<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
					<?php wp_nonce_field( 'mpfl_admin_add_note', '_mpflnonce' ); ?>
					<textarea name="note" rows="3" style="width:100%;" placeholder="<?php esc_attr_e( 'Private note — never visible to the visitor', 'mayfair-forms-leads' ); ?>"></textarea>
					<?php submit_button( __( 'Add Note', 'mayfair-forms-leads' ), 'secondary', 'submit', false ); ?>
				</form>
			<?php endif; ?>

			<?php if ( current_user_can( 'export_mayfair_leads' ) ) : ?>
				<h2><?php esc_html_e( 'Export This Submission', 'mayfair-forms-leads' ); ?></h2>
				<?php foreach ( array( 'txt' => 'TXT', 'json' => 'JSON', 'pdf' => 'PDF' ) as $mpfl_fmt => $mpfl_fl ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="export">
						<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
						<input type="hidden" name="format" value="<?php echo esc_attr( $mpfl_fmt ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_export', '_mpflnonce' ); ?>
						<button type="submit" class="button"><?php echo esc_html( $mpfl_fl ); ?></button>
					</form>
				<?php endforeach; ?>
			<?php endif; ?>

			<?php if ( current_user_can( 'edit_mayfair_leads' ) || current_user_can( 'delete_mayfair_leads' ) ) : ?>
				<h2><?php esc_html_e( 'Danger Zone', 'mayfair-forms-leads' ); ?></h2>
				<?php if ( current_user_can( 'edit_mayfair_leads' ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="mark_spam">
						<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_mark_spam', '_mpflnonce' ); ?>
						<button type="submit" class="button"><?php esc_html_e( 'Mark Spam', 'mayfair-forms-leads' ); ?></button>
					</form>
				<?php endif; ?>
				<?php if ( current_user_can( 'delete_mayfair_leads' ) ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpfl_admin_action">
						<input type="hidden" name="mpfl_task" value="delete_submission">
						<input type="hidden" name="submission_id" value="<?php echo esc_attr( $mpfl_id ); ?>">
						<?php wp_nonce_field( 'mpfl_admin_delete_submission', '_mpflnonce' ); ?>
						<button type="submit" class="button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Permanently delete this submission?', 'mayfair-forms-leads' ) ); ?>');"><?php esc_html_e( 'Delete', 'mayfair-forms-leads' ); ?></button>
					</form>
				<?php endif; ?>
			<?php endif; ?>

			<h2><?php esc_html_e( 'Timeline', 'mayfair-forms-leads' ); ?></h2>
			<ul class="mpfl-timeline">
				<?php foreach ( $mpfl_timeline as $mpfl_e ) : ?>
					<?php $mpfl_ed = json_decode( (string) $mpfl_e['event_data'], true ); ?>
					<li>
						<span class="mpfl-timeline__time"><?php echo esc_html( mysql2date( 'j M Y H:i', $mpfl_e['created_at'] ) ); ?></span>
						<strong><?php echo esc_html( ucwords( str_replace( '_', ' ', $mpfl_e['event_type'] ) ) ); ?></strong>
						<?php if ( 'note_added' === $mpfl_e['event_type'] && isset( $mpfl_ed['note'] ) ) : ?>
							<em>— <?php echo esc_html( $mpfl_ed['note'] ); ?></em>
						<?php elseif ( 'status_changed' === $mpfl_e['event_type'] && isset( $mpfl_ed['to'] ) ) : ?>
							<em>— <?php echo esc_html( ( isset( $mpfl_ed['from'] ) ? $mpfl_ed['from'] . ' → ' : '' ) . $mpfl_ed['to'] ); ?></em>
						<?php elseif ( isset( $mpfl_ed['result'] ) ) : ?>
							<em>— <?php echo esc_html( $mpfl_ed['result'] ); ?></em>
						<?php endif; ?>
						<?php if ( $mpfl_e['user_id'] ) : ?>
							<span class="mpfl-timeline__user"><?php echo esc_html( get_the_author_meta( 'display_name', (int) $mpfl_e['user_id'] ) ); ?></span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
	<p><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpfl-submissions' ) ); ?>">&larr; <?php esc_html_e( 'Back to submissions', 'mayfair-forms-leads' ); ?></a></p>
</div>
