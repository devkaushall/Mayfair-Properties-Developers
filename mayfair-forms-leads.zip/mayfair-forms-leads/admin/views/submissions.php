<?php
/**
 * Submission inbox: table + filters + search + bulk-ish actions.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET filters are read-only list criteria
$mpfl_filters = array(
	'form_id'          => isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0,
	'status'           => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
	'source'           => isset( $_GET['source'] ) ? sanitize_key( wp_unslash( $_GET['source'] ) ) : '',
	'property_post_id' => isset( $_GET['property_post_id'] ) ? (int) $_GET['property_post_id'] : 0,
	'project_post_id'  => isset( $_GET['project_post_id'] ) ? (int) $_GET['project_post_id'] : 0,
	'assigned_user'    => isset( $_GET['assigned_user'] ) ? (int) $_GET['assigned_user'] : 0,
	'date_from'        => isset( $_GET['date_from'] ) ? sanitize_text_field( wp_unslash( $_GET['date_from'] ) ) : '',
	'date_to'          => isset( $_GET['date_to'] ) ? sanitize_text_field( wp_unslash( $_GET['date_to'] ) ) : '',
	'search'           => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
	'page'             => isset( $_GET['paged'] ) ? (int) $_GET['paged'] : 1,
);
// phpcs:enable

$mpfl_result   = MPFL_Submissions::query( $mpfl_filters );
$mpfl_statuses = MPFL_Leads::statuses();
$mpfl_sources  = MPFL_Leads::source_labels();
?>
<div class="wrap mpfl-wrap">
	<h1><?php esc_html_e( 'Submissions', 'mayfair-forms-leads' ); ?></h1>
	<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<form method="get" class="mpfl-filterbar">
		<input type="hidden" name="page" value="mpfl-submissions">
		<select name="form_id">
			<option value=""><?php esc_html_e( 'All Forms', 'mayfair-forms-leads' ); ?></option>
			<?php foreach ( MPFL_Form_Builder::get_forms() as $mpfl_f ) : ?>
				<option value="<?php echo esc_attr( $mpfl_f['id'] ); ?>" <?php selected( $mpfl_filters['form_id'], (int) $mpfl_f['id'] ); ?>><?php echo esc_html( $mpfl_f['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="status">
			<option value=""><?php esc_html_e( 'All Statuses', 'mayfair-forms-leads' ); ?></option>
			<?php foreach ( $mpfl_statuses as $mpfl_k => $mpfl_l ) : ?>
				<option value="<?php echo esc_attr( $mpfl_k ); ?>" <?php selected( $mpfl_filters['status'], $mpfl_k ); ?>><?php echo esc_html( $mpfl_l ); ?></option>
			<?php endforeach; ?>
		</select>
		<select name="source">
			<option value=""><?php esc_html_e( 'All Sources', 'mayfair-forms-leads' ); ?></option>
			<?php foreach ( $mpfl_sources as $mpfl_k => $mpfl_l ) : ?>
				<option value="<?php echo esc_attr( $mpfl_k ); ?>" <?php selected( $mpfl_filters['source'], $mpfl_k ); ?>><?php echo esc_html( $mpfl_l ); ?></option>
			<?php endforeach; ?>
		</select>
		<input type="date" name="date_from" value="<?php echo esc_attr( $mpfl_filters['date_from'] ); ?>">
		<input type="date" name="date_to" value="<?php echo esc_attr( $mpfl_filters['date_to'] ); ?>">
		<input type="search" name="s" placeholder="<?php esc_attr_e( 'Search name/email/phone…', 'mayfair-forms-leads' ); ?>" value="<?php echo esc_attr( $mpfl_filters['search'] ); ?>">
		<?php submit_button( __( 'Filter', 'mayfair-forms-leads' ), 'secondary', 'submit', false ); ?>
	</form>

	<p><?php echo esc_html( sprintf( /* translators: %d count */ __( '%d submissions found.', 'mayfair-forms-leads' ), $mpfl_result['total'] ) ); ?></p>

	<table class="widefat striped">
		<thead><tr>
			<th>ID</th>
			<th><?php esc_html_e( 'Date', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Name', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Phone', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Email', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Form', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Property', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Status', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Source', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Assigned', 'mayfair-forms-leads' ); ?></th>
			<th><?php esc_html_e( 'Actions', 'mayfair-forms-leads' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( $mpfl_result['rows'] as $mpfl_s ) : ?>
			<tr>
				<td><?php echo esc_html( $mpfl_s['id'] ); ?></td>
				<td><?php echo esc_html( mysql2date( 'j M Y H:i', $mpfl_s['created_at'] ) ); ?></td>
				<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpfl-submissions&view=' . (int) $mpfl_s['id'] ) ); ?>"><?php echo esc_html( $mpfl_s['name'] ? $mpfl_s['name'] : '—' ); ?></a></strong></td>
				<td><?php echo esc_html( $mpfl_s['phone'] ); ?></td>
				<td><?php echo esc_html( $mpfl_s['email'] ); ?></td>
				<td><?php echo esc_html( $mpfl_s['form_name'] ); ?></td>
				<td><?php echo esc_html( $mpfl_s['property_post_id'] ? get_the_title( (int) $mpfl_s['property_post_id'] ) : ( $mpfl_s['project_post_id'] ? get_the_title( (int) $mpfl_s['project_post_id'] ) . ' (project)' : '—' ) ); ?></td>
				<td><span class="mpfl-badge mpfl-badge--<?php echo esc_attr( $mpfl_s['status'] ); ?>"><?php echo esc_html( MPFL_Leads::status_label( $mpfl_s['status'] ) ); ?></span></td>
				<td><?php echo esc_html( isset( $mpfl_sources[ $mpfl_s['source'] ] ) ? $mpfl_sources[ $mpfl_s['source'] ] : $mpfl_s['source'] ); ?></td>
				<td><?php echo esc_html( $mpfl_s['assigned_user'] ? get_the_author_meta( 'display_name', (int) $mpfl_s['assigned_user'] ) : '—' ); ?></td>
				<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpfl-submissions&view=' . (int) $mpfl_s['id'] ) ); ?>"><?php esc_html_e( 'View', 'mayfair-forms-leads' ); ?></a></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( empty( $mpfl_result['rows'] ) ) : ?>
			<tr><td colspan="11"><?php esc_html_e( 'No submissions match these filters.', 'mayfair-forms-leads' ); ?></td></tr>
		<?php endif; ?>
		</tbody>
	</table>

	<?php
	$mpfl_pages = (int) ceil( $mpfl_result['total'] / $mpfl_result['per_page'] );
	if ( $mpfl_pages > 1 ) :
		?>
		<p class="mpfl-pager">
		<?php for ( $mpfl_i = 1; $mpfl_i <= $mpfl_pages; $mpfl_i++ ) : ?>
			<?php if ( $mpfl_i === $mpfl_result['page'] ) : ?>
				<strong><?php echo esc_html( $mpfl_i ); ?></strong>
			<?php else : ?>
				<a href="<?php echo esc_url( add_query_arg( 'paged', $mpfl_i ) ); ?>"><?php echo esc_html( $mpfl_i ); ?></a>
			<?php endif; ?>
		<?php endfor; ?>
		</p>
	<?php endif; ?>
</div>
