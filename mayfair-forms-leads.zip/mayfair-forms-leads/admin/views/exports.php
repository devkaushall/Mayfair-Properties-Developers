<?php
/**
 * Exports page: bulk/filtered exports in all formats + config backup/restore.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpfl_statuses = MPFL_Leads::statuses();
$mpfl_presets  = MPFL_Exports::presets();
?>
<div class="wrap mpfl-wrap">
	<h1><?php esc_html_e( 'Exports', 'mayfair-forms-leads' ); ?></h1>
	<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<h2><?php esc_html_e( 'Bulk / Filtered Export', 'mayfair-forms-leads' ); ?></h2>
	<p class="description"><?php esc_html_e( 'Data is stored centrally; exports are generated on demand. No files are created automatically per submission.', 'mayfair-forms-leads' ); ?></p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="export">
		<?php wp_nonce_field( 'mpfl_admin_export', '_mpflnonce' ); ?>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'Format', 'mayfair-forms-leads' ); ?></th>
				<td><select name="format">
					<option value="csv">CSV (UTF-8 + BOM)</option>
					<option value="xlsx">XLSX (genuine Excel OOXML)</option>
					<option value="json">JSON</option>
				</select>
				<p class="description"><?php esc_html_e( 'PDF and TXT are per-submission formats — open a submission to export those.', 'mayfair-forms-leads' ); ?></p></td></tr>
			<tr><th><?php esc_html_e( 'Preset', 'mayfair-forms-leads' ); ?></th>
				<td><select name="preset">
					<?php foreach ( $mpfl_presets as $mpfl_k => $mpfl_p ) : ?>
						<option value="<?php echo esc_attr( $mpfl_k ); ?>"><?php echo esc_html( $mpfl_p['label'] ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Form', 'mayfair-forms-leads' ); ?></th>
				<td><select name="form_id">
					<option value=""><?php esc_html_e( 'All Forms', 'mayfair-forms-leads' ); ?></option>
					<?php foreach ( MPFL_Form_Builder::get_forms() as $mpfl_f ) : ?>
						<option value="<?php echo esc_attr( $mpfl_f['id'] ); ?>"><?php echo esc_html( $mpfl_f['name'] ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Status', 'mayfair-forms-leads' ); ?></th>
				<td><select name="status">
					<option value=""><?php esc_html_e( 'All Statuses', 'mayfair-forms-leads' ); ?></option>
					<?php foreach ( $mpfl_statuses as $mpfl_k => $mpfl_l ) : ?>
						<option value="<?php echo esc_attr( $mpfl_k ); ?>"><?php echo esc_html( $mpfl_l ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><?php esc_html_e( 'Date Range', 'mayfair-forms-leads' ); ?></th>
				<td><input type="date" name="date_from"> — <input type="date" name="date_to"></td></tr>
			<tr><th><?php esc_html_e( 'Property (post ID)', 'mayfair-forms-leads' ); ?></th>
				<td><input type="number" name="property_post_id" min="0" placeholder="<?php esc_attr_e( 'optional', 'mayfair-forms-leads' ); ?>"></td></tr>
		</table>
		<?php submit_button( __( 'Generate Export', 'mayfair-forms-leads' ) ); ?>
	</form>

	<hr>
	<h2><?php esc_html_e( 'Configuration Backup / Restore', 'mayfair-forms-leads' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:24px;">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="export_config">
		<?php wp_nonce_field( 'mpfl_admin_export_config', '_mpflnonce' ); ?>
		<button type="submit" class="button"><?php esc_html_e( 'Export configuration (forms + settings)', 'mayfair-forms-leads' ); ?></button>
	</form>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" style="display:inline-block;">
		<input type="hidden" name="action" value="mpfl_admin_action">
		<input type="hidden" name="mpfl_task" value="import_config">
		<?php wp_nonce_field( 'mpfl_admin_import_config', '_mpflnonce' ); ?>
		<input type="file" name="config_file" accept="application/json">
		<button type="submit" class="button"><?php esc_html_e( 'Import configuration', 'mayfair-forms-leads' ); ?></button>
	</form>
	<p class="description"><?php esc_html_e( 'Import adds forms as new drafts — it never overwrites or deletes existing data.', 'mayfair-forms-leads' ); ?></p>
</div>
