<?php
/**
 * Overview dashboard.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpfl_counters = MPFL_Submissions::counters();
$mpfl_sources  = MPFL_Leads::source_labels();
?>
<div class="wrap mpfl-wrap">
	<h1><?php esc_html_e( 'Mayfair Forms — Dashboard', 'mayfair-forms-leads' ); ?></h1>
	<?php if ( isset( $_GET['mpfl_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-success is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<div class="mpfl-cards">
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['total'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Total Submissions', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['new'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'New Leads', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['contacted'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Contacted', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['qualified'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Qualified', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['site_visit_scheduled'] + $mpfl_counters['site_visit_completed'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Site Visits', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['won'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Won', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['lost'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Lost', 'mayfair-forms-leads' ); ?></span></div>
	</div>

	<div class="mpfl-cards mpfl-cards--period">
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['today'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Today', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['week'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'This Week', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['month'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'This Month', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['property_enquiries'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Property Enquiries', 'mayfair-forms-leads' ); ?></span></div>
		<div class="mpfl-card"><span class="mpfl-card__n"><?php echo esc_html( $mpfl_counters['project_enquiries'] ); ?></span><span class="mpfl-card__l"><?php esc_html_e( 'Project Enquiries', 'mayfair-forms-leads' ); ?></span></div>
	</div>

	<h2><?php esc_html_e( 'Lead Sources', 'mayfair-forms-leads' ); ?></h2>
	<table class="widefat striped" style="max-width:520px;">
		<thead><tr><th><?php esc_html_e( 'Source', 'mayfair-forms-leads' ); ?></th><th><?php esc_html_e( 'Leads', 'mayfair-forms-leads' ); ?></th></tr></thead>
		<tbody>
		<?php foreach ( (array) $mpfl_counters['sources'] as $mpfl_row ) : ?>
			<tr>
				<td><?php echo esc_html( isset( $mpfl_sources[ $mpfl_row['source'] ] ) ? $mpfl_sources[ $mpfl_row['source'] ] : $mpfl_row['source'] ); ?></td>
				<td><?php echo esc_html( $mpfl_row['n'] ); ?></td>
			</tr>
		<?php endforeach; ?>
		<?php if ( empty( $mpfl_counters['sources'] ) ) : ?>
			<tr><td colspan="2"><?php esc_html_e( 'No submissions yet.', 'mayfair-forms-leads' ); ?></td></tr>
		<?php endif; ?>
		</tbody>
	</table>

	<p class="description" style="margin-top:16px;">
		<?php esc_html_e( 'Analytics note: form views/starts tracking is not implemented in v1, so conversion rate is not shown — the plugin does not fabricate metrics it does not measure.', 'mayfair-forms-leads' ); ?>
	</p>
</div>
