# User Guide — Mayfair Forms & Leads
*For non-coders. Nothing here requires touching code.*

## 1. First steps after activation

Activation creates the database tables and seeds **12 ready-made forms** (Property Enquiry, Site Visit, Buyer Requirement, Callback, Sell/Valuation, Home Loan, and more). Go to **Mayfair Forms → Forms** to see them. All are editable; duplicate any of them to experiment safely.

Then open **Mayfair Forms → Settings** and set:
1. **Notify To** — the inbox that receives lead alerts.
2. **Consent Text** — the line shown next to the consent checkbox.
3. Leave privacy defaults as they are (IP stored as an anonymous hash; data kept on uninstall).

## 2. Editing a form

**Mayfair Forms → Forms → click a form name.**
- Change name, status (Draft/Published/Inactive), success message, redirect, button text, notifications.
- **Fields table**: see every field, delete ones you don't need.
- **Add Field**: pick a type (Text, Email, Phone, Select, Property Selector, Budget Range, File Upload, Consent…), give it a label, set width (two 50% fields sit side by side), mark Required if needed.
- Options for Select/Radio/Checkbox-group fields: one choice per line.

Only **Published** forms appear on the website.

## 3. Placing a form on the website

**Elementor (recommended):** edit the page → search widgets for **Mayfair Form** (in the *Mayfair* category) → drop it in → choose your form. Style tab controls labels, inputs, button, colors — it follows your Elementor Global Colors/Fonts automatically unless you override.

**Anywhere else:** paste the shortcode shown in the Forms list, e.g. `[mayfair_form id="3"]`.

**Property pages:** just place the Property Enquiry form in the Single Property template. The plugin automatically records which property each enquiry came from — visitors never type the property name.

## 4. Managing leads

**Mayfair Forms → Submissions** is your inbox: filter by form, status, source, dates; search by name/phone/email. Click a name to open the full lead:
- All submitted answers + the property/project it came from
- Source (Google/Meta/Direct/…) and UTM tags when present
- **Status** dropdown (New → Contacted → Qualified → Site Visit → Won/Lost…)
- **Assign** to a team member (only users with lead permissions appear)
- **Internal notes** — private, never visible to the visitor
- **Timeline** — every event: creation, status changes, notes, emails, exports
- **Copy Full Submission** — one click, paste into WhatsApp/email

## 5. Exporting

**Single lead:** open it → TXT / JSON / PDF buttons (PDF is a clean printable report).

**Many leads:** **Mayfair Forms → Exports** → choose format (CSV opens perfectly in Excel; XLSX is genuine Excel format; JSON for developers) → choose a preset (Sales/Marketing/Property Enquiry/Site Visit/Full) → optionally filter by form, status, dates, property → **Generate Export**. Files download with names like `mayfair-leads-2026-08-17.csv`.

**Backup:** the Exports page also backs up your form definitions + settings to a JSON file, and can import them later (imports add copies; they never overwrite).

## 6. Team permissions

Administrators get all abilities automatically. To give another user access, a developer/administrator can grant these capabilities (e.g. via a role plugin): `view_mayfair_leads`, `edit_mayfair_leads`, `export_mayfair_leads`, `delete_mayfair_leads`, `manage_mayfair_forms`.

## 7. Good to know

- **A lead is never lost because an email failed** — everything is in the database first; email is just a notification. The timeline records every email attempt.
- Email deliverability depends on your site's mail setup; SMTP configuration is a separate task.
- Spam protection is on automatically (honeypot, timing, rate limiting). If spam grows, a developer can add Cloudflare Turnstile via the provided hook.
- Deleting a **form** never deletes its **submissions**.
- Deleting the **plugin** never deletes data unless you explicitly ticked "Delete all plugin data on uninstall" in Settings.
