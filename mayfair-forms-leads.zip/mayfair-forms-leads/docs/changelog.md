# Changelog — Mayfair Forms & Leads

## 1.0.0 — 2026-08-17
Initial release (generated; statically validated; awaiting live WordPress testing).

**Added**
- Form Builder (CRUD, duplicate, draft/publish/inactive, versioning) with 24 curated field types
- 12 built-in editable real-estate form templates + 5 reusable field presets (Buyer/Seller/Visit/Investor/Loan)
- Conditional field visibility (AND/OR; is / is_not / contains) evaluated client- AND server-side
- Independent submission database: 5 custom tables via dbDelta and $wpdb->prefix
- Automatic property/project context capture (post ID, mpd_property_id meta, title, URL, taxonomies, page URL, referrer)
- Lead dashboard: overview cards, filterable/searchable inbox, detail view, timeline, private notes, capability-gated assignment, configurable statuses
- Exports: CSV (UTF-8+BOM), genuine minimal-OOXML XLSX, JSON (single+bulk), dependency-free PDF, TXT/clipboard; presets; filtered/date-range/property exports; config backup+restore
- Notifications via wp_mail with per-attempt timeline logging; optional visitor confirmation
- Configurable https webhook (CRM/Sheets/Zapier/Make-ready)
- Anti-spam: nonce, honeypot, signed timing check, rate limiting, choice whitelisting; mpfl_extra_spam_check filter for Turnstile/reCAPTCHA
- Privacy: consent text/version/timestamp, hashed-or-off IP storage, data preserved on uninstall by default
- Elementor: Mayfair category + Mayfair Form widget with Global Colors/Fonts-bound style controls
- Shortcode [mayfair_form id="" mode=""]
- Read-only capability-gated REST API (mpfl/v1)
- Five plugin capabilities

**Known limitations (documented)**
- Form views/starts analytics not implemented — conversion rate deliberately not displayed
- Built-in PDF is Latin-1 (core fonts); full-Unicode PDFs need a GPL library swap later
- XLSX requires PHP zip extension (CSV fallback message otherwise)
- Rate limiting is per-server without a shared object cache
