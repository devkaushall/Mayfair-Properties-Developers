# Security & Privacy Documentation — Mayfair Forms & Leads

## Request security
| Layer | Implementation |
|---|---|
| CSRF | Per-form nonce (`mpfl_submit_form_{id}`) on every frontend submit; `check_admin_referer('mpfl_admin_{task}')` on every admin action |
| Capability checks | Every admin page and every admin task checks its specific capability; REST routes use `permission_callback` |
| Honeypot | Visually hidden `mpfl_website_url` field; any value rejects |
| Timing | Server-issued timestamp HMAC-signed with `wp_salt('nonce')`; forged or too-fast (< min_submit_seconds) submissions rejected |
| Rate limiting | Transient counter per salted client hash; default 5 / 10 min, configurable |
| Extension | `mpfl_extra_spam_check` filter for Turnstile/reCAPTCHA later — not required in v1 |

## Input handling
- **Sanitization by type**: `sanitize_email`, `esc_url_raw`, numeric filtering, `sanitize_textarea_field`, `sanitize_text_field`; arrays sanitized recursively.
- **Server-side validation is mandatory and authoritative**: required, email, phone pattern, numeric min/max, URL (`wp_http_validate_url`), min/max length, and **choice whitelisting** (select/radio/checkbox values must match defined options). Frontend validation is never trusted.
- Conditional fields are re-evaluated **server-side**; hidden-by-logic fields are skipped entirely (can't be smuggled in).
- Context post IDs are re-verified server-side (`get_post_type()` must return property/project).
- Redirect overrides travel HMAC-signed; `wp_safe_redirect` everywhere.

## Output escaping
All admin views escape with `esc_html`/`esc_attr`/`esc_url`/`esc_textarea`; the frontend renderer escapes every attribute and text node; the `html` field type passes through `wp_kses_post`. The Elementor widget's `render()` outputs the renderer's pre-escaped markup.

## SQL
All queries use `$wpdb->prepare()` with placeholders, `$wpdb->insert/update/delete` with format arrays, and `$wpdb->esc_like()` for search. Table names are built internally from `$wpdb->prefix` + fixed suffixes — never from user input. The only non-prepared statements are fixed-string aggregates on internal table names (marked with phpcs annotations).

## File uploads
- Allowed: PDF, JPG, JPEG, PNG, WEBP only — enforced via `wp_check_filetype_and_ext()` (real content sniffing, not extension trust).
- Configurable size limit (default 5 MB).
- Stored in an isolated `uploads/mayfair-leads/` subtree with `.htaccess` denying script execution + blank `index.html`.
- File links rendered only in the capability-gated admin detail view.

## Privacy
- **Raw IP is never stored.** Settings offer: salted-HMAC hash (default) or nothing.
- Consent: text configurable, version + timestamp stored per submission; version bumping documented.
- Data minimisation: no unnecessary fields captured; user agent truncated to 255 chars.
- Uninstall: data preserved unless the admin explicitly opted into deletion (default OFF).
- Internal notes are stored in the events table and rendered only in admin — never on the frontend.
- No legal guarantees are made or implied; consult counsel for compliance requirements.

## Direct access protection
Every PHP file begins with an `ABSPATH` (or `WP_UNINSTALL_PLUGIN`) guard.

## Known limitations (honest)
- Rate limiting uses transients — on multi-server setups without shared object cache it is per-server.
- `wp_mail()` deliverability depends on the host until SMTP is configured (separate task).
- The REST API exposes no public endpoints; if a headless client later needs frontend submission via REST, it must add its own nonce/token design.
