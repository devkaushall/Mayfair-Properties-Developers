# Elementor Widget Documentation — Mayfair Form

**Widget:** `Mayfair Form` · **Category:** `Mayfair` (dedicated) · **Requires:** Elementor (free or Pro) for placement only — forms also work via shortcode without Elementor.

The widget renders forms defined in the plugin's Form Builder. It deliberately does **not** duplicate the form engine: fields, validation, storage, notifications and exports all belong to the plugin; Elementor owns placement and styling.

## Content controls
| Control | Effect |
|---|---|
| **Form** | Select any Published form |
| **Form Mode** | Stacked (default) / Inline (single-row hero bars) / Compact (tight spacing) |
| **Success Message (override)** | Overrides the Form Builder message for this placement only |
| **Redirect URL (override)** | Per-placement redirect; transmitted HMAC-signed so it cannot be tampered with client-side |
| **Button Text (override)** | Per-placement label |
| **Alignment** | Submit-row alignment (responsive) |
| **Width** | Max form width, px/% (responsive) |
| **CSS Class** | Extra class on the `<form>` |

## Style controls (all default to Elementor Globals)
| Section | Controls | Global default |
|---|---|---|
| Labels | Typography, color | Text font / Text color |
| Inputs | Typography, text color, background, placeholder color, border group, radius, padding, focus accent | Text font & color; focus ← Accent color |
| Layout | Field gap, mobile stacking switch | — |
| Button | Typography, background, text color, hover background, width | Accent font; Secondary color bg; Accent hover |
| Messages | Success text/bg, error text/bg | — |

Because defaults bind to **Global Colors/Fonts** (`Global_Colors::COLOR_SECONDARY`, `COLOR_ACCENT`, `COLOR_TEXT`, `Global_Typography`), changing the site design system in Elementor restyles every Mayfair form automatically — per-widget overrides win only where set. No second design system is created; the plugin's base CSS is structural only.

## Placement recipes
- **Single Property template:** drop the widget into the enquiry section, select *Property Enquiry*. Property context (post ID, `mpd_property_id`, title, URL, type, location, status) is captured automatically as hidden metadata.
- **Single Project template:** same with *Project Enquiry* — project context captured automatically.
- **Contact page:** *General Enquiry*, stacked mode.
- **Homepage hero:** *Callback Request*, inline mode, width ~640px.

## Non-Elementor embedding
- Shortcode: `[mayfair_form id="123"]` or `[mayfair_form id="123" mode="inline"]` (only `id` and `mode` are exposed — no unsafe attributes).
- Gutenberg: use the Shortcode block with the same shortcode (a dedicated block is a v1.1 candidate; the shortcode path keeps v1 dependency-free).
- Direct URL: place the shortcode on any WordPress page to create a standalone form URL.
