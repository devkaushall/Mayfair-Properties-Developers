# QA — Static Validation Results & Live Test Checklist

## Part A — Static validation performed before delivery (in the generation environment)

**Honesty note:** these checks ran on the source files and on extracted logic executed in PHP 8.4 CLI **outside WordPress**. They do not prove behaviour inside a live WordPress installation — Part B exists for that.

| Check | Result |
|---|---|
| PHP syntax (`php -l`) on all 23 PHP files | PASS — zero errors |
| JSON validity (sample exports, docs) | PASS |
| SQL schema — dbDelta-compatible CREATE TABLE statements, `$wpdb->prefix` only, no hardcoded `wp_` | PASS |
| All `require_once` targets exist; class names match files | PASS |
| No undefined MPFL_* class references | PASS |
| Nonce usage — frontend (`mpfl_submit_form_{id}`) + every admin task (`mpfl_admin_{task}`) + REST permission callbacks | PASS |
| Capability checks on every admin page, every admin task, every REST route | PASS |
| Prepared SQL / format-array usage audit | PASS (fixed-string aggregates on internal table names annotated) |
| Escaping audit — admin views & frontend renderer | PASS |
| Sanitization audit — all `$_POST`/`$_GET`/`$_FILES` touchpoints | PASS |
| Elementor widget + category registration hooks | PASS (structural) |
| Shortcode registration (`mayfair_form`) | PASS (structural) |
| Export engine functional tests (CLI): PDF structure (header/xref/multi-page/EOF), CSV BOM+quoting+embedded newlines, XLSX real-ZIP + wellformed worksheet XML, conditional logic AND/OR/is_not/contains | PASS — 22/22 |
| File permissions in ZIP (dirs 755, files 644) | PASS |
| No ACF Pro / paid dependencies / React / Vue | PASS |
| No modification of CPTs, taxonomies, ACF fields | PASS (read-only context detection only) |

## Part B — Must be tested on a staging/live WordPress site (not yet performed anywhere)

**Forms**
- [ ] Activate plugin → tables exist (check via a DB tool: `{prefix}mayfair_forms` … `_events`), 12 templates seeded
- [ ] Create / edit / duplicate / delete a form; deleting a form leaves its submissions intact
- [ ] Add fields of several types incl. Property Selector + Consent; reorder via sort order; delete a field
- [ ] Conditional field: rule "Timeline is Immediately" shows/hides live (JS) AND is honoured on submit with JS disabled

**Submission path**
- [ ] Shortcode renders on a plain page; Mayfair Form widget renders in Elementor under the Mayfair category
- [ ] Submit with missing required field → readable error, nothing stored
- [ ] Valid submit → success message; row in Submissions with all answers
- [ ] Same form on a property page → property context auto-captured (post ID, ref, title, URL, type, location, status)
- [ ] Honeypot filled (dev tools) → rejected; instant submit → "too quickly" rejection; 6th rapid submit → rate-limited
- [ ] File upload: PDF accepted; .php renamed to .pdf rejected; oversize rejected; file lands in `uploads/mayfair-leads/`
- [ ] UTM parameters on the page URL appear in the stored submission

**Lead management**
- [ ] Change status → badge updates, timeline logs old→new
- [ ] Add internal note → timeline only, never frontend
- [ ] Assign to a user with `edit_mayfair_leads` → works; users without the cap don't appear
- [ ] Dashboard counters move when new submissions arrive

**Exports**
- [ ] CSV opens in Excel with Indian text intact (BOM) and embedded commas/newlines preserved
- [ ] XLSX opens in Excel/LibreOffice as a real workbook
- [ ] JSON single + bulk validate
- [ ] PDF opens in a viewer, multi-page for long submissions
- [ ] TXT copy block selects on click and pastes cleanly
- [ ] Config export downloads; import adds “(Imported)” drafts
- [ ] All exports work with Elementor deactivated

**Email / webhook**
- [ ] Submission triggers admin email attempt; timeline shows `email_attempted` with result either way
- [ ] Kill mail on purpose (bad From) → submission still stored — lead not lost
- [ ] Webhook to https endpoint (e.g. webhook.site) fires with JSON payload; timeline logs HTTP code

**Uninstall safety**
- [ ] Deactivate + delete plugin with the setting OFF → tables/leads survive
- [ ] (Staging only) enable delete-on-uninstall → tables removed

**Compatibility watch**
- [ ] LiteSpeed Cache: exclude `admin-post.php` from caching if success/error flashes misbehave (it is excluded by default in LSCWP defaults)
- [ ] Rank Math / Royal Addons: no console errors on pages containing the form
