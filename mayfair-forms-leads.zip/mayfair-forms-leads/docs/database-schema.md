# Database Schema — Mayfair Forms & Leads

All tables use `$wpdb->prefix . 'mayfair_*'` (shown here as `wp_` for illustration only — the real prefix is whatever the site uses). Created on activation with `dbDelta()` — idempotent, never destroys existing data on update.

## wp_mayfair_forms
| Column | Type | Notes |
|---|---|---|
| id | BIGINT UNSIGNED PK AI | Form ID |
| name | VARCHAR(190) | Form name |
| slug | VARCHAR(190) IDX | Unique-ish slug (name + random suffix) |
| description | TEXT | Internal description |
| form_type | VARCHAR(60) IDX | Template type key |
| status | VARCHAR(20) IDX | draft / published / inactive |
| version | INT | Incremented on every save |
| settings | LONGTEXT | JSON: success_message, redirect_url, button_text, notify_admin, notify_visitor, webhook_enabled, lead_type, design_preset |
| created_at / updated_at | DATETIME | |

## wp_mayfair_form_fields
| Column | Type | Notes |
|---|---|---|
| id | BIGINT UNSIGNED PK AI | |
| form_id | BIGINT UNSIGNED IDX | FK → forms.id (application-level) |
| field_key | VARCHAR(190) IDX | Stable key used in submissions |
| field_type | VARCHAR(60) | One of 24 curated types |
| label / placeholder | VARCHAR(255) | |
| description | TEXT | Help text |
| required | TINYINT(1) | |
| default_value | TEXT | Also carries HTML for `html` type (kses-filtered on output) |
| css_class | VARCHAR(190) | |
| width | VARCHAR(10) | 25/33/50/66/75/100 |
| sort_order | INT | |
| validation | LONGTEXT | JSON: min, max, minlength, maxlength |
| conditions | LONGTEXT | JSON: { relation: AND\|OR, rules: [{field, operator(is/is_not/contains), value}] } |
| options | LONGTEXT | JSON array for select/radio/checkbox_group/bedrooms |
| admin_only | TINYINT(1) | Never rendered on frontend |
| export_label | VARCHAR(255) | Column header override |
| privacy_flag | TINYINT(1) | Marked sensitive |

## wp_mayfair_submissions
| Column | Type | Notes |
|---|---|---|
| id | BIGINT UNSIGNED PK AI | Submission/Lead ID |
| form_id IDX / form_name | | Snapshot of form name (survives form deletion) |
| status | VARCHAR(40) IDX | Lead status key |
| lead_type | VARCHAR(60) | buyer/seller/visit/... from form settings |
| name / email / phone | VARCHAR | Promoted from common field keys |
| property_id | VARCHAR(100) | The mpd_property_id value (business ref) |
| property_post_id | BIGINT NULL IDX | Verified server-side to be a real property post |
| project_post_id | BIGINT NULL IDX | Verified server-side |
| source | VARCHAR(60) | Auto-classified; never fabricated |
| page_url / referrer | TEXT | |
| utm_source/medium/campaign/term/content | VARCHAR(190) | |
| user_agent | VARCHAR(255) | Truncated |
| ip_hash | VARCHAR(64) | Salted HMAC hash or empty — raw IP never stored |
| consent_state | TINYINT(1) | |
| consent_version | VARCHAR(20) | Settings version at submit time |
| consent_at | DATETIME NULL | |
| assigned_user | BIGINT NULL IDX | WP user ID |
| created_at IDX / updated_at | DATETIME | |

## wp_mayfair_submission_values
| Column | Type | Notes |
|---|---|---|
| id | PK AI | |
| submission_id | BIGINT IDX | |
| field_key | VARCHAR(190) IDX | `_ctx_*` keys hold property/project context snapshots |
| field_label | VARCHAR(255) | Export label snapshot |
| field_type | VARCHAR(60) | `file` values store JSON upload metadata |
| value | LONGTEXT | Scalar, or JSON for arrays/files |

## wp_mayfair_submission_events
| Column | Type | Notes |
|---|---|---|
| id | PK AI | |
| submission_id | BIGINT IDX | |
| event_type | VARCHAR(60) IDX | created / status_changed / note_added / assigned / exported / email_attempted / webhook_attempted |
| event_data | LONGTEXT | JSON payload |
| user_id | BIGINT | Actor (0 = visitor/system) |
| created_at | DATETIME IDX | |

## Lifecycle
- **Activation**: dbDelta creates/updates tables; capabilities added to administrator; templates seeded once (`mpfl_templates_seeded` guard).
- **Update**: dbDelta re-run when `mpfl_db_version` changes — additive only.
- **Deactivation**: nothing destroyed.
- **Uninstall**: tables/options dropped ONLY if `delete_on_uninstall` was explicitly enabled (default OFF).
