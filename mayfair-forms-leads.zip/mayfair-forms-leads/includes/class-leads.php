<?php
/**
 * Lead statuses, notes, assignment, timeline events.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Leads {

	public static function default_statuses() {
		return array(
			'new'                  => 'New',
			'contacted'            => 'Contacted',
			'qualified'            => 'Qualified',
			'site_visit_scheduled' => 'Site Visit Scheduled',
			'site_visit_completed' => 'Site Visit Completed',
			'follow_up'            => 'Follow Up',
			'won'                  => 'Won',
			'lost'                 => 'Lost',
			'spam'                 => 'Spam',
			'archived'             => 'Archived',
		);
	}

	/** Configured statuses (admin can add custom ones in Settings). */
	public static function statuses() {
		$settings = MPFL_Database::get_settings();
		$statuses = isset( $settings['lead_statuses'] ) && is_array( $settings['lead_statuses'] ) ? $settings['lead_statuses'] : array();
		return ! empty( $statuses ) ? $statuses : self::default_statuses();
	}

	public static function status_label( $key ) {
		$all = self::statuses();
		return isset( $all[ $key ] ) ? $all[ $key ] : ucfirst( str_replace( '_', ' ', $key ) );
	}

	/** Change a submission's status (capability-checked by callers). */
	public static function set_status( $submission_id, $status ) {
		global $wpdb;
		$statuses = self::statuses();
		if ( ! isset( $statuses[ $status ] ) ) {
			return new WP_Error( 'mpfl_status', __( 'Unknown status.', 'mayfair-forms-leads' ) );
		}
		$table = MPFL_Database::table( 'submissions' );
		$old   = $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$table} WHERE id = %d", $submission_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from trusted builder
		$wpdb->update(
			$table,
			array( 'status' => $status, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $submission_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		self::log_event( $submission_id, 'status_changed', array( 'from' => $old, 'to' => $status ) );
		return true;
	}

	/** Add a private internal note (never rendered on the frontend). */
	public static function add_note( $submission_id, $note ) {
		$note = sanitize_textarea_field( $note );
		if ( '' === $note ) {
			return new WP_Error( 'mpfl_note', __( 'Note is empty.', 'mayfair-forms-leads' ) );
		}
		self::log_event( $submission_id, 'note_added', array( 'note' => $note ) );
		return true;
	}

	/** Assign a submission to a user who can edit leads. */
	public static function assign( $submission_id, $user_id ) {
		global $wpdb;
		$user_id = (int) $user_id;
		if ( $user_id && ! user_can( $user_id, 'edit_mayfair_leads' ) && ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'mpfl_assign', __( 'That user cannot manage leads.', 'mayfair-forms-leads' ) );
		}
		$table = MPFL_Database::table( 'submissions' );
		$wpdb->update(
			$table,
			array( 'assigned_user' => $user_id ? $user_id : null, 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $submission_id ),
			array( '%d', '%s' ),
			array( '%d' )
		);
		self::log_event( $submission_id, 'assigned', array( 'user_id' => $user_id ) );
		return true;
	}

	/** Users eligible for assignment (only lead-capable users — never all users). */
	public static function assignable_users() {
		$users = get_users( array( 'capability' => 'edit_mayfair_leads', 'fields' => array( 'ID', 'display_name' ) ) );
		if ( empty( $users ) ) {
			$users = get_users( array( 'role' => 'administrator', 'fields' => array( 'ID', 'display_name' ) ) );
		}
		return $users;
	}

	/** Append to the submission timeline. */
	public static function log_event( $submission_id, $type, $data = array() ) {
		global $wpdb;
		$wpdb->insert(
			MPFL_Database::table( 'submission_events' ),
			array(
				'submission_id' => (int) $submission_id,
				'event_type'    => sanitize_key( $type ),
				'event_data'    => wp_json_encode( $data ),
				'user_id'       => get_current_user_id(),
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%d', '%s' )
		);
	}

	/** Timeline for a submission (oldest first). */
	public static function timeline( $submission_id ) {
		global $wpdb;
		$table = MPFL_Database::table( 'submission_events' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE submission_id = %d ORDER BY created_at ASC, id ASC", $submission_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/** Best-effort automatic source classification. Never fabricates: falls back to website_form. */
	public static function classify_source( $referrer, $utm_source ) {
		$utm = strtolower( (string) $utm_source );
		if ( '' !== $utm ) {
			if ( false !== strpos( $utm, 'google' ) ) {
				return 'google';
			}
			if ( false !== strpos( $utm, 'facebook' ) || false !== strpos( $utm, 'meta' ) || false !== strpos( $utm, 'fb' ) ) {
				return 'meta';
			}
			if ( false !== strpos( $utm, 'instagram' ) || false !== strpos( $utm, 'ig' ) ) {
				return 'instagram';
			}
			if ( false !== strpos( $utm, 'whatsapp' ) || false !== strpos( $utm, 'wa' ) ) {
				return 'whatsapp';
			}
			return 'other';
		}
		$ref = strtolower( (string) $referrer );
		if ( '' === $ref ) {
			return 'direct';
		}
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( $host && false !== strpos( $ref, $host ) ) {
			return 'website_form';
		}
		if ( false !== strpos( $ref, 'google.' ) ) {
			return 'organic';
		}
		if ( false !== strpos( $ref, 'facebook.' ) || false !== strpos( $ref, 'instagram.' ) ) {
			return 'meta';
		}
		return 'referral';
	}

	public static function source_labels() {
		return array(
			'website_form' => 'Website Form',
			'organic'      => 'Organic',
			'direct'       => 'Direct',
			'google'       => 'Google',
			'meta'         => 'Meta',
			'instagram'    => 'Instagram',
			'whatsapp'     => 'WhatsApp',
			'portal'       => 'Property Portal',
			'referral'     => 'Referral',
			'manual'       => 'Manual',
			'other'        => 'Other',
		);
	}
}
