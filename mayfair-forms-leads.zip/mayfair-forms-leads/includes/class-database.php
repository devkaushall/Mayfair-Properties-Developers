<?php
/**
 * Database schema, activation, migration.
 *
 * Tables (all via $wpdb->prefix — never hardcoded wp_):
 *  {prefix}mayfair_forms
 *  {prefix}mayfair_form_fields
 *  {prefix}mayfair_submissions
 *  {prefix}mayfair_submission_values
 *  {prefix}mayfair_submission_events
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Database {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'mayfair_' . $name;
	}

	/**
	 * Activation: create tables with dbDelta (idempotent, never destroys data),
	 * seed built-in form templates once, add capabilities.
	 */
	public static function activate() {
		self::create_tables();
		self::add_capabilities();
		MPFL_Templates::seed_builtin_templates();
		update_option( 'mpfl_db_version', MPFL_DB_VERSION );
		// Default settings: privacy-first.
		add_option( 'mpfl_settings', array(
			'store_ip'            => 'hash',      // off | hash  (never raw by default)
			'delete_on_uninstall' => 0,           // default OFF — data survives uninstall
			'notify_to'           => get_option( 'admin_email' ),
			'notify_from_name'    => get_bloginfo( 'name' ),
			'notify_from_email'   => get_option( 'admin_email' ),
			'notify_subject'      => '[Mayfair] New lead: {form_name} #{submission_id}',
			'visitor_confirm'     => 0,
			'consent_text'        => 'I agree to be contacted by Mayfair Properties & Developers about my enquiry.',
			'consent_version'     => '1.0',
			'rate_limit_max'      => 5,           // submissions per window per client
			'rate_limit_window'   => 600,         // seconds
			'min_submit_seconds'  => 3,           // timing check
			'upload_max_mb'       => 5,
			'lead_statuses'       => MPFL_Leads::default_statuses(),
		) );
	}

	public static function deactivate() {
		// Nothing destructive. Flush any scheduled events we own.
		wp_clear_scheduled_hook( 'mpfl_daily_maintenance' );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		$forms       = self::table( 'forms' );
		$fields      = self::table( 'form_fields' );
		$submissions = self::table( 'submissions' );
		$values      = self::table( 'submission_values' );
		$events      = self::table( 'submission_events' );

		dbDelta( "CREATE TABLE {$forms} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			slug VARCHAR(190) NOT NULL,
			description TEXT NULL,
			form_type VARCHAR(60) NOT NULL DEFAULT 'general',
			status VARCHAR(20) NOT NULL DEFAULT 'draft',
			version INT(11) UNSIGNED NOT NULL DEFAULT 1,
			settings LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY slug (slug),
			KEY status (status),
			KEY form_type (form_type)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$fields} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT(20) UNSIGNED NOT NULL,
			field_key VARCHAR(190) NOT NULL,
			field_type VARCHAR(60) NOT NULL,
			label VARCHAR(255) NOT NULL DEFAULT '',
			placeholder VARCHAR(255) NOT NULL DEFAULT '',
			description TEXT NULL,
			required TINYINT(1) NOT NULL DEFAULT 0,
			default_value TEXT NULL,
			css_class VARCHAR(190) NOT NULL DEFAULT '',
			width VARCHAR(10) NOT NULL DEFAULT '100',
			sort_order INT(11) NOT NULL DEFAULT 0,
			validation LONGTEXT NULL,
			conditions LONGTEXT NULL,
			options LONGTEXT NULL,
			admin_only TINYINT(1) NOT NULL DEFAULT 0,
			export_label VARCHAR(255) NOT NULL DEFAULT '',
			privacy_flag TINYINT(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY form_id (form_id),
			KEY field_key (field_key)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$submissions} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT(20) UNSIGNED NOT NULL,
			form_name VARCHAR(190) NOT NULL DEFAULT '',
			status VARCHAR(40) NOT NULL DEFAULT 'new',
			lead_type VARCHAR(60) NOT NULL DEFAULT '',
			name VARCHAR(190) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			phone VARCHAR(60) NOT NULL DEFAULT '',
			property_id VARCHAR(100) NOT NULL DEFAULT '',
			property_post_id BIGINT(20) UNSIGNED NULL,
			project_post_id BIGINT(20) UNSIGNED NULL,
			source VARCHAR(60) NOT NULL DEFAULT 'website_form',
			page_url TEXT NULL,
			referrer TEXT NULL,
			utm_source VARCHAR(190) NOT NULL DEFAULT '',
			utm_medium VARCHAR(190) NOT NULL DEFAULT '',
			utm_campaign VARCHAR(190) NOT NULL DEFAULT '',
			utm_term VARCHAR(190) NOT NULL DEFAULT '',
			utm_content VARCHAR(190) NOT NULL DEFAULT '',
			user_agent VARCHAR(255) NOT NULL DEFAULT '',
			ip_hash VARCHAR(64) NOT NULL DEFAULT '',
			consent_state TINYINT(1) NOT NULL DEFAULT 0,
			consent_version VARCHAR(20) NOT NULL DEFAULT '',
			consent_at DATETIME NULL,
			assigned_user BIGINT(20) UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY form_id (form_id),
			KEY status (status),
			KEY property_post_id (property_post_id),
			KEY project_post_id (project_post_id),
			KEY created_at (created_at),
			KEY assigned_user (assigned_user)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$values} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			submission_id BIGINT(20) UNSIGNED NOT NULL,
			field_key VARCHAR(190) NOT NULL,
			field_label VARCHAR(255) NOT NULL DEFAULT '',
			field_type VARCHAR(60) NOT NULL DEFAULT 'text',
			value LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY submission_id (submission_id),
			KEY field_key (field_key)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$events} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			submission_id BIGINT(20) UNSIGNED NOT NULL,
			event_type VARCHAR(60) NOT NULL,
			event_data LONGTEXT NULL,
			user_id BIGINT(20) UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY submission_id (submission_id),
			KEY event_type (event_type),
			KEY created_at (created_at)
		) {$charset};" );
	}

	public static function add_capabilities() {
		$role = get_role( 'administrator' );
		if ( ! $role ) {
			return;
		}
		foreach ( self::capabilities() as $cap ) {
			$role->add_cap( $cap );
		}
	}

	public static function capabilities() {
		return array(
			'manage_mayfair_forms',
			'view_mayfair_leads',
			'edit_mayfair_leads',
			'export_mayfair_leads',
			'delete_mayfair_leads',
		);
	}

	/** Settings helper. */
	public static function get_settings() {
		$defaults = array(
			'store_ip'            => 'hash',
			'delete_on_uninstall' => 0,
			'notify_to'           => get_option( 'admin_email' ),
			'notify_from_name'    => get_bloginfo( 'name' ),
			'notify_from_email'   => get_option( 'admin_email' ),
			'notify_subject'      => '[Mayfair] New lead: {form_name} #{submission_id}',
			'visitor_confirm'     => 0,
			'consent_text'        => '',
			'consent_version'     => '1.0',
			'rate_limit_max'      => 5,
			'rate_limit_window'   => 600,
			'min_submit_seconds'  => 3,
			'upload_max_mb'       => 5,
			'lead_statuses'       => MPFL_Leads::default_statuses(),
		);
		$saved = get_option( 'mpfl_settings', array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	}
}
