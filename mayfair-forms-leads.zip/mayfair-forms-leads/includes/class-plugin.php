<?php
/**
 * Plugin orchestrator: admin menu, admin pages, admin actions (all
 * nonce + capability checked), asset loading.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		MPFL_Form_Renderer::init();
		MPFL_REST::init();

		if ( did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ) ) {
			MPFL_Elementor::init();
		} else {
			add_action( 'elementor/loaded', array( 'MPFL_Elementor', 'init' ) );
		}

		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'admin_menu' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
			add_action( 'admin_post_mpfl_admin_action', array( $this, 'handle_admin_action' ) );
		}

		// DB upgrade path.
		if ( get_option( 'mpfl_db_version' ) !== MPFL_DB_VERSION ) {
			MPFL_Database::create_tables();
			update_option( 'mpfl_db_version', MPFL_DB_VERSION );
		}
	}

	/* ------------------------------------------------------------------ */
	/* Menu                                                               */
	/* ------------------------------------------------------------------ */

	public function admin_menu() {
		add_menu_page(
			__( 'Mayfair Forms', 'mayfair-forms-leads' ),
			__( 'Mayfair Forms', 'mayfair-forms-leads' ),
			'view_mayfair_leads',
			'mpfl-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-feedback',
			26
		);
		add_submenu_page( 'mpfl-dashboard', __( 'Dashboard', 'mayfair-forms-leads' ), __( 'Dashboard', 'mayfair-forms-leads' ), 'view_mayfair_leads', 'mpfl-dashboard', array( $this, 'render_dashboard' ) );
		add_submenu_page( 'mpfl-dashboard', __( 'Forms', 'mayfair-forms-leads' ), __( 'Forms', 'mayfair-forms-leads' ), 'manage_mayfair_forms', 'mpfl-forms', array( $this, 'render_forms' ) );
		add_submenu_page( 'mpfl-dashboard', __( 'Submissions', 'mayfair-forms-leads' ), __( 'Submissions', 'mayfair-forms-leads' ), 'view_mayfair_leads', 'mpfl-submissions', array( $this, 'render_submissions' ) );
		add_submenu_page( 'mpfl-dashboard', __( 'Exports', 'mayfair-forms-leads' ), __( 'Exports', 'mayfair-forms-leads' ), 'export_mayfair_leads', 'mpfl-exports', array( $this, 'render_exports' ) );
		add_submenu_page( 'mpfl-dashboard', __( 'Settings', 'mayfair-forms-leads' ), __( 'Settings', 'mayfair-forms-leads' ), 'manage_mayfair_forms', 'mpfl-settings', array( $this, 'render_settings' ) );
	}

	public function admin_assets( $hook ) {
		if ( false === strpos( $hook, 'mpfl-' ) ) {
			return;
		}
		wp_enqueue_style( 'mpfl-admin', MPFL_URL . 'admin/assets/mpfl-admin.css', array(), MPFL_VERSION );
	}

	/* ------------------------------------------------------------------ */
	/* Views (delegated to admin/views/*.php)                             */
	/* ------------------------------------------------------------------ */

	public function render_dashboard() {
		if ( ! current_user_can( 'view_mayfair_leads' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
		require MPFL_DIR . 'admin/views/dashboard.php';
	}

	public function render_forms() {
		if ( ! current_user_can( 'manage_mayfair_forms' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
		require MPFL_DIR . 'admin/views/forms.php';
	}

	public function render_submissions() {
		if ( ! current_user_can( 'view_mayfair_leads' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
		$view = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only routing
		if ( $view ) {
			require MPFL_DIR . 'admin/views/submission-detail.php';
		} else {
			require MPFL_DIR . 'admin/views/submissions.php';
		}
	}

	public function render_exports() {
		if ( ! current_user_can( 'export_mayfair_leads' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
		require MPFL_DIR . 'admin/views/exports.php';
	}

	public function render_settings() {
		if ( ! current_user_can( 'manage_mayfair_forms' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
		require MPFL_DIR . 'admin/views/settings.php';
	}

	/* ------------------------------------------------------------------ */
	/* Admin actions — single dispatcher, nonce + capability per action   */
	/* ------------------------------------------------------------------ */

	public function handle_admin_action() {
		$task = isset( $_POST['mpfl_task'] ) ? sanitize_key( wp_unslash( $_POST['mpfl_task'] ) ) : ( isset( $_GET['mpfl_task'] ) ? sanitize_key( wp_unslash( $_GET['mpfl_task'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- verified below per task
		check_admin_referer( 'mpfl_admin_' . $task, '_mpflnonce' );

		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=mpfl-dashboard' );

		switch ( $task ) {

			case 'create_form':
				$this->require_cap( 'manage_mayfair_forms' );
				$id = MPFL_Form_Builder::create_form( array(
					'name'        => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
					'description' => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
					'form_type'   => isset( $_POST['form_type'] ) ? sanitize_key( wp_unslash( $_POST['form_type'] ) ) : 'general',
					'status'      => 'draft',
				) );
				$this->finish( $redirect, is_wp_error( $id ) ? $id->get_error_message() : __( 'Form created.', 'mayfair-forms-leads' ) );
				break;

			case 'update_form':
				$this->require_cap( 'manage_mayfair_forms' );
				$form_id = isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : 0;
				$data    = array();
				foreach ( array( 'name', 'description', 'form_type', 'status' ) as $k ) {
					if ( isset( $_POST[ $k ] ) ) {
						$data[ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
					}
				}
				if ( isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ) {
					$data['settings'] = map_deep( wp_unslash( $_POST['settings'] ), 'sanitize_text_field' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by map_deep
				}
				MPFL_Form_Builder::update_form( $form_id, $data );
				$this->finish( $redirect, __( 'Form updated.', 'mayfair-forms-leads' ) );
				break;

			case 'duplicate_form':
				$this->require_cap( 'manage_mayfair_forms' );
				MPFL_Form_Builder::duplicate_form( isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : 0 );
				$this->finish( $redirect, __( 'Form duplicated.', 'mayfair-forms-leads' ) );
				break;

			case 'delete_form':
				$this->require_cap( 'manage_mayfair_forms' );
				MPFL_Form_Builder::delete_form( isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : 0 );
				$this->finish( $redirect, __( 'Form deleted. Its submissions are preserved.', 'mayfair-forms-leads' ) );
				break;

			case 'add_field':
				$this->require_cap( 'manage_mayfair_forms' );
				$form_id = isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : 0;
				$field   = array();
				foreach ( array( 'field_type', 'field_key', 'label', 'placeholder', 'description', 'default_value', 'css_class', 'width', 'export_label' ) as $k ) {
					$field[ $k ] = isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : '';
				}
				$field['required']     = ! empty( $_POST['required'] ) ? 1 : 0;
				$field['admin_only']   = ! empty( $_POST['admin_only'] ) ? 1 : 0;
				$field['privacy_flag'] = ! empty( $_POST['privacy_flag'] ) ? 1 : 0;
				$field['sort_order']   = isset( $_POST['sort_order'] ) ? (int) $_POST['sort_order'] : 99;
				if ( ! empty( $_POST['options'] ) ) {
					$field['options'] = array_filter( array_map( 'trim', explode( "\n", sanitize_textarea_field( wp_unslash( $_POST['options'] ) ) ) ) );
				}
				MPFL_Form_Builder::add_field( $form_id, $field );
				$this->finish( $redirect, __( 'Field added.', 'mayfair-forms-leads' ) );
				break;

			case 'delete_field':
				$this->require_cap( 'manage_mayfair_forms' );
				MPFL_Form_Builder::delete_field( isset( $_POST['field_id'] ) ? (int) $_POST['field_id'] : 0 );
				$this->finish( $redirect, __( 'Field deleted.', 'mayfair-forms-leads' ) );
				break;

			case 'reorder_fields':
				$this->require_cap( 'manage_mayfair_forms' );
				$order = isset( $_POST['order'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['order'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- intval map
				MPFL_Form_Builder::reorder_fields( isset( $_POST['form_id'] ) ? (int) $_POST['form_id'] : 0, $order );
				$this->finish( $redirect, __( 'Fields reordered.', 'mayfair-forms-leads' ) );
				break;

			case 'set_status':
				$this->require_cap( 'edit_mayfair_leads' );
				MPFL_Leads::set_status( isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0, isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '' );
				$this->finish( $redirect, __( 'Status updated.', 'mayfair-forms-leads' ) );
				break;

			case 'add_note':
				$this->require_cap( 'edit_mayfair_leads' );
				MPFL_Leads::add_note( isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0, isset( $_POST['note'] ) ? wp_unslash( $_POST['note'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized inside add_note
				$this->finish( $redirect, __( 'Note added.', 'mayfair-forms-leads' ) );
				break;

			case 'assign':
				$this->require_cap( 'edit_mayfair_leads' );
				MPFL_Leads::assign( isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0, isset( $_POST['user_id'] ) ? (int) $_POST['user_id'] : 0 );
				$this->finish( $redirect, __( 'Assigned.', 'mayfair-forms-leads' ) );
				break;

			case 'delete_submission':
				$this->require_cap( 'delete_mayfair_leads' );
				MPFL_Submissions::delete( isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0 );
				$this->finish( admin_url( 'admin.php?page=mpfl-submissions' ), __( 'Submission deleted.', 'mayfair-forms-leads' ) );
				break;

			case 'mark_spam':
				$this->require_cap( 'edit_mayfair_leads' );
				MPFL_Leads::set_status( isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0, 'spam' );
				$this->finish( $redirect, __( 'Marked as spam.', 'mayfair-forms-leads' ) );
				break;

			case 'export':
				$this->require_cap( 'export_mayfair_leads' );
				$this->handle_export();
				break;

			case 'save_settings':
				$this->require_cap( 'manage_mayfair_forms' );
				$settings = MPFL_Database::get_settings();
				foreach ( array( 'notify_to', 'notify_from_name', 'notify_from_email', 'notify_subject', 'consent_text', 'consent_version' ) as $k ) {
					if ( isset( $_POST[ $k ] ) ) {
						$settings[ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
					}
				}
				foreach ( array( 'rate_limit_max', 'rate_limit_window', 'min_submit_seconds', 'upload_max_mb' ) as $k ) {
					if ( isset( $_POST[ $k ] ) ) {
						$settings[ $k ] = (int) $_POST[ $k ];
					}
				}
				$settings['store_ip']            = ( isset( $_POST['store_ip'] ) && 'off' === $_POST['store_ip'] ) ? 'off' : 'hash';
				$settings['delete_on_uninstall'] = ! empty( $_POST['delete_on_uninstall'] ) ? 1 : 0;
				$settings['visitor_confirm']     = ! empty( $_POST['visitor_confirm'] ) ? 1 : 0;
				if ( isset( $_POST['custom_statuses'] ) ) {
					$lines    = array_filter( array_map( 'trim', explode( "\n", sanitize_textarea_field( wp_unslash( $_POST['custom_statuses'] ) ) ) ) );
					$statuses = MPFL_Leads::default_statuses();
					foreach ( $lines as $line ) {
						$statuses[ sanitize_key( $line ) ] = sanitize_text_field( $line );
					}
					$settings['lead_statuses'] = $statuses;
				}
				update_option( 'mpfl_settings', $settings );
				// Webhook config.
				$webhook = MPFL_Webhooks::config();
				$webhook['enabled'] = ! empty( $_POST['webhook_enabled'] ) ? 1 : 0;
				if ( isset( $_POST['webhook_url'] ) ) {
					$webhook['url'] = esc_url_raw( wp_unslash( $_POST['webhook_url'] ) );
				}
				update_option( 'mpfl_webhook', $webhook );
				$this->finish( $redirect, __( 'Settings saved.', 'mayfair-forms-leads' ) );
				break;

			case 'export_config':
				$this->require_cap( 'manage_mayfair_forms' );
				MPFL_Exports::stream( MPFL_Exports::export_config(), 'mayfair-forms-config-' . gmdate( 'Y-m-d' ) . '.json', 'application/json; charset=utf-8' );
				break;

			case 'import_config':
				$this->require_cap( 'manage_mayfair_forms' );
				if ( ! empty( $_FILES['config_file']['tmp_name'] ) ) {
					$json   = file_get_contents( sanitize_text_field( $_FILES['config_file']['tmp_name'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- tmp path from PHP
					$result = MPFL_Exports::import_config( $json );
					$this->finish( $redirect, is_wp_error( $result ) ? $result->get_error_message() : sprintf( /* translators: %d count */ __( '%d forms imported.', 'mayfair-forms-leads' ), $result ) );
				}
				$this->finish( $redirect, __( 'No file provided.', 'mayfair-forms-leads' ) );
				break;

			default:
				wp_die( esc_html__( 'Unknown action.', 'mayfair-forms-leads' ) );
		}
	}

	private function handle_export() {
		$format  = isset( $_POST['format'] ) ? sanitize_key( wp_unslash( $_POST['format'] ) ) : 'csv'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in dispatcher
		$preset  = isset( $_POST['preset'] ) ? sanitize_key( wp_unslash( $_POST['preset'] ) ) : 'full'; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$single  = isset( $_POST['submission_id'] ) ? (int) $_POST['submission_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$filters = array();
		foreach ( array( 'form_id' => 'int', 'status' => 'key', 'source' => 'key', 'property_post_id' => 'int', 'project_post_id' => 'int', 'date_from' => 'text', 'date_to' => 'text' ) as $k => $type ) {
			if ( ! empty( $_POST[ $k ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$raw = wp_unslash( $_POST[ $k ] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below by type
				$filters[ $k ] = ( 'int' === $type ) ? (int) $raw : ( ( 'key' === $type ) ? sanitize_key( $raw ) : sanitize_text_field( $raw ) );
			}
		}

		if ( $single ) {
			switch ( $format ) {
				case 'json':
					$out = MPFL_Exports::build_json_single( $single );
					MPFL_Leads::log_event( $single, 'exported', array( 'format' => 'json' ) );
					MPFL_Exports::stream( is_wp_error( $out ) ? '{}' : $out, MPFL_Exports::filename( array( 'single', $single ), 'json' ), 'application/json; charset=utf-8' );
					break;
				case 'pdf':
					$out = MPFL_Exports::build_pdf_single( $single );
					MPFL_Leads::log_event( $single, 'exported', array( 'format' => 'pdf' ) );
					MPFL_Exports::stream( is_wp_error( $out ) ? '' : $out, MPFL_Exports::filename( array( 'single', $single ), 'pdf' ), 'application/pdf' );
					break;
				case 'txt':
				default:
					$out = MPFL_Exports::build_txt_single( $single );
					MPFL_Leads::log_event( $single, 'exported', array( 'format' => 'txt' ) );
					MPFL_Exports::stream( is_wp_error( $out ) ? '' : $out, MPFL_Exports::filename( array( 'single', $single ), 'txt' ), 'text/plain; charset=utf-8' );
			}
			return;
		}

		$rows = MPFL_Exports::collect( $filters, $preset );
		switch ( $format ) {
			case 'xlsx':
				$out = MPFL_Exports::build_xlsx( $rows );
				if ( is_wp_error( $out ) ) {
					$this->finish( wp_get_referer(), $out->get_error_message() );
				}
				MPFL_Exports::stream( $out, MPFL_Exports::filename( array( 'bulk' ), 'xlsx' ), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
				break;
			case 'json':
				MPFL_Exports::stream( MPFL_Exports::build_json_bulk( $filters, $preset ), MPFL_Exports::filename( array( 'bulk' ), 'json' ), 'application/json; charset=utf-8' );
				break;
			case 'csv':
			default:
				MPFL_Exports::stream( MPFL_Exports::build_csv( $rows ), MPFL_Exports::filename( array( 'bulk' ), 'csv' ), 'text/csv; charset=utf-8' );
		}
	}

	private function require_cap( $cap ) {
		if ( ! current_user_can( $cap ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-forms-leads' ) );
		}
	}

	private function finish( $redirect, $message ) {
		wp_safe_redirect( add_query_arg( 'mpfl_notice', rawurlencode( $message ), $redirect ) );
		exit;
	}
}
