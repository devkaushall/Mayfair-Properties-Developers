<?php
/**
 * Security helpers: nonces, rate limiting, honeypot, timing, sanitization,
 * IP privacy, upload restrictions.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Security {

	const NONCE_ACTION = 'mpfl_submit_form';
	const NONCE_FIELD  = 'mpfl_nonce';

	/** Render hidden security fields into a form. */
	public static function form_fields( $form_id ) {
		$out  = wp_nonce_field( self::NONCE_ACTION . '_' . (int) $form_id, self::NONCE_FIELD, true, false );
		// Honeypot: visually hidden, real bots fill it.
		$out .= '<div class="mpfl-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:auto;height:1px;overflow:hidden;">';
		$out .= '<label>Leave this field empty<input type="text" name="mpfl_website_url" value="" tabindex="-1" autocomplete="off"></label></div>';
		// Timing check token: server-issued timestamp, HMAC-signed so it cannot be forged.
		$ts   = time();
		$out .= '<input type="hidden" name="mpfl_ts" value="' . esc_attr( $ts ) . '">';
		$out .= '<input type="hidden" name="mpfl_tsig" value="' . esc_attr( self::sign( (string) $ts ) ) . '">';
		return $out;
	}

	public static function sign( $data ) {
		return hash_hmac( 'sha256', $data, wp_salt( 'nonce' ) );
	}

	/**
	 * Run all gate checks for a submission request.
	 *
	 * @return true|WP_Error
	 */
	public static function verify_submission_request( $form_id ) {
		// Nonce / CSRF.
		$nonce = isset( $_POST[ self::NONCE_FIELD ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION . '_' . (int) $form_id ) ) {
			return new WP_Error( 'mpfl_nonce', __( 'Security check failed. Please reload the page and try again.', 'mayfair-forms-leads' ) );
		}

		// Honeypot.
		if ( ! empty( $_POST['mpfl_website_url'] ) ) {
			return new WP_Error( 'mpfl_honeypot', __( 'Submission rejected.', 'mayfair-forms-leads' ) );
		}

		// Timing: signed timestamp must verify and be older than the minimum.
		$settings = MPFL_Database::get_settings();
		$ts   = isset( $_POST['mpfl_ts'] ) ? sanitize_text_field( wp_unslash( $_POST['mpfl_ts'] ) ) : '';
		$sig  = isset( $_POST['mpfl_tsig'] ) ? sanitize_text_field( wp_unslash( $_POST['mpfl_tsig'] ) ) : '';
		if ( '' === $ts || ! hash_equals( self::sign( $ts ), $sig ) ) {
			return new WP_Error( 'mpfl_timing', __( 'Security check failed.', 'mayfair-forms-leads' ) );
		}
		if ( ( time() - (int) $ts ) < (int) $settings['min_submit_seconds'] ) {
			return new WP_Error( 'mpfl_too_fast', __( 'Form submitted too quickly. Please try again.', 'mayfair-forms-leads' ) );
		}

		// Rate limit per client key (privacy-safe hash).
		$key   = 'mpfl_rl_' . self::client_key();
		$count = (int) get_transient( $key );
		if ( $count >= (int) $settings['rate_limit_max'] ) {
			return new WP_Error( 'mpfl_rate', __( 'Too many submissions. Please try again later.', 'mayfair-forms-leads' ) );
		}
		set_transient( $key, $count + 1, (int) $settings['rate_limit_window'] );

		/**
		 * Extension point for Turnstile / reCAPTCHA later:
		 * add_filter( 'mpfl_extra_spam_check', function( $result ) { ...verify token...; return $result_or_WP_Error; } );
		 */
		$extra = apply_filters( 'mpfl_extra_spam_check', true );
		if ( is_wp_error( $extra ) ) {
			return $extra;
		}

		return true;
	}

	/** Privacy-safe client identifier: salted hash, never the raw IP. */
	public static function client_key() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ), 0, 32 );
	}

	/** IP storage per settings: 'off' => '', 'hash' => salted hash (default). Raw IP is never stored. */
	public static function ip_for_storage() {
		$settings = MPFL_Database::get_settings();
		if ( 'off' === $settings['store_ip'] ) {
			return '';
		}
		return self::client_key();
	}

	/** Sanitize one submitted value according to field type. */
	public static function sanitize_value( $type, $raw ) {
		if ( is_array( $raw ) ) {
			$clean = array();
			foreach ( $raw as $item ) {
				$clean[] = self::sanitize_value( $type, $item );
			}
			return $clean;
		}
		$raw = wp_unslash( $raw );
		switch ( $type ) {
			case 'email':
				return sanitize_email( $raw );
			case 'url':
				return esc_url_raw( $raw );
			case 'number':
			case 'budget_range':
				return is_numeric( $raw ) ? ( 0 + $raw ) : preg_replace( '/[^0-9.\-]/', '', (string) $raw );
			case 'textarea':
				return sanitize_textarea_field( $raw );
			case 'html':
				return ''; // display-only field type never accepts input
			default:
				return sanitize_text_field( $raw );
		}
	}

	/**
	 * Server-side validation for one field. Frontend validation is never trusted.
	 *
	 * @return true|WP_Error
	 */
	public static function validate_value( $field, $value ) {
		$label = ! empty( $field['label'] ) ? $field['label'] : $field['field_key'];
		$rules = ! empty( $field['validation'] ) && is_array( $field['validation'] ) ? $field['validation'] : array();

		$is_empty = ( '' === $value || null === $value || ( is_array( $value ) && empty( $value ) ) );

		if ( ! empty( $field['required'] ) && $is_empty ) {
			/* translators: %s field label */
			return new WP_Error( 'mpfl_required', sprintf( __( '%s is required.', 'mayfair-forms-leads' ), $label ) );
		}
		if ( $is_empty ) {
			return true;
		}

		switch ( $field['field_type'] ) {
			case 'email':
				if ( ! is_email( $value ) ) {
					return new WP_Error( 'mpfl_email', sprintf( __( '%s must be a valid email address.', 'mayfair-forms-leads' ), $label ) );
				}
				break;
			case 'phone':
				if ( ! preg_match( '/^[0-9+\-\s()]{7,20}$/', (string) $value ) ) {
					return new WP_Error( 'mpfl_phone', sprintf( __( '%s must be a valid phone number.', 'mayfair-forms-leads' ), $label ) );
				}
				break;
			case 'number':
			case 'budget_range':
				if ( ! is_numeric( $value ) ) {
					return new WP_Error( 'mpfl_number', sprintf( __( '%s must be a number.', 'mayfair-forms-leads' ), $label ) );
				}
				if ( isset( $rules['min'] ) && '' !== $rules['min'] && (float) $value < (float) $rules['min'] ) {
					return new WP_Error( 'mpfl_min', sprintf( __( '%s is below the minimum.', 'mayfair-forms-leads' ), $label ) );
				}
				if ( isset( $rules['max'] ) && '' !== $rules['max'] && (float) $value > (float) $rules['max'] ) {
					return new WP_Error( 'mpfl_max', sprintf( __( '%s exceeds the maximum.', 'mayfair-forms-leads' ), $label ) );
				}
				break;
			case 'url':
				if ( ! wp_http_validate_url( $value ) ) {
					return new WP_Error( 'mpfl_url', sprintf( __( '%s must be a valid URL.', 'mayfair-forms-leads' ), $label ) );
				}
				break;
			case 'date':
			case 'time':
			case 'datetime':
				// Accept common browser formats; store as text.
				if ( strlen( (string) $value ) > 32 ) {
					return new WP_Error( 'mpfl_date', sprintf( __( '%s is invalid.', 'mayfair-forms-leads' ), $label ) );
				}
				break;
		}

		$len = is_array( $value ) ? count( $value ) : mb_strlen( (string) $value );
		if ( isset( $rules['minlength'] ) && '' !== $rules['minlength'] && $len < (int) $rules['minlength'] ) {
			return new WP_Error( 'mpfl_minlength', sprintf( __( '%s is too short.', 'mayfair-forms-leads' ), $label ) );
		}
		if ( isset( $rules['maxlength'] ) && '' !== $rules['maxlength'] && $len > (int) $rules['maxlength'] ) {
			return new WP_Error( 'mpfl_maxlength', sprintf( __( '%s is too long.', 'mayfair-forms-leads' ), $label ) );
		}

		// Select-type fields: value must be one of the defined options.
		if ( in_array( $field['field_type'], array( 'select', 'radio', 'checkbox_group', 'bedrooms' ), true ) && ! empty( $field['options'] ) ) {
			$allowed = array_map( 'strval', (array) $field['options'] );
			$vals    = is_array( $value ) ? $value : array( $value );
			foreach ( $vals as $v ) {
				if ( ! in_array( (string) $v, $allowed, true ) ) {
					return new WP_Error( 'mpfl_option', sprintf( __( '%s contains an invalid choice.', 'mayfair-forms-leads' ), $label ) );
				}
			}
		}

		return true;
	}

	/** Allowed upload mimes for form file fields. */
	public static function allowed_mimes() {
		return array(
			'pdf'  => 'application/pdf',
			'jpg'  => 'image/jpeg',
			'jpeg' => 'image/jpeg',
			'png'  => 'image/png',
			'webp' => 'image/webp',
		);
	}

	/**
	 * Handle a single uploaded file securely.
	 *
	 * @return array|WP_Error array( 'url','file','name','size','type' )
	 */
	public static function handle_upload( $file_array ) {
		$settings = MPFL_Database::get_settings();
		$max      = (int) $settings['upload_max_mb'] * 1024 * 1024;

		if ( empty( $file_array['name'] ) ) {
			return new WP_Error( 'mpfl_upload', __( 'No file uploaded.', 'mayfair-forms-leads' ) );
		}
		if ( ! empty( $file_array['size'] ) && (int) $file_array['size'] > $max ) {
			return new WP_Error( 'mpfl_upload_size', __( 'File exceeds the maximum allowed size.', 'mayfair-forms-leads' ) );
		}

		// Real MIME check — extension alone is never trusted.
		$check = wp_check_filetype_and_ext( $file_array['tmp_name'], $file_array['name'], self::allowed_mimes() );
		if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
			return new WP_Error( 'mpfl_upload_type', __( 'File type not allowed. Allowed: PDF, JPG, PNG, WEBP.', 'mayfair-forms-leads' ) );
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		add_filter( 'upload_dir', array( __CLASS__, 'upload_dir' ) );
		$result = wp_handle_upload( $file_array, array(
			'test_form' => false,
			'mimes'     => self::allowed_mimes(),
		) );
		remove_filter( 'upload_dir', array( __CLASS__, 'upload_dir' ) );

		if ( isset( $result['error'] ) ) {
			return new WP_Error( 'mpfl_upload_failed', $result['error'] );
		}
		self::protect_upload_dir();
		return array(
			'url'  => $result['url'],
			'file' => $result['file'],
			'name' => sanitize_file_name( $file_array['name'] ),
			'size' => (int) $file_array['size'],
			'type' => $result['type'],
		);
	}

	/** Route plugin uploads into an isolated subdirectory. */
	public static function upload_dir( $dirs ) {
		$dirs['subdir'] = '/mayfair-leads' . $dirs['subdir'];
		$dirs['path']   = $dirs['basedir'] . $dirs['subdir'];
		$dirs['url']    = $dirs['baseurl'] . $dirs['subdir'];
		return $dirs;
	}

	/** Drop .htaccess + index.html so uploads can never execute. */
	public static function protect_upload_dir() {
		$base = wp_upload_dir();
		$dir  = trailingslashit( $base['basedir'] ) . 'mayfair-leads';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		$ht = $dir . '/.htaccess';
		if ( ! file_exists( $ht ) ) {
			// Deny PHP execution; allow static file serving.
			@file_put_contents( $ht, "<FilesMatch \"\\.(php|phtml|php3|php4|php5|pl|py|cgi)$\">\nRequire all denied\n</FilesMatch>\n" );
		}
		$ix = $dir . '/index.html';
		if ( ! file_exists( $ix ) ) {
			@file_put_contents( $ix, '' );
		}
	}
}
