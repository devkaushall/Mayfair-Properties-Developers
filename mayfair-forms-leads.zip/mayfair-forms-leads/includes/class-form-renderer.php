<?php
/**
 * Frontend form rendering (shortcode + Elementor widget both call this),
 * property/project context capture, and the submit handler.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Form_Renderer {

	public static function init() {
		add_shortcode( 'mayfair_form', array( __CLASS__, 'shortcode' ) );
		add_action( 'admin_post_nopriv_mpfl_submit', array( __CLASS__, 'handle_submit' ) );
		add_action( 'admin_post_mpfl_submit', array( __CLASS__, 'handle_submit' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	public static function register_assets() {
		wp_register_style( 'mpfl-forms', MPFL_URL . 'public/assets/mpfl-forms.css', array(), MPFL_VERSION );
		// Single small vanilla-JS file: conditional visibility + inline validation hints. No frameworks.
		wp_register_script( 'mpfl-forms', MPFL_URL . 'public/assets/mpfl-forms.js', array(), MPFL_VERSION, true );
	}

	/** Shortcode: [mayfair_form id="123" mode="inline"] — only safe attributes exposed. */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0, 'mode' => 'stacked' ), $atts, 'mayfair_form' );
		$mode = in_array( $atts['mode'], array( 'stacked', 'inline', 'compact' ), true ) ? $atts['mode'] : 'stacked';
		return self::render_form( (int) $atts['id'], array( 'mode' => $mode ) );
	}

	/**
	 * Render a published form.
	 *
	 * @param int   $form_id Form id.
	 * @param array $args    mode, button_text, css_class, success_message, redirect_url (Elementor overrides).
	 */
	public static function render_form( $form_id, $args = array() ) {
		$form = MPFL_Form_Builder::get_form( $form_id );
		if ( ! $form || 'published' !== $form['status'] ) {
			return current_user_can( 'manage_mayfair_forms' )
				? '<p class="mpfl-error">' . esc_html__( 'Mayfair Form: form not found or not published.', 'mayfair-forms-leads' ) . '</p>'
				: '';
		}

		wp_enqueue_style( 'mpfl-forms' );
		wp_enqueue_script( 'mpfl-forms' );

		$settings = json_decode( (string) $form['settings'], true );
		$settings = is_array( $settings ) ? $settings : array();
		$fields   = MPFL_Form_Builder::get_fields( $form_id );
		$mode     = isset( $args['mode'] ) ? $args['mode'] : 'stacked';
		$button   = ! empty( $args['button_text'] ) ? $args['button_text'] : ( isset( $settings['button_text'] ) ? $settings['button_text'] : __( 'Submit', 'mayfair-forms-leads' ) );
		$css      = ! empty( $args['css_class'] ) ? sanitize_html_class( $args['css_class'] ) : '';
		$preset   = isset( $settings['design_preset'] ) ? $settings['design_preset'] : 'mayfair-heritage';

		// Success flash (post/redirect/get).
		$out = '';
		if ( isset( $_GET['mpfl_success'] ) && (int) $_GET['mpfl_success'] === (int) $form_id ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag
			$msg  = ! empty( $args['success_message'] ) ? $args['success_message'] : ( isset( $settings['success_message'] ) ? $settings['success_message'] : __( 'Thank you — your enquiry has been received.', 'mayfair-forms-leads' ) );
			$out .= '<div class="mpfl-success" role="status">' . esc_html( $msg ) . '</div>';
		}
		if ( isset( $_GET['mpfl_error'] ) && (int) $_GET['mpfl_error'] === (int) $form_id && isset( $_GET['mpfl_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$out .= '<div class="mpfl-error" role="alert">' . esc_html( sanitize_text_field( wp_unslash( $_GET['mpfl_msg'] ) ) ) . '</div>';
		}

		$out .= '<form class="mpfl-form mpfl-mode-' . esc_attr( $mode ) . ' mpfl-preset-' . esc_attr( $preset ) . ' ' . esc_attr( $css ) . '" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" enctype="multipart/form-data" novalidate>';
		$out .= '<input type="hidden" name="action" value="mpfl_submit">';
		$out .= '<input type="hidden" name="mpfl_form_id" value="' . esc_attr( (int) $form_id ) . '">';
		$out .= MPFL_Security::form_fields( $form_id );
		$out .= self::context_fields();

		// Optional per-widget redirect override travels signed so it cannot be tampered with.
		if ( ! empty( $args['redirect_url'] ) ) {
			$r    = esc_url_raw( $args['redirect_url'] );
			$out .= '<input type="hidden" name="mpfl_redirect" value="' . esc_attr( $r ) . '">';
			$out .= '<input type="hidden" name="mpfl_redirect_sig" value="' . esc_attr( MPFL_Security::sign( $r ) ) . '">';
		}

		$out .= '<div class="mpfl-fields">';
		foreach ( $fields as $field ) {
			if ( ! empty( $field['admin_only'] ) ) {
				continue;
			}
			$out .= self::render_field( $field );
		}
		$out .= '</div>';
		$out .= '<div class="mpfl-actions"><button type="submit" class="mpfl-submit">' . esc_html( $button ) . '</button></div>';
		$out .= '</form>';

		return $out;
	}

	/** Hidden context fields: page URL + referrer + UTM (values read from request server-side on submit as well). */
	private static function context_fields() {
		$out  = '<input type="hidden" name="mpfl_page_url" value="' . esc_attr( self::current_url() ) . '">';
		$out .= '<input type="hidden" name="mpfl_referrer" value="' . esc_attr( isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '' ) . '">';
		foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ) as $utm ) {
			$val  = isset( $_GET[ $utm ] ) ? sanitize_text_field( wp_unslash( $_GET[ $utm ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- marketing params, read-only
			$out .= '<input type="hidden" name="mpfl_' . esc_attr( $utm ) . '" value="' . esc_attr( $val ) . '">';
		}
		// Property / project context: detected automatically from the current post.
		$ctx = self::detect_context();
		foreach ( $ctx as $key => $val ) {
			$out .= '<input type="hidden" name="mpfl_ctx_' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '">';
		}
		return $out;
	}

	/**
	 * Automatic property/project context. Visitor never types the property name
	 * when the form sits on a property page.
	 */
	public static function detect_context() {
		$ctx  = array();
		$post = get_post();
		if ( ! $post ) {
			return $ctx;
		}
		if ( 'property' === $post->post_type ) {
			$ctx['property_post_id'] = (string) $post->ID;
			$ctx['property_title']   = get_the_title( $post );
			$ctx['property_url']     = get_permalink( $post );
			// ACF optional: read the meta directly so the plugin works without ACF too.
			$ctx['property_id'] = (string) get_post_meta( $post->ID, 'mpd_property_id', true );
			$ctx['property_type']   = self::first_term( $post->ID, 'property-type' );
			$ctx['location']        = self::first_term( $post->ID, 'location' );
			$ctx['property_status'] = self::first_term( $post->ID, 'property-status' );
		} elseif ( 'project' === $post->post_type ) {
			$ctx['project_post_id'] = (string) $post->ID;
			$ctx['project_title']   = get_the_title( $post );
			$ctx['project_url']     = get_permalink( $post );
			$ctx['project_type']    = self::first_term( $post->ID, 'project-type' );
			$ctx['location']        = self::first_term( $post->ID, 'location' );
		}
		return $ctx;
	}

	private static function first_term( $post_id, $taxonomy ) {
		$terms = get_the_terms( $post_id, $taxonomy );
		if ( is_array( $terms ) && ! empty( $terms ) ) {
			return $terms[0]->name;
		}
		return '';
	}

	/** Render one field. All output escaped. */
	public static function render_field( $field ) {
		$key   = 'mpfl_f_' . $field['field_key'];
		$id    = 'mpfl-' . (int) $field['form_id'] . '-' . $field['field_key'];
		$req   = ! empty( $field['required'] );
		$width = in_array( (string) $field['width'], array( '25', '33', '50', '66', '75', '100' ), true ) ? $field['width'] : '100';
		$cond  = ! empty( $field['conditions'] ) && ! empty( $field['conditions']['rules'] ) ? wp_json_encode( $field['conditions'] ) : '';

		$wrap  = '<div class="mpfl-field mpfl-w-' . esc_attr( $width ) . ' mpfl-type-' . esc_attr( $field['field_type'] ) . ( $field['css_class'] ? ' ' . esc_attr( $field['css_class'] ) : '' ) . '"';
		$wrap .= $cond ? ' data-mpfl-conditions="' . esc_attr( $cond ) . '"' : '';
		$wrap .= '>';

		$label = '<label class="mpfl-label" for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] );
		$label .= $req ? ' <span class="mpfl-req" aria-hidden="true">*</span>' : '';
		$label .= '</label>';
		$desc   = $field['description'] ? '<span class="mpfl-desc" id="' . esc_attr( $id ) . '-desc">' . esc_html( $field['description'] ) . '</span>' : '';
		$aria   = $field['description'] ? ' aria-describedby="' . esc_attr( $id ) . '-desc"' : '';
		$reqattr = $req ? ' required' : '';

		$input = '';
		switch ( $field['field_type'] ) {
			case 'textarea':
				$input = '<textarea class="mpfl-input" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" rows="4" placeholder="' . esc_attr( $field['placeholder'] ) . '"' . $reqattr . $aria . '>' . esc_textarea( $field['default_value'] ) . '</textarea>';
				break;

			case 'select':
			case 'bedrooms':
				$input = '<select class="mpfl-input" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . $reqattr . $aria . '>';
				$input .= '<option value="">' . esc_html( $field['placeholder'] ? $field['placeholder'] : __( 'Select…', 'mayfair-forms-leads' ) ) . '</option>';
				foreach ( (array) $field['options'] as $opt ) {
					$input .= '<option value="' . esc_attr( $opt ) . '"' . selected( $field['default_value'], $opt, false ) . '>' . esc_html( $opt ) . '</option>';
				}
				$input .= '</select>';
				break;

			case 'radio':
				$input = '<div class="mpfl-choices" role="radiogroup" aria-label="' . esc_attr( $field['label'] ) . '">';
				foreach ( (array) $field['options'] as $i => $opt ) {
					$oid    = $id . '-' . $i;
					$input .= '<label class="mpfl-choice" for="' . esc_attr( $oid ) . '"><input type="radio" id="' . esc_attr( $oid ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $opt ) . '"' . checked( $field['default_value'], $opt, false ) . ( $req && 0 === $i ? ' required' : '' ) . '> ' . esc_html( $opt ) . '</label>';
				}
				$input .= '</div>';
				break;

			case 'checkbox':
				$input = '<label class="mpfl-choice" for="' . esc_attr( $id ) . '"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" value="1"' . $reqattr . '> ' . esc_html( $field['placeholder'] ? $field['placeholder'] : $field['label'] ) . '</label>';
				break;

			case 'checkbox_group':
				$input = '<div class="mpfl-choices">';
				foreach ( (array) $field['options'] as $i => $opt ) {
					$oid    = $id . '-' . $i;
					$input .= '<label class="mpfl-choice" for="' . esc_attr( $oid ) . '"><input type="checkbox" id="' . esc_attr( $oid ) . '" name="' . esc_attr( $key ) . '[]" value="' . esc_attr( $opt ) . '"> ' . esc_html( $opt ) . '</label>';
				}
				$input .= '</div>';
				break;

			case 'consent':
				$settings = MPFL_Database::get_settings();
				$text     = $settings['consent_text'] ? $settings['consent_text'] : __( 'I agree to be contacted about my enquiry.', 'mayfair-forms-leads' );
				$input    = '<label class="mpfl-choice mpfl-consent" for="' . esc_attr( $id ) . '"><input type="checkbox" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" value="1"' . $reqattr . '> <span>' . esc_html( $text ) . '</span></label>';
				$label    = ''; // consent renders its own text
				break;

			case 'hidden':
				return '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $field['default_value'] ) . '">';

			case 'html':
				return $wrap . wp_kses_post( $field['default_value'] ) . '</div>';

			case 'file':
				$input = '<input class="mpfl-input mpfl-file" type="file" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" accept=".pdf,.jpg,.jpeg,.png,.webp"' . $reqattr . $aria . '>';
				break;

			case 'property':
			case 'project':
				$input = self::post_select( $field['field_type'], $id, $key, $req, $field['placeholder'] );
				break;

			case 'location':
			case 'property_type':
			case 'status':
				$tax_map = array( 'location' => 'location', 'property_type' => 'property-type', 'status' => 'property-status' );
				$input   = self::term_select( $tax_map[ $field['field_type'] ], $id, $key, $req, $field['placeholder'] );
				break;

			case 'budget_range':
			case 'number':
				$input = '<input class="mpfl-input" type="number" inputmode="numeric" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" placeholder="' . esc_attr( $field['placeholder'] ) . '" value="' . esc_attr( $field['default_value'] ) . '"' . $reqattr . $aria . '>';
				break;

			case 'date':
				$input = '<input class="mpfl-input" type="date" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . $reqattr . $aria . '>';
				break;

			case 'time':
				$input = '<input class="mpfl-input" type="time" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . $reqattr . $aria . '>';
				break;

			case 'datetime':
				$input = '<input class="mpfl-input" type="datetime-local" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . $reqattr . $aria . '>';
				break;

			default: // text, email, phone, url
				$html_type = 'text';
				if ( 'email' === $field['field_type'] ) {
					$html_type = 'email';
				} elseif ( 'phone' === $field['field_type'] ) {
					$html_type = 'tel';
				} elseif ( 'url' === $field['field_type'] ) {
					$html_type = 'url';
				}
				$input = '<input class="mpfl-input" type="' . esc_attr( $html_type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '" placeholder="' . esc_attr( $field['placeholder'] ) . '" value="' . esc_attr( $field['default_value'] ) . '"' . $reqattr . $aria . '>';
		}

		return $wrap . $label . $input . $desc . '</div>';
	}

	private static function post_select( $post_type, $id, $key, $req, $placeholder ) {
		$posts = get_posts( array( 'post_type' => $post_type, 'posts_per_page' => 200, 'post_status' => 'publish', 'orderby' => 'title', 'order' => 'ASC' ) );
		$out   = '<select class="mpfl-input" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . ( $req ? ' required' : '' ) . '>';
		$out  .= '<option value="">' . esc_html( $placeholder ? $placeholder : __( 'Select…', 'mayfair-forms-leads' ) ) . '</option>';
		foreach ( $posts as $p ) {
			$out .= '<option value="' . esc_attr( $p->ID ) . '">' . esc_html( get_the_title( $p ) ) . '</option>';
		}
		return $out . '</select>';
	}

	private static function term_select( $taxonomy, $id, $key, $req, $placeholder ) {
		$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
		$out   = '<select class="mpfl-input" id="' . esc_attr( $id ) . '" name="' . esc_attr( $key ) . '"' . ( $req ? ' required' : '' ) . '>';
		$out  .= '<option value="">' . esc_html( $placeholder ? $placeholder : __( 'Select…', 'mayfair-forms-leads' ) ) . '</option>';
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out .= '<option value="' . esc_attr( $t->name ) . '">' . esc_html( $t->name ) . '</option>';
			}
		}
		return $out . '</select>';
	}

	private static function current_url() {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		return esc_url_raw( ( is_ssl() ? 'https://' : 'http://' ) . $host . $uri );
	}

	/* ------------------------------------------------------------------ */
	/* Submit handler                                                     */
	/* ------------------------------------------------------------------ */

	public static function handle_submit() {
		$form_id = isset( $_POST['mpfl_form_id'] ) ? (int) $_POST['mpfl_form_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified next line
		$back    = isset( $_POST['mpfl_page_url'] ) ? esc_url_raw( wp_unslash( $_POST['mpfl_page_url'] ) ) : home_url( '/' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		$gate = MPFL_Security::verify_submission_request( $form_id );
		if ( is_wp_error( $gate ) ) {
			self::bounce( $back, $form_id, $gate->get_error_message() );
		}

		$result = MPFL_Submissions::create_from_request( $form_id );
		if ( is_wp_error( $result ) ) {
			self::bounce( $back, $form_id, $result->get_error_message() );
		}

		// Redirect override (signed) > form-level redirect > back with success flag.
		$form     = MPFL_Form_Builder::get_form( $form_id );
		$settings = json_decode( (string) $form['settings'], true );
		$redirect = '';
		if ( ! empty( $_POST['mpfl_redirect'] ) && ! empty( $_POST['mpfl_redirect_sig'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$candidate = esc_url_raw( wp_unslash( $_POST['mpfl_redirect'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$sig       = sanitize_text_field( wp_unslash( $_POST['mpfl_redirect_sig'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
			if ( hash_equals( MPFL_Security::sign( $candidate ), $sig ) ) {
				$redirect = $candidate;
			}
		}
		if ( '' === $redirect && ! empty( $settings['redirect_url'] ) ) {
			$redirect = $settings['redirect_url'];
		}
		if ( '' !== $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
		wp_safe_redirect( add_query_arg( 'mpfl_success', $form_id, $back ) );
		exit;
	}

	private static function bounce( $back, $form_id, $message ) {
		wp_safe_redirect( add_query_arg( array(
			'mpfl_error' => $form_id,
			'mpfl_msg'   => rawurlencode( $message ),
		), $back ) );
		exit;
	}
}
