<?php
/**
 * Email notifications via wp_mail() (no SMTP assumption).
 * Every attempt is logged to the submission timeline — success or failure.
 * A failed email never loses the lead: the submission is already stored.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Email {

	public static function notify_admin( $submission_id ) {
		$settings = MPFL_Database::get_settings();
		$s        = MPFL_Submissions::get( $submission_id );
		if ( ! $s ) {
			return false;
		}
		$to      = $settings['notify_to'] ? $settings['notify_to'] : get_option( 'admin_email' );
		$subject = strtr( $settings['notify_subject'], array(
			'{form_name}'     => $s['form_name'],
			'{submission_id}' => $s['id'],
			'{name}'          => $s['name'],
		) );
		$body    = MPFL_Exports::build_txt_single( $submission_id );
		if ( is_wp_error( $body ) ) {
			$body = 'New lead #' . $submission_id;
		}
		$headers = array();
		if ( $settings['notify_from_email'] && is_email( $settings['notify_from_email'] ) ) {
			$headers[] = 'From: ' . $settings['notify_from_name'] . ' <' . $settings['notify_from_email'] . '>';
		}
		if ( $s['email'] && is_email( $s['email'] ) ) {
			$headers[] = 'Reply-To: ' . ( $s['name'] ? $s['name'] : $s['email'] ) . ' <' . $s['email'] . '>';
		}

		$sent = wp_mail( $to, $subject, $body, $headers );
		MPFL_Leads::log_event( $submission_id, 'email_attempted', array(
			'kind'   => 'admin_notification',
			'to'     => $to,
			'result' => $sent ? 'wp_mail returned true' : 'wp_mail returned false',
		) );
		return $sent;
	}

	public static function notify_visitor( $submission_id, $email ) {
		if ( ! is_email( $email ) ) {
			return false;
		}
		$settings = MPFL_Database::get_settings();
		$s        = MPFL_Submissions::get( $submission_id );
		if ( ! $s ) {
			return false;
		}
		$subject = sprintf(
			/* translators: %s site name */
			__( 'We received your enquiry — %s', 'mayfair-forms-leads' ),
			get_bloginfo( 'name' )
		);
		$body  = sprintf( "Dear %s,\n\n", $s['name'] ? $s['name'] : __( 'Sir/Madam', 'mayfair-forms-leads' ) );
		$body .= __( "Thank you for contacting Mayfair Properties & Developers. Your enquiry has been received and our team will get back to you within one working day.\n\n", 'mayfair-forms-leads' );
		$body .= sprintf( __( "Reference: MPFL-%d\n\n", 'mayfair-forms-leads' ), $submission_id );
		$body .= __( "Warm regards,\nMayfair Properties & Developers", 'mayfair-forms-leads' );

		$headers = array();
		if ( $settings['notify_from_email'] && is_email( $settings['notify_from_email'] ) ) {
			$headers[] = 'From: ' . $settings['notify_from_name'] . ' <' . $settings['notify_from_email'] . '>';
			$headers[] = 'Reply-To: ' . $settings['notify_from_name'] . ' <' . $settings['notify_from_email'] . '>';
		}

		$sent = wp_mail( $email, $subject, $body, $headers );
		MPFL_Leads::log_event( $submission_id, 'email_attempted', array(
			'kind'   => 'visitor_confirmation',
			'result' => $sent ? 'wp_mail returned true' : 'wp_mail returned false',
		) );
		return $sent;
	}
}
