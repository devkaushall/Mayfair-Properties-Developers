<?php
/**
 * Export engine: CSV, XLSX (genuine SpreadsheetML-free minimal OOXML), JSON,
 * PDF, TXT/clipboard. Presets. Config backup/restore.
 * Exports never require Elementor.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Exports {

	/** Built-in export presets (column sets). Admin can add more in Settings. */
	public static function presets() {
		$saved = get_option( 'mpfl_export_presets', array() );
		$built = array(
			'full'       => array( 'label' => 'Full Submission Export', 'columns' => array() ), // empty = all
			'sales'      => array( 'label' => 'Sales Export', 'columns' => array( 'id', 'created_at', 'name', 'phone', 'email', 'form_name', 'property', 'status', 'assigned' ) ),
			'marketing'  => array( 'label' => 'Marketing Export', 'columns' => array( 'id', 'created_at', 'form_name', 'source', 'utm_source', 'utm_medium', 'utm_campaign', 'page_url' ) ),
			'property'   => array( 'label' => 'Property Enquiry Export', 'columns' => array( 'id', 'created_at', 'name', 'phone', 'email', 'property', 'property_id', 'status' ) ),
			'site_visit' => array( 'label' => 'Site Visit Export', 'columns' => array( 'id', 'created_at', 'name', 'phone', 'property', 'status' ) ),
		);
		return array_merge( $built, is_array( $saved ) ? $saved : array() );
	}

	/** Flatten one submission row + its values for export. */
	public static function flatten( $submission ) {
		$values = MPFL_Submissions::get_values( $submission['id'] );
		$row    = array(
			'id'           => $submission['id'],
			'created_at'   => $submission['created_at'],
			'form_name'    => $submission['form_name'],
			'status'       => MPFL_Leads::status_label( $submission['status'] ),
			'lead_type'    => $submission['lead_type'],
			'name'         => $submission['name'],
			'email'        => $submission['email'],
			'phone'        => $submission['phone'],
			'property'     => '',
			'property_id'  => $submission['property_id'],
			'project'      => '',
			'source'       => $submission['source'],
			'page_url'     => $submission['page_url'],
			'utm_source'   => $submission['utm_source'],
			'utm_medium'   => $submission['utm_medium'],
			'utm_campaign' => $submission['utm_campaign'],
			'consent'      => $submission['consent_state'] ? 'Yes (v' . $submission['consent_version'] . ' at ' . $submission['consent_at'] . ')' : 'No',
			'assigned'     => $submission['assigned_user'] ? self::user_name( $submission['assigned_user'] ) : '',
		);
		if ( ! empty( $submission['property_post_id'] ) ) {
			$row['property'] = get_the_title( (int) $submission['property_post_id'] );
		}
		if ( ! empty( $submission['project_post_id'] ) ) {
			$row['project'] = get_the_title( (int) $submission['project_post_id'] );
		}
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) ) {
				if ( '' === $row['property'] && '_ctx_property_title' === $v['field_key'] ) {
					$row['property'] = $v['value'];
				}
				if ( '' === $row['project'] && '_ctx_project_title' === $v['field_key'] ) {
					$row['project'] = $v['value'];
				}
				continue;
			}
			// Privacy-flagged fields excluded from bulk exports unless preset explicitly includes them.
			$label = $v['field_label'] ? $v['field_label'] : $v['field_key'];
			$row[ 'answer:' . $label ] = self::readable_value( $v );
		}
		return $row;
	}

	private static function readable_value( $v ) {
		if ( 'file' === $v['field_type'] ) {
			$meta = json_decode( (string) $v['value'], true );
			return is_array( $meta ) && isset( $meta['name'] ) ? $meta['name'] . ' (' . ( isset( $meta['url'] ) ? $meta['url'] : '' ) . ')' : '';
		}
		$decoded = json_decode( (string) $v['value'], true );
		if ( is_array( $decoded ) ) {
			return implode( ', ', array_map( 'strval', $decoded ) );
		}
		return (string) $v['value'];
	}

	private static function user_name( $user_id ) {
		$user = get_userdata( (int) $user_id );
		return $user ? $user->display_name : '';
	}

	/** Collect flattened rows for a filter set, applying an optional preset's column list. */
	public static function collect( $filters, $preset_key = 'full' ) {
		$filters['per_page'] = 5000;
		$filters['page']     = 1;
		$result  = MPFL_Submissions::query( $filters );
		$presets = self::presets();
		$columns = isset( $presets[ $preset_key ] ) ? $presets[ $preset_key ]['columns'] : array();

		$rows = array();
		foreach ( $result['rows'] as $submission ) {
			$flat = self::flatten( $submission );
			if ( ! empty( $columns ) ) {
				$slice = array();
				foreach ( $columns as $col ) {
					$slice[ $col ] = isset( $flat[ $col ] ) ? $flat[ $col ] : '';
				}
				// answers are always appended for the 'property'/'site_visit' presets? No — only explicit columns. Keep strict.
				$flat = $slice;
			}
			$rows[] = $flat;
		}
		return $rows;
	}

	/* ------------------------------------------------------------------ */
	/* CSV                                                                */
	/* ------------------------------------------------------------------ */

	/** Build CSV string: UTF-8 with BOM, labels as headers, correct quoting. */
	public static function build_csv( $rows ) {
		if ( empty( $rows ) ) {
			return "\xEF\xBB\xBF";
		}
		// Union of all keys preserves every answer column.
		$headers = array();
		foreach ( $rows as $row ) {
			foreach ( array_keys( $row ) as $k ) {
				if ( ! in_array( $k, $headers, true ) ) {
					$headers[] = $k;
				}
			}
		}
		$fh = fopen( 'php://temp', 'w+' );
		fputcsv( $fh, array_map( array( __CLASS__, 'header_label' ), $headers ) );
		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $headers as $h ) {
				$line[] = isset( $row[ $h ] ) ? (string) $row[ $h ] : '';
			}
			fputcsv( $fh, $line ); // fputcsv handles commas/quotes/newlines correctly
		}
		rewind( $fh );
		$csv = stream_get_contents( $fh );
		fclose( $fh );
		return "\xEF\xBB\xBF" . $csv; // BOM for Excel
	}

	public static function header_label( $key ) {
		if ( 0 === strpos( $key, 'answer:' ) ) {
			return substr( $key, 7 );
		}
		$map = array(
			'id' => 'Submission ID', 'created_at' => 'Date', 'form_name' => 'Form', 'status' => 'Status',
			'lead_type' => 'Lead Type', 'name' => 'Name', 'email' => 'Email', 'phone' => 'Phone',
			'property' => 'Property', 'property_id' => 'Property Ref', 'project' => 'Project',
			'source' => 'Source', 'page_url' => 'Page URL', 'utm_source' => 'UTM Source',
			'utm_medium' => 'UTM Medium', 'utm_campaign' => 'UTM Campaign', 'consent' => 'Consent',
			'assigned' => 'Assigned To',
		);
		return isset( $map[ $key ] ) ? $map[ $key ] : ucwords( str_replace( '_', ' ', $key ) );
	}

	/* ------------------------------------------------------------------ */
	/* XLSX — genuine minimal OOXML (ZipArchive), never a renamed CSV      */
	/* ------------------------------------------------------------------ */

	/**
	 * Build a real .xlsx (Office Open XML) using PHP's ZipArchive with
	 * inline strings — no external library, no licensing issue.
	 *
	 * @return string|WP_Error binary xlsx content.
	 */
	public static function build_xlsx( $rows ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			// Documented fallback: hosts without ZipArchive get CSV instead.
			return new WP_Error( 'mpfl_xlsx', __( 'XLSX requires the PHP zip extension on this server. Use CSV export instead.', 'mayfair-forms-leads' ) );
		}
		$headers = array();
		foreach ( $rows as $row ) {
			foreach ( array_keys( $row ) as $k ) {
				if ( ! in_array( $k, $headers, true ) ) {
					$headers[] = $k;
				}
			}
		}

		$sheet_rows   = array();
		$sheet_rows[] = array_map( array( __CLASS__, 'header_label' ), $headers );
		foreach ( $rows as $row ) {
			$line = array();
			foreach ( $headers as $h ) {
				$line[] = isset( $row[ $h ] ) ? (string) $row[ $h ] : '';
			}
			$sheet_rows[] = $line;
		}

		$sheet_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";
		$sheet_xml .= '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
		foreach ( $sheet_rows as $r_idx => $cells ) {
			$sheet_xml .= '<row r="' . ( $r_idx + 1 ) . '">';
			foreach ( $cells as $c_idx => $cell ) {
				$ref        = self::cell_ref( $c_idx ) . ( $r_idx + 1 );
				$sheet_xml .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . htmlspecialchars( $cell, ENT_XML1 | ENT_QUOTES, 'UTF-8' ) . '</t></is></c>';
			}
			$sheet_xml .= '</row>';
		}
		$sheet_xml .= '</sheetData></worksheet>';

		$content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '</Types>';
		$rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
		$workbook = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="Leads" sheetId="1" r:id="rId1"/></sheets></workbook>';
		$wb_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '</Relationships>';

		$tmp = wp_tempnam( 'mpfl-xlsx' );
		$zip = new ZipArchive();
		if ( true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_Error( 'mpfl_xlsx_zip', __( 'Could not create XLSX archive.', 'mayfair-forms-leads' ) );
		}
		$zip->addFromString( '[Content_Types].xml', $content_types );
		$zip->addFromString( '_rels/.rels', $rels );
		$zip->addFromString( 'xl/workbook.xml', $workbook );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', $wb_rels );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $sheet_xml );
		$zip->close();
		$binary = file_get_contents( $tmp );
		wp_delete_file( $tmp );
		return $binary;
	}

	private static function cell_ref( $index ) {
		$ref = '';
		$n   = $index;
		while ( $n >= 0 ) {
			$ref = chr( 65 + ( $n % 26 ) ) . $ref;
			$n   = (int) floor( $n / 26 ) - 1;
		}
		return $ref;
	}

	/* ------------------------------------------------------------------ */
	/* JSON                                                               */
	/* ------------------------------------------------------------------ */

	public static function build_json_single( $submission_id ) {
		$s = MPFL_Submissions::get( $submission_id );
		if ( ! $s ) {
			return new WP_Error( 'mpfl_missing', __( 'Submission not found.', 'mayfair-forms-leads' ) );
		}
		$values  = MPFL_Submissions::get_values( $submission_id );
		$answers = array();
		$ctx     = array();
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) ) {
				$ctx[ substr( $v['field_key'], 5 ) ] = $v['value'];
			} else {
				$answers[ $v['field_label'] ? $v['field_label'] : $v['field_key'] ] = self::readable_value( $v );
			}
		}
		return wp_json_encode( array(
			'submission_id' => (int) $s['id'],
			'form'          => $s['form_name'],
			'created_at'    => $s['created_at'],
			'status'        => $s['status'],
			'lead'          => array( 'name' => $s['name'], 'email' => $s['email'], 'phone' => $s['phone'], 'lead_type' => $s['lead_type'] ),
			'property'      => array(
				'post_id'     => $s['property_post_id'] ? (int) $s['property_post_id'] : null,
				'property_id' => $s['property_id'],
				'title'       => isset( $ctx['property_title'] ) ? $ctx['property_title'] : '',
				'url'         => isset( $ctx['property_url'] ) ? $ctx['property_url'] : '',
			),
			'project'       => array(
				'post_id' => $s['project_post_id'] ? (int) $s['project_post_id'] : null,
				'title'   => isset( $ctx['project_title'] ) ? $ctx['project_title'] : '',
				'url'     => isset( $ctx['project_url'] ) ? $ctx['project_url'] : '',
			),
			'answers'       => $answers,
			'source'        => array(
				'source'       => $s['source'],
				'page_url'     => $s['page_url'],
				'referrer'     => $s['referrer'],
				'utm_source'   => $s['utm_source'],
				'utm_medium'   => $s['utm_medium'],
				'utm_campaign' => $s['utm_campaign'],
				'utm_term'     => $s['utm_term'],
				'utm_content'  => $s['utm_content'],
			),
			'consent'       => array(
				'state'     => (bool) $s['consent_state'],
				'version'   => $s['consent_version'],
				'timestamp' => $s['consent_at'],
			),
		), JSON_PRETTY_PRINT );
	}

	public static function build_json_bulk( $filters, $preset = 'full' ) {
		return wp_json_encode( self::collect( $filters, $preset ), JSON_PRETTY_PRINT );
	}

	/* ------------------------------------------------------------------ */
	/* TXT / clipboard                                                    */
	/* ------------------------------------------------------------------ */

	public static function build_txt_single( $submission_id ) {
		$s = MPFL_Submissions::get( $submission_id );
		if ( ! $s ) {
			return new WP_Error( 'mpfl_missing', __( 'Submission not found.', 'mayfair-forms-leads' ) );
		}
		$values = MPFL_Submissions::get_values( $submission_id );
		$ctx    = array();
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) ) {
				$ctx[ substr( $v['field_key'], 5 ) ] = $v['value'];
			}
		}
		$lines   = array();
		$lines[] = 'MAYFAIR PROPERTIES & DEVELOPERS';
		$lines[] = '';
		$lines[] = 'Submission #' . $s['id'];
		$lines[] = '';
		$lines[] = 'Form: ' . $s['form_name'];
		$lines[] = 'Date: ' . date_i18n( 'j F Y, H:i', strtotime( $s['created_at'] ) );
		$lines[] = 'Status: ' . MPFL_Leads::status_label( $s['status'] );
		$lines[] = '';
		$lines[] = 'Name: ' . $s['name'];
		$lines[] = 'Phone: ' . $s['phone'];
		$lines[] = 'Email: ' . $s['email'];
		$lines[] = '';
		if ( ! empty( $ctx['property_title'] ) || '' !== $s['property_id'] ) {
			$lines[] = 'Property: ' . ( isset( $ctx['property_title'] ) ? $ctx['property_title'] : '' );
			$lines[] = 'Property ID: ' . $s['property_id'];
			$lines[] = '';
		}
		if ( ! empty( $ctx['project_title'] ) ) {
			$lines[] = 'Project: ' . $ctx['project_title'];
			$lines[] = '';
		}
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) || in_array( $v['field_key'], array( 'name', 'email', 'phone' ), true ) ) {
				continue;
			}
			$lines[] = ( $v['field_label'] ? $v['field_label'] : $v['field_key'] ) . ':';
			$lines[] = self::readable_value( $v );
			$lines[] = '';
		}
		$lines[] = 'SOURCE:';
		$lines[] = ucwords( str_replace( '_', ' ', $s['source'] ) );
		if ( $s['utm_source'] ) {
			$lines[] = 'UTM: ' . $s['utm_source'] . ' / ' . $s['utm_medium'] . ' / ' . $s['utm_campaign'];
		}
		$lines[] = '';
		$lines[] = 'Consent: ' . ( $s['consent_state'] ? 'Yes (v' . $s['consent_version'] . ', ' . $s['consent_at'] . ')' : 'No' );
		return implode( "\n", $lines );
	}

	/* ------------------------------------------------------------------ */
	/* PDF                                                                */
	/* ------------------------------------------------------------------ */

	public static function build_pdf_single( $submission_id ) {
		$s = MPFL_Submissions::get( $submission_id );
		if ( ! $s ) {
			return new WP_Error( 'mpfl_missing', __( 'Submission not found.', 'mayfair-forms-leads' ) );
		}
		$values = MPFL_Submissions::get_values( $submission_id );
		$ctx    = array();
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) ) {
				$ctx[ substr( $v['field_key'], 5 ) ] = $v['value'];
			}
		}

		$pdf = new MPFL_PDF();
		$pdf->line( 'MAYFAIR PROPERTIES & DEVELOPERS', 16, true );
		$pdf->line( 'Lead Submission Report', 11 );
		$pdf->rule();
		$pdf->spacer();
		$pdf->line( 'Submission #' . $s['id'], 13, true );
		$pdf->line( 'Form: ' . $s['form_name'], 10 );
		$pdf->line( 'Date: ' . date_i18n( 'j F Y, H:i', strtotime( $s['created_at'] ) ), 10 );
		$pdf->line( 'Status: ' . MPFL_Leads::status_label( $s['status'] ), 10 );
		$pdf->spacer();
		$pdf->line( 'LEAD INFORMATION', 11, true );
		$pdf->line( 'Name: ' . $s['name'], 10, false, 10 );
		$pdf->line( 'Phone: ' . $s['phone'], 10, false, 10 );
		$pdf->line( 'Email: ' . $s['email'], 10, false, 10 );
		$pdf->spacer();
		if ( ! empty( $ctx['property_title'] ) || '' !== $s['property_id'] ) {
			$pdf->line( 'PROPERTY', 11, true );
			$pdf->line( 'Property: ' . ( isset( $ctx['property_title'] ) ? $ctx['property_title'] : '-' ), 10, false, 10 );
			$pdf->line( 'Property ID: ' . ( $s['property_id'] ? $s['property_id'] : '-' ), 10, false, 10 );
			$pdf->spacer();
		}
		if ( ! empty( $ctx['project_title'] ) ) {
			$pdf->line( 'PROJECT', 11, true );
			$pdf->line( 'Project: ' . $ctx['project_title'], 10, false, 10 );
			$pdf->spacer();
		}
		$pdf->line( 'ANSWERS', 11, true );
		foreach ( $values as $v ) {
			if ( 0 === strpos( $v['field_key'], '_ctx_' ) || in_array( $v['field_key'], array( 'name', 'email', 'phone' ), true ) ) {
				continue;
			}
			$label = $v['field_label'] ? $v['field_label'] : $v['field_key'];
			$val   = self::readable_value( $v );
			// Wrap long values at ~80 chars.
			$pdf->line( $label . ':', 10, true, 10 );
			foreach ( str_split( $val, 80 ) as $chunk ) {
				$pdf->line( $chunk, 10, false, 20 );
			}
		}
		$pdf->spacer();
		$pdf->line( 'SOURCE', 11, true );
		$pdf->line( 'Source: ' . ucwords( str_replace( '_', ' ', $s['source'] ) ), 10, false, 10 );
		if ( $s['utm_source'] ) {
			$pdf->line( 'UTM: ' . $s['utm_source'] . ' / ' . $s['utm_medium'] . ' / ' . $s['utm_campaign'], 10, false, 10 );
		}
		$pdf->line( 'Page: ' . $s['page_url'], 10, false, 10 );
		$pdf->spacer();
		$pdf->line( 'CONSENT', 11, true );
		$pdf->line( $s['consent_state'] ? 'Given - version ' . $s['consent_version'] . ' at ' . $s['consent_at'] : 'Not given', 10, false, 10 );
		$pdf->rule();
		$pdf->line( 'Internal reference: MPFL-' . $s['id'] . ' | Generated ' . date_i18n( 'Y-m-d H:i' ), 8 );
		return $pdf->output();
	}

	/* ------------------------------------------------------------------ */
	/* Filenames + download                                               */
	/* ------------------------------------------------------------------ */

	public static function filename( $kind, $ext ) {
		if ( 'single' === $kind[0] ) {
			return sanitize_file_name( 'mayfair-submission-' . $kind[1] . '.' . $ext );
		}
		return sanitize_file_name( 'mayfair-leads-' . gmdate( 'Y-m-d' ) . '.' . $ext );
	}

	/** Stream a download (called from capability-checked admin action). */
	public static function stream( $content, $filename, $mime ) {
		nocache_headers();
		header( 'Content-Type: ' . $mime );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $content ) );
		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary/plain file body, not HTML
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Config backup / restore                                            */
	/* ------------------------------------------------------------------ */

	public static function export_config() {
		$forms = array();
		foreach ( MPFL_Form_Builder::get_forms() as $form ) {
			$form['fields'] = MPFL_Form_Builder::get_fields( $form['id'] );
			$forms[]        = $form;
		}
		return wp_json_encode( array(
			'plugin'   => 'mayfair-forms-leads',
			'version'  => MPFL_VERSION,
			'exported' => gmdate( 'c' ),
			'settings' => MPFL_Database::get_settings(),
			'presets'  => get_option( 'mpfl_export_presets', array() ),
			'forms'    => $forms,
		), JSON_PRETTY_PRINT );
	}

	/** Import config (forms + settings). Never deletes anything silently. */
	public static function import_config( $json ) {
		$data = json_decode( (string) $json, true );
		if ( ! is_array( $data ) || 'mayfair-forms-leads' !== ( isset( $data['plugin'] ) ? $data['plugin'] : '' ) ) {
			return new WP_Error( 'mpfl_import', __( 'Invalid configuration file.', 'mayfair-forms-leads' ) );
		}
		if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
			update_option( 'mpfl_settings', $data['settings'] );
		}
		if ( isset( $data['presets'] ) && is_array( $data['presets'] ) ) {
			update_option( 'mpfl_export_presets', $data['presets'] );
		}
		$imported = 0;
		if ( ! empty( $data['forms'] ) && is_array( $data['forms'] ) ) {
			foreach ( $data['forms'] as $form ) {
				$new_id = MPFL_Form_Builder::create_form( array(
					'name'        => ( isset( $form['name'] ) ? $form['name'] : 'Imported form' ) . ' (Imported)',
					'description' => isset( $form['description'] ) ? $form['description'] : '',
					'form_type'   => isset( $form['form_type'] ) ? $form['form_type'] : 'general',
					'status'      => 'draft',
					'settings'    => isset( $form['settings'] ) ? json_decode( (string) $form['settings'], true ) : array(),
				) );
				if ( is_wp_error( $new_id ) ) {
					continue;
				}
				if ( ! empty( $form['fields'] ) ) {
					foreach ( $form['fields'] as $field ) {
						unset( $field['id'] );
						MPFL_Form_Builder::add_field( $new_id, $field );
					}
				}
				$imported++;
			}
		}
		return $imported;
	}
}
