<?php
/**
 * REST API (optional, capability-gated, read/list only in v1).
 * Private leads are NEVER publicly exposed: every route requires
 * an authenticated user with the right capability.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_REST {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	public static function register_routes() {
		register_rest_route( 'mpfl/v1', '/forms', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'list_forms' ),
			'permission_callback' => function () {
				return current_user_can( 'manage_mayfair_forms' );
			},
		) );

		register_rest_route( 'mpfl/v1', '/submissions', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'list_submissions' ),
			'permission_callback' => function () {
				return current_user_can( 'view_mayfair_leads' );
			},
			'args'                => array(
				'form_id'  => array( 'type' => 'integer', 'required' => false ),
				'status'   => array( 'type' => 'string', 'required' => false ),
				'page'     => array( 'type' => 'integer', 'required' => false, 'default' => 1 ),
				'per_page' => array( 'type' => 'integer', 'required' => false, 'default' => 25 ),
			),
		) );

		register_rest_route( 'mpfl/v1', '/submissions/(?P<id>\d+)', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'get_submission' ),
			'permission_callback' => function () {
				return current_user_can( 'view_mayfair_leads' );
			},
		) );
	}

	public static function list_forms() {
		$forms = MPFL_Form_Builder::get_forms();
		$out   = array();
		foreach ( $forms as $form ) {
			$out[] = array(
				'id'        => (int) $form['id'],
				'name'      => $form['name'],
				'form_type' => $form['form_type'],
				'status'    => $form['status'],
				'version'   => (int) $form['version'],
			);
		}
		return rest_ensure_response( $out );
	}

	public static function list_submissions( WP_REST_Request $request ) {
		$result = MPFL_Submissions::query( array(
			'form_id'  => (int) $request->get_param( 'form_id' ),
			'status'   => (string) $request->get_param( 'status' ),
			'page'     => (int) $request->get_param( 'page' ),
			'per_page' => (int) $request->get_param( 'per_page' ),
		) );
		return rest_ensure_response( $result );
	}

	public static function get_submission( WP_REST_Request $request ) {
		$id  = (int) $request['id'];
		$out = MPFL_Exports::build_json_single( $id );
		if ( is_wp_error( $out ) ) {
			return new WP_Error( 'mpfl_not_found', __( 'Submission not found.', 'mayfair-forms-leads' ), array( 'status' => 404 ) );
		}
		return rest_ensure_response( json_decode( $out, true ) );
	}
}
