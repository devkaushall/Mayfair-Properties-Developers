<?php
/**
 * Elementor widget: Mayfair Form.
 * Presentation controls only — form structure comes from the plugin builder.
 * Style controls use Elementor Global Colors/Fonts defaults so the widget
 * inherits the site design system unless overridden per-widget.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class MPFL_Elementor_Widget extends Widget_Base {

	public function get_name() {
		return 'mayfair_form';
	}

	public function get_title() {
		return __( 'Mayfair Form', 'mayfair-forms-leads' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return array( 'mayfair' );
	}

	public function get_keywords() {
		return array( 'form', 'lead', 'enquiry', 'mayfair', 'property' );
	}

	private function forms_options() {
		$options = array( 0 => __( '— Select a form —', 'mayfair-forms-leads' ) );
		foreach ( MPFL_Form_Builder::get_forms( 'published' ) as $form ) {
			$options[ (int) $form['id'] ] = $form['name'] . ' (#' . $form['id'] . ')';
		}
		return $options;
	}

	protected function register_controls() {

		/* ---------------- Content ---------------- */
		$this->start_controls_section( 'section_form', array( 'label' => __( 'Form', 'mayfair-forms-leads' ) ) );

		$this->add_control( 'form_id', array(
			'label'   => __( 'Form', 'mayfair-forms-leads' ),
			'type'    => Controls_Manager::SELECT,
			'options' => $this->forms_options(),
			'default' => 0,
		) );

		$this->add_control( 'form_mode', array(
			'label'   => __( 'Form Mode', 'mayfair-forms-leads' ),
			'type'    => Controls_Manager::SELECT,
			'options' => array(
				'stacked' => __( 'Stacked', 'mayfair-forms-leads' ),
				'inline'  => __( 'Inline', 'mayfair-forms-leads' ),
				'compact' => __( 'Compact', 'mayfair-forms-leads' ),
			),
			'default' => 'stacked',
		) );

		$this->add_control( 'success_message', array(
			'label'       => __( 'Success Message (override)', 'mayfair-forms-leads' ),
			'type'        => Controls_Manager::TEXTAREA,
			'default'     => '',
			'description' => __( 'Leave empty to use the message configured in the Form Builder.', 'mayfair-forms-leads' ),
		) );

		$this->add_control( 'redirect_url', array(
			'label'   => __( 'Redirect URL (override)', 'mayfair-forms-leads' ),
			'type'    => Controls_Manager::URL,
			'options' => false,
		) );

		$this->add_control( 'button_text', array(
			'label'   => __( 'Button Text (override)', 'mayfair-forms-leads' ),
			'type'    => Controls_Manager::TEXT,
			'default' => '',
		) );

		$this->add_responsive_control( 'form_align', array(
			'label'     => __( 'Alignment', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::CHOOSE,
			'options'   => array(
				'left'   => array( 'title' => __( 'Left', 'mayfair-forms-leads' ), 'icon' => 'eicon-text-align-left' ),
				'center' => array( 'title' => __( 'Center', 'mayfair-forms-leads' ), 'icon' => 'eicon-text-align-center' ),
				'right'  => array( 'title' => __( 'Right', 'mayfair-forms-leads' ), 'icon' => 'eicon-text-align-right' ),
			),
			'selectors' => array( '{{WRAPPER}} .mpfl-actions' => 'text-align: {{VALUE}};' ),
		) );

		$this->add_responsive_control( 'form_width', array(
			'label'      => __( 'Width', 'mayfair-forms-leads' ),
			'type'       => Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range'      => array( 'px' => array( 'min' => 200, 'max' => 1200 ), '%' => array( 'min' => 10, 'max' => 100 ) ),
			'selectors'  => array( '{{WRAPPER}} .mpfl-form' => 'max-width: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_control( 'css_class', array(
			'label' => __( 'CSS Class', 'mayfair-forms-leads' ),
			'type'  => Controls_Manager::TEXT,
		) );

		$this->end_controls_section();

		/* ---------------- Style: Labels ---------------- */
		$this->start_controls_section( 'style_labels', array( 'label' => __( 'Labels', 'mayfair-forms-leads' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array(
			'name'     => 'label_typography',
			'selector' => '{{WRAPPER}} .mpfl-label',
			'global'   => array( 'default' => Global_Typography::TYPOGRAPHY_TEXT ),
		) );
		$this->add_control( 'label_color', array(
			'label'     => __( 'Label Color', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => array( 'default' => Global_Colors::COLOR_TEXT ),
			'selectors' => array( '{{WRAPPER}} .mpfl-label' => 'color: {{VALUE}};' ),
		) );
		$this->end_controls_section();

		/* ---------------- Style: Inputs ---------------- */
		$this->start_controls_section( 'style_inputs', array( 'label' => __( 'Inputs', 'mayfair-forms-leads' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array(
			'name'     => 'input_typography',
			'selector' => '{{WRAPPER}} .mpfl-input',
			'global'   => array( 'default' => Global_Typography::TYPOGRAPHY_TEXT ),
		) );
		$this->add_control( 'input_text_color', array(
			'label'     => __( 'Text Color', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => array( 'default' => Global_Colors::COLOR_TEXT ),
			'selectors' => array( '{{WRAPPER}} .mpfl-input' => 'color: {{VALUE}};' ),
		) );
		$this->add_control( 'input_bg_color', array(
			'label'     => __( 'Background', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-input' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'placeholder_color', array(
			'label'     => __( 'Placeholder Color', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-input::placeholder' => 'color: {{VALUE}};' ),
		) );
		$this->add_group_control( Group_Control_Border::get_type(), array(
			'name'     => 'input_border',
			'selector' => '{{WRAPPER}} .mpfl-input',
		) );
		$this->add_responsive_control( 'input_radius', array(
			'label'      => __( 'Border Radius', 'mayfair-forms-leads' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'selectors'  => array( '{{WRAPPER}} .mpfl-input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_responsive_control( 'input_padding', array(
			'label'      => __( 'Padding', 'mayfair-forms-leads' ),
			'type'       => Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'selectors'  => array( '{{WRAPPER}} .mpfl-input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
		) );
		$this->add_control( 'focus_color', array(
			'label'     => __( 'Focus Accent', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => array( 'default' => Global_Colors::COLOR_ACCENT ),
			'selectors' => array(
				'{{WRAPPER}} .mpfl-input:focus'         => 'border-color: {{VALUE}}; outline-color: {{VALUE}};',
				'{{WRAPPER}} .mpfl-input:focus-visible' => 'outline-color: {{VALUE}};',
			),
		) );
		$this->end_controls_section();

		/* ---------------- Style: Layout ---------------- */
		$this->start_controls_section( 'style_layout', array( 'label' => __( 'Layout', 'mayfair-forms-leads' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_responsive_control( 'field_gap', array(
			'label'     => __( 'Field Gap', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::SLIDER,
			'range'     => array( 'px' => array( 'min' => 0, 'max' => 60 ) ),
			'selectors' => array( '{{WRAPPER}} .mpfl-fields' => 'gap: {{SIZE}}{{UNIT}};' ),
		) );
		$this->add_control( 'mobile_stack', array(
			'label'        => __( 'Stack all fields on mobile', 'mayfair-forms-leads' ),
			'type'         => Controls_Manager::SWITCHER,
			'default'      => 'yes',
			'prefix_class' => 'mpfl-mobile-stack-',
		) );
		$this->end_controls_section();

		/* ---------------- Style: Button ---------------- */
		$this->start_controls_section( 'style_button', array( 'label' => __( 'Button', 'mayfair-forms-leads' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_group_control( Group_Control_Typography::get_type(), array(
			'name'     => 'button_typography',
			'selector' => '{{WRAPPER}} .mpfl-submit',
			'global'   => array( 'default' => Global_Typography::TYPOGRAPHY_ACCENT ),
		) );
		$this->add_control( 'button_bg', array(
			'label'     => __( 'Background', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => array( 'default' => Global_Colors::COLOR_SECONDARY ),
			'selectors' => array( '{{WRAPPER}} .mpfl-submit' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'button_color', array(
			'label'     => __( 'Text Color', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '#FFFFFF',
			'selectors' => array( '{{WRAPPER}} .mpfl-submit' => 'color: {{VALUE}};' ),
		) );
		$this->add_control( 'button_hover_bg', array(
			'label'     => __( 'Hover Background', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'global'    => array( 'default' => Global_Colors::COLOR_ACCENT ),
			'selectors' => array( '{{WRAPPER}} .mpfl-submit:hover, {{WRAPPER}} .mpfl-submit:focus' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_responsive_control( 'button_width', array(
			'label'     => __( 'Button Width', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::SLIDER,
			'size_units' => array( 'px', '%' ),
			'range'     => array( 'px' => array( 'min' => 100, 'max' => 600 ), '%' => array( 'min' => 10, 'max' => 100 ) ),
			'selectors' => array( '{{WRAPPER}} .mpfl-submit' => 'width: {{SIZE}}{{UNIT}};' ),
		) );
		$this->end_controls_section();

		/* ---------------- Style: Messages ---------------- */
		$this->start_controls_section( 'style_messages', array( 'label' => __( 'Messages', 'mayfair-forms-leads' ), 'tab' => Controls_Manager::TAB_STYLE ) );
		$this->add_control( 'success_color', array(
			'label'     => __( 'Success Text', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-success' => 'color: {{VALUE}};' ),
		) );
		$this->add_control( 'success_bg', array(
			'label'     => __( 'Success Background', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-success' => 'background-color: {{VALUE}};' ),
		) );
		$this->add_control( 'error_color', array(
			'label'     => __( 'Error Text', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-error' => 'color: {{VALUE}};' ),
		) );
		$this->add_control( 'error_bg', array(
			'label'     => __( 'Error Background', 'mayfair-forms-leads' ),
			'type'      => Controls_Manager::COLOR,
			'selectors' => array( '{{WRAPPER}} .mpfl-error' => 'background-color: {{VALUE}};' ),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$form_id  = (int) $settings['form_id'];
		if ( ! $form_id ) {
			if ( current_user_can( 'manage_mayfair_forms' ) ) {
				echo '<p>' . esc_html__( 'Mayfair Form: choose a form in the widget settings.', 'mayfair-forms-leads' ) . '</p>';
			}
			return;
		}
		echo MPFL_Form_Renderer::render_form( $form_id, array( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- renderer escapes all output internally
			'mode'            => $settings['form_mode'],
			'success_message' => $settings['success_message'],
			'redirect_url'    => ! empty( $settings['redirect_url']['url'] ) ? $settings['redirect_url']['url'] : '',
			'button_text'     => $settings['button_text'],
			'css_class'       => $settings['css_class'],
		) );
	}
}
