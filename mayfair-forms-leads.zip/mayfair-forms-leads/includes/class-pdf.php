<?php
/**
 * Minimal dependency-free PDF writer for single-submission reports.
 *
 * Generates genuine PDF 1.4 output (Helvetica core font, no compression)
 * without any external library, so there is no licensing question and no
 * bundled dependency. Suitable for clean text-based business documents.
 * If richer PDFs are needed later, swap in a redistributable library
 * (e.g. GPL-compatible FPDF/TCPDF) behind this same class API.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_PDF {

	private $lines = array();

	/** Add a text line: array( text, size, bold, indent ). */
	public function line( $text, $size = 10, $bold = false, $indent = 0 ) {
		// Core-font PDFs are Latin-1; transliterate what we can, replace the rest.
		$text = remove_accents( (string) $text );
		$text = preg_replace( '/[^\x20-\x7E]/', '?', $text );
		$this->lines[] = array( 'text' => $text, 'size' => $size, 'bold' => $bold, 'indent' => $indent );
		return $this;
	}

	public function spacer() {
		$this->lines[] = array( 'text' => '', 'size' => 6, 'bold' => false, 'indent' => 0 );
		return $this;
	}

	public function rule() {
		$this->lines[] = array( 'text' => str_repeat( '_', 78 ), 'size' => 8, 'bold' => false, 'indent' => 0 );
		return $this;
	}

	/** Build the PDF binary string. */
	public function output() {
		// Page geometry: A4 595x842pt, margins 56pt, usable height 730pt.
		$pages     = array();
		$current   = array();
		$y_used    = 0;
		$max_h     = 730;

		foreach ( $this->lines as $ln ) {
			$h = $ln['size'] + 6;
			if ( $y_used + $h > $max_h && ! empty( $current ) ) {
				$pages[]  = $current;
				$current  = array();
				$y_used   = 0;
			}
			$current[] = $ln;
			$y_used   += $h;
		}
		if ( ! empty( $current ) ) {
			$pages[] = $current;
		}
		if ( empty( $pages ) ) {
			$pages[] = array( array( 'text' => '', 'size' => 10, 'bold' => false, 'indent' => 0 ) );
		}

		$objects   = array();
		$objects[] = '<< /Type /Catalog /Pages 2 0 R >>'; // 1
		$kids      = array();
		$page_obj_start = 5; // 1 catalog, 2 pages, 3 font, 4 bold font, then page+content pairs
		$n_pages   = count( $pages );
		for ( $i = 0; $i < $n_pages; $i++ ) {
			$kids[] = ( $page_obj_start + $i * 2 ) . ' 0 R';
		}
		$objects[] = '<< /Type /Pages /Kids [' . implode( ' ', $kids ) . '] /Count ' . $n_pages . ' >>'; // 2
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'; // 3
		$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>'; // 4

		foreach ( $pages as $i => $page_lines ) {
			$content = "BT\n";
			$y       = 786; // top margin
			foreach ( $page_lines as $ln ) {
				$y       -= ( $ln['size'] + 6 );
				$font     = $ln['bold'] ? '/F2' : '/F1';
				$x        = 56 + (int) $ln['indent'];
				$text     = str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), $ln['text'] );
				$content .= sprintf( "%s %d Tf\n1 0 0 1 %d %d Tm\n(%s) Tj\n", $font, (int) $ln['size'], $x, $y, $text );
			}
			$content .= 'ET';

			$page_num    = $page_obj_start + $i * 2;
			$content_num = $page_num + 1;
			$objects[]   = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ' . $content_num . ' 0 R >>';
			$objects[]   = '__STREAM__' . $content;
		}

		// Assemble with xref.
		$pdf     = "%PDF-1.4\n";
		$offsets = array();
		foreach ( $objects as $index => $body ) {
			$num       = $index + 1;
			$offsets[] = strlen( $pdf );
			if ( 0 === strpos( $body, '__STREAM__' ) ) {
				$stream = substr( $body, 10 );
				$pdf   .= $num . " 0 obj\n<< /Length " . strlen( $stream ) . " >>\nstream\n" . $stream . "\nendstream\nendobj\n";
			} else {
				$pdf .= $num . " 0 obj\n" . $body . "\nendobj\n";
			}
		}
		$xref_pos = strlen( $pdf );
		$count    = count( $objects ) + 1;
		$pdf     .= "xref\n0 " . $count . "\n0000000000 65535 f \n";
		foreach ( $offsets as $off ) {
			$pdf .= sprintf( "%010d 00000 n \n", $off );
		}
		$pdf .= "trailer\n<< /Size " . $count . " /Root 1 0 R >>\nstartxref\n" . $xref_pos . "\n%%EOF";
		return $pdf;
	}
}
