<?php
/**
 * Submission creation, querying, analytics counters.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Submissions {

	/**
	 * Create a submission from the current validated POST request.
	 * Security gates already passed in the caller.
	 *
	 * @return int|WP_Error submission id.
	 */
	public static function create_from_request( $form_id ) {
		global $wpdb;

		$form = MPFL_Form_Builder::get_form( $form_id );
		if ( ! $form || 'published' !== $form['status'] ) {
			return new WP_Error( 'mpfl_form', __( 'This form is not accepting submissions.', 'mayfair-forms-leads' ) );
		}
		$settings = json_decode( (string) $form['settings'], true );
		$settings = is_array( $settings ) ? $settings : array();
		$fields   = MPFL_Form_Builder::get_fields( $form_id );

		// 1) Collect + sanitize raw values first (needed for conditional evaluation).
		$raw = array();
		foreach ( $fields as $field ) {
			$post_key = 'mpfl_f_' . $field['field_key'];
			if ( 'file' === $field['field_type'] ) {
				continue;
			}
			$value = isset( $_POST[ $post_key ] ) ? MPFL_Security::sanitize_value( $field['field_type'], $_POST[ $post_key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by type in helper
			$raw[ $field['field_key'] ] = $value;
		}

		// 2) Validate server-side, honouring conditional visibility (hidden fields aren't required).
		$values = array();
		foreach ( $fields as $field ) {
			if ( ! MPFL_Form_Builder::conditions_met( $field['conditions'], $raw ) ) {
				continue; // field hidden by logic — skip entirely
			}
			if ( 'file' === $field['field_type'] ) {
				$file_key = 'mpfl_f_' . $field['field_key'];
				if ( ! empty( $_FILES[ $file_key ]['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
					$upload = MPFL_Security::handle_upload( array_map( 'sanitize_text_field', array(
						'name'     => isset( $_FILES[ $file_key ]['name'] ) ? $_FILES[ $file_key ]['name'] : '',
						'type'     => isset( $_FILES[ $file_key ]['type'] ) ? $_FILES[ $file_key ]['type'] : '',
						'tmp_name' => isset( $_FILES[ $file_key ]['tmp_name'] ) ? $_FILES[ $file_key ]['tmp_name'] : '',
						'error'    => isset( $_FILES[ $file_key ]['error'] ) ? $_FILES[ $file_key ]['error'] : 0,
						'size'     => isset( $_FILES[ $file_key ]['size'] ) ? $_FILES[ $file_key ]['size'] : 0,
					) ) );
					if ( is_wp_error( $upload ) ) {
						return $upload;
					}
					$values[ $field['field_key'] ] = array( 'field' => $field, 'value' => wp_json_encode( $upload ) );
				} elseif ( ! empty( $field['required'] ) ) {
					return new WP_Error( 'mpfl_required', sprintf( /* translators: %s label */ __( '%s is required.', 'mayfair-forms-leads' ), $field['label'] ) );
				}
				continue;
			}
			$valid = MPFL_Security::validate_value( $field, $raw[ $field['field_key'] ] );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}
			$values[ $field['field_key'] ] = array( 'field' => $field, 'value' => $raw[ $field['field_key'] ] );
		}

		// 3) Context (hidden metadata, sanitized).
		$ctx = array();
		foreach ( array( 'property_post_id', 'property_title', 'property_url', 'property_id', 'property_type', 'location', 'property_status', 'project_post_id', 'project_title', 'project_url', 'project_type' ) as $ckey ) {
			$pkey = 'mpfl_ctx_' . $ckey;
			$ctx[ $ckey ] = isset( $_POST[ $pkey ] ) ? sanitize_text_field( wp_unslash( $_POST[ $pkey ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}
		// Re-verify post ids server-side: only accept ids that really are property/project posts.
		$property_post_id = (int) $ctx['property_post_id'];
		if ( $property_post_id && 'property' !== get_post_type( $property_post_id ) ) {
			$property_post_id = 0;
		}
		$project_post_id = (int) $ctx['project_post_id'];
		if ( $project_post_id && 'project' !== get_post_type( $project_post_id ) ) {
			$project_post_id = 0;
		}

		$page_url = isset( $_POST['mpfl_page_url'] ) ? esc_url_raw( wp_unslash( $_POST['mpfl_page_url'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$referrer = isset( $_POST['mpfl_referrer'] ) ? esc_url_raw( wp_unslash( $_POST['mpfl_referrer'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$utm      = array();
		foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ) as $u ) {
			$utm[ $u ] = isset( $_POST[ 'mpfl_' . $u ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'mpfl_' . $u ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		// 4) Lead identity from common keys.
		$name  = isset( $values['name'] ) ? (string) $values['name']['value'] : '';
		$email = isset( $values['email'] ) ? (string) $values['email']['value'] : '';
		$phone = isset( $values['phone'] ) ? (string) $values['phone']['value'] : '';

		// 5) Consent.
		$consent_state = 0;
		$app_settings  = MPFL_Database::get_settings();
		foreach ( $values as $fk => $bundle ) {
			if ( 'consent' === $bundle['field']['field_type'] && ! empty( $bundle['value'] ) ) {
				$consent_state = 1;
			}
		}

		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 250 ) : '';

		$now = current_time( 'mysql' );
		$wpdb->insert(
			MPFL_Database::table( 'submissions' ),
			array(
				'form_id'          => (int) $form_id,
				'form_name'        => $form['name'],
				'status'           => 'new',
				'lead_type'        => isset( $settings['lead_type'] ) ? $settings['lead_type'] : '',
				'name'             => $name,
				'email'            => $email,
				'phone'            => $phone,
				'property_id'      => $ctx['property_id'],
				'property_post_id' => $property_post_id ? $property_post_id : null,
				'project_post_id'  => $project_post_id ? $project_post_id : null,
				'source'           => MPFL_Leads::classify_source( $referrer, $utm['utm_source'] ),
				'page_url'         => $page_url,
				'referrer'         => $referrer,
				'utm_source'       => $utm['utm_source'],
				'utm_medium'       => $utm['utm_medium'],
				'utm_campaign'     => $utm['utm_campaign'],
				'utm_term'         => $utm['utm_term'],
				'utm_content'      => $utm['utm_content'],
				'user_agent'       => $ua,
				'ip_hash'          => MPFL_Security::ip_for_storage(),
				'consent_state'    => $consent_state,
				'consent_version'  => $consent_state ? $app_settings['consent_version'] : '',
				'consent_at'       => $consent_state ? $now : null,
				'created_at'       => $now,
				'updated_at'       => $now,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);
		$submission_id = (int) $wpdb->insert_id;
		if ( ! $submission_id ) {
			return new WP_Error( 'mpfl_db', __( 'Could not save your enquiry. Please try again.', 'mayfair-forms-leads' ) );
		}

		// 6) Store answers.
		foreach ( $values as $fk => $bundle ) {
			$field = $bundle['field'];
			$value = is_array( $bundle['value'] ) ? wp_json_encode( $bundle['value'] ) : (string) $bundle['value'];
			$wpdb->insert(
				MPFL_Database::table( 'submission_values' ),
				array(
					'submission_id' => $submission_id,
					'field_key'     => $field['field_key'],
					'field_label'   => $field['export_label'] ? $field['export_label'] : $field['label'],
					'field_type'    => $field['field_type'],
					'value'         => $value,
				),
				array( '%d', '%s', '%s', '%s', '%s' )
			);
		}
		// Store context titles as values too (so exports show them without joins).
		foreach ( array( 'property_title', 'property_url', 'project_title', 'project_url' ) as $ckey ) {
			if ( '' !== $ctx[ $ckey ] ) {
				$wpdb->insert(
					MPFL_Database::table( 'submission_values' ),
					array(
						'submission_id' => $submission_id,
						'field_key'     => '_ctx_' . $ckey,
						'field_label'   => ucwords( str_replace( '_', ' ', $ckey ) ),
						'field_type'    => 'context',
						'value'         => $ctx[ $ckey ],
					),
					array( '%d', '%s', '%s', '%s', '%s' )
				);
			}
		}

		MPFL_Leads::log_event( $submission_id, 'created', array( 'form' => $form['name'] ) );

		// 7) Notifications + webhook. Email failure NEVER loses the lead — it's already stored.
		if ( ! empty( $settings['notify_admin'] ) ) {
			MPFL_Email::notify_admin( $submission_id );
		}
		if ( ! empty( $settings['notify_visitor'] ) && '' !== $email ) {
			MPFL_Email::notify_visitor( $submission_id, $email );
		}
		if ( ! empty( $settings['webhook_enabled'] ) ) {
			MPFL_Webhooks::dispatch( $submission_id );
		}

		/** Fires after a submission is fully stored. CRM/SMS/WhatsApp integrations hook here later. */
		do_action( 'mpfl_submission_created', $submission_id, $form_id );

		return $submission_id;
	}

	/* ------------------------------------------------------------------ */
	/* Querying                                                           */
	/* ------------------------------------------------------------------ */

	/**
	 * Query submissions with filters. All filter clauses are prepared.
	 *
	 * @param array $filters form_id, status, source, property_post_id, project_post_id,
	 *                       assigned_user, date_from, date_to, search, page, per_page.
	 */
	public static function query( $filters = array() ) {
		global $wpdb;
		$table = MPFL_Database::table( 'submissions' );

		$where  = array( '1=1' );
		$params = array();

		if ( ! empty( $filters['form_id'] ) ) {
			$where[]  = 'form_id = %d';
			$params[] = (int) $filters['form_id'];
		}
		if ( ! empty( $filters['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $filters['status'] );
		}
		if ( ! empty( $filters['source'] ) ) {
			$where[]  = 'source = %s';
			$params[] = sanitize_key( $filters['source'] );
		}
		if ( ! empty( $filters['property_post_id'] ) ) {
			$where[]  = 'property_post_id = %d';
			$params[] = (int) $filters['property_post_id'];
		}
		if ( ! empty( $filters['project_post_id'] ) ) {
			$where[]  = 'project_post_id = %d';
			$params[] = (int) $filters['project_post_id'];
		}
		if ( ! empty( $filters['assigned_user'] ) ) {
			$where[]  = 'assigned_user = %d';
			$params[] = (int) $filters['assigned_user'];
		}
		if ( ! empty( $filters['date_from'] ) ) {
			$where[]  = 'created_at >= %s';
			$params[] = sanitize_text_field( $filters['date_from'] ) . ' 00:00:00';
		}
		if ( ! empty( $filters['date_to'] ) ) {
			$where[]  = 'created_at <= %s';
			$params[] = sanitize_text_field( $filters['date_to'] ) . ' 23:59:59';
		}
		if ( ! empty( $filters['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( sanitize_text_field( $filters['search'] ) ) . '%';
			$where[]  = '(name LIKE %s OR email LIKE %s OR phone LIKE %s OR form_name LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$per_page = ! empty( $filters['per_page'] ) ? min( 200, max( 1, (int) $filters['per_page'] ) ) : 25;
		$page     = ! empty( $filters['page'] ) ? max( 1, (int) $filters['page'] ) : 1;
		$offset   = ( $page - 1 ) * $per_page;

		$where_sql = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total     = $params ? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : (int) $wpdb->get_var( $count_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$list_sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at DESC LIMIT %d OFFSET %d";
		$rows     = $wpdb->get_results( $wpdb->prepare( $list_sql, array_merge( $params, array( $per_page, $offset ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return array( 'total' => $total, 'rows' => $rows, 'page' => $page, 'per_page' => $per_page );
	}

	public static function get( $submission_id ) {
		global $wpdb;
		$table = MPFL_Database::table( 'submissions' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $submission_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function get_values( $submission_id ) {
		global $wpdb;
		$table = MPFL_Database::table( 'submission_values' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE submission_id = %d ORDER BY id ASC", $submission_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function delete( $submission_id ) {
		global $wpdb;
		$wpdb->delete( MPFL_Database::table( 'submission_values' ), array( 'submission_id' => (int) $submission_id ), array( '%d' ) );
		$wpdb->delete( MPFL_Database::table( 'submission_events' ), array( 'submission_id' => (int) $submission_id ), array( '%d' ) );
		$wpdb->delete( MPFL_Database::table( 'submissions' ), array( 'id' => (int) $submission_id ), array( '%d' ) );
		return true;
	}

	/** Overview counters for the dashboard. */
	public static function counters() {
		global $wpdb;
		$table = MPFL_Database::table( 'submissions' );

		$counts = array( 'total' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( array( 'new', 'contacted', 'qualified', 'site_visit_scheduled', 'site_visit_completed', 'won', 'lost' ) as $status ) {
			$counts[ $status ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $status ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		$counts['today'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-d' ) . ' 00:00:00' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$counts['week']  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-d', strtotime( 'monday this week' ) ) . ' 00:00:00' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$counts['month'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s", gmdate( 'Y-m-01' ) . ' 00:00:00' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Sources.
		$counts['sources'] = $wpdb->get_results( "SELECT source, COUNT(*) AS n FROM {$table} GROUP BY source ORDER BY n DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Property vs project enquiries.
		$counts['property_enquiries'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE property_post_id IS NOT NULL" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$counts['project_enquiries']  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE project_post_id IS NOT NULL" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		foreach ( array( 'buyer', 'seller', 'visit' ) as $lt ) {
			$counts[ 'lead_' . $lt ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE lead_type = %s", $lt ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $counts;
	}
}
