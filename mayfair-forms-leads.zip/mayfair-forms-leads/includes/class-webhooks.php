<?php
/**
 * Configurable webhook dispatch (CRM / Sheets / Zapier / Make ready).
 * No third-party service hardcoded. Attempts are logged to the timeline.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Webhooks {

	/** Webhook config lives in an option; editable in Settings. */
	public static function config() {
		$defaults = array(
			'enabled' => 0,
			'url'     => '',
			'method'  => 'POST',
			'headers' => array( 'Content-Type' => 'application/json' ),
			'timeout' => 8,
		);
		$saved = get_option( 'mpfl_webhook', array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	}

	public static function dispatch( $submission_id ) {
		$config = self::config();
		if ( empty( $config['enabled'] ) || empty( $config['url'] ) ) {
			return false;
		}
		$url = esc_url_raw( $config['url'] );
		if ( '' === $url || 0 !== strpos( $url, 'https://' ) ) {
			MPFL_Leads::log_event( $submission_id, 'webhook_attempted', array( 'result' => 'skipped: webhook URL must be https' ) );
			return false;
		}

		$payload = MPFL_Exports::build_json_single( $submission_id );
		if ( is_wp_error( $payload ) ) {
			return false;
		}

		$headers = array();
		foreach ( (array) $config['headers'] as $k => $v ) {
			$headers[ sanitize_text_field( $k ) ] = sanitize_text_field( $v );
		}

		$args = array(
			'method'  => ( 'PUT' === strtoupper( $config['method'] ) ) ? 'PUT' : 'POST',
			'timeout' => min( 15, max( 3, (int) $config['timeout'] ) ),
			'headers' => $headers,
			'body'    => $payload,
		);

		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			MPFL_Leads::log_event( $submission_id, 'webhook_attempted', array( 'result' => 'error: ' . $response->get_error_message() ) );
			return false;
		}
		$code = wp_remote_retrieve_response_code( $response );
		MPFL_Leads::log_event( $submission_id, 'webhook_attempted', array( 'result' => 'http ' . $code ) );

		/** Fires after a webhook attempt. */
		do_action( 'mpfl_webhook_dispatched', $submission_id, $code );
		return $code >= 200 && $code < 300;
	}
}
