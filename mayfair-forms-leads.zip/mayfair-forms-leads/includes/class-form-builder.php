<?php
/**
 * Form CRUD + field CRUD (the data layer of the admin Form Builder).
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Form_Builder {

	/** Supported field types (curated — no obscure types). */
	public static function field_types() {
		return array(
			'text'           => 'Text',
			'email'          => 'Email',
			'phone'          => 'Phone',
			'number'         => 'Number',
			'textarea'       => 'Textarea',
			'select'         => 'Select',
			'radio'          => 'Radio',
			'checkbox'       => 'Checkbox',
			'checkbox_group' => 'Checkbox Group',
			'date'           => 'Date',
			'time'           => 'Time',
			'datetime'       => 'Date + Time',
			'url'            => 'URL',
			'hidden'         => 'Hidden',
			'consent'        => 'Consent',
			'file'           => 'File Upload',
			'property'       => 'Property Selector',
			'project'        => 'Project Selector',
			'location'       => 'Location Selector',
			'property_type'  => 'Property Type Selector',
			'status'         => 'Status Selector',
			'bedrooms'       => 'Bedrooms Selector',
			'budget_range'   => 'Budget Range',
			'html'           => 'Custom HTML/Text',
		);
	}

	/* ------------------------------------------------------------------ */
	/* Forms                                                              */
	/* ------------------------------------------------------------------ */

	public static function create_form( $data ) {
		global $wpdb;
		$now  = current_time( 'mysql' );
		$name = isset( $data['name'] ) ? sanitize_text_field( $data['name'] ) : '';
		if ( '' === $name ) {
			return new WP_Error( 'mpfl_form_name', __( 'Form name is required.', 'mayfair-forms-leads' ) );
		}
		$wpdb->insert(
			MPFL_Database::table( 'forms' ),
			array(
				'name'        => $name,
				'slug'        => sanitize_title( $name ) . '-' . wp_generate_password( 6, false, false ),
				'description' => isset( $data['description'] ) ? sanitize_textarea_field( $data['description'] ) : '',
				'form_type'   => isset( $data['form_type'] ) ? sanitize_key( $data['form_type'] ) : 'general',
				'status'      => isset( $data['status'] ) && in_array( $data['status'], array( 'draft', 'published', 'inactive' ), true ) ? $data['status'] : 'draft',
				'version'     => 1,
				'settings'    => isset( $data['settings'] ) ? wp_json_encode( self::sanitize_form_settings( $data['settings'] ) ) : wp_json_encode( array() ),
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function update_form( $form_id, $data ) {
		global $wpdb;
		$form = self::get_form( $form_id );
		if ( ! $form ) {
			return new WP_Error( 'mpfl_form_missing', __( 'Form not found.', 'mayfair-forms-leads' ) );
		}
		$update = array( 'updated_at' => current_time( 'mysql' ), 'version' => (int) $form['version'] + 1 );
		$format = array( '%s', '%d' );
		if ( isset( $data['name'] ) ) {
			$update['name'] = sanitize_text_field( $data['name'] );
			$format[]       = '%s';
		}
		if ( isset( $data['description'] ) ) {
			$update['description'] = sanitize_textarea_field( $data['description'] );
			$format[]              = '%s';
		}
		if ( isset( $data['form_type'] ) ) {
			$update['form_type'] = sanitize_key( $data['form_type'] );
			$format[]            = '%s';
		}
		if ( isset( $data['status'] ) && in_array( $data['status'], array( 'draft', 'published', 'inactive' ), true ) ) {
			$update['status'] = $data['status'];
			$format[]         = '%s';
		}
		if ( isset( $data['settings'] ) ) {
			$update['settings'] = wp_json_encode( self::sanitize_form_settings( $data['settings'] ) );
			$format[]           = '%s';
		}
		$wpdb->update( MPFL_Database::table( 'forms' ), $update, array( 'id' => (int) $form_id ), $format, array( '%d' ) );
		return true;
	}

	/** Duplicate a form + all its fields. Templates stay intact; the copy is edited. */
	public static function duplicate_form( $form_id ) {
		global $wpdb;
		$form = self::get_form( $form_id );
		if ( ! $form ) {
			return new WP_Error( 'mpfl_form_missing', __( 'Form not found.', 'mayfair-forms-leads' ) );
		}
		$new_id = self::create_form( array(
			'name'        => $form['name'] . ' (Copy)',
			'description' => $form['description'],
			'form_type'   => $form['form_type'],
			'status'      => 'draft',
			'settings'    => json_decode( (string) $form['settings'], true ),
		) );
		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}
		foreach ( self::get_fields( $form_id ) as $field ) {
			unset( $field['id'] );
			$field['form_id'] = $new_id;
			self::add_field( $new_id, $field );
		}
		return $new_id;
	}

	public static function delete_form( $form_id ) {
		global $wpdb;
		// Submissions are preserved on purpose — deleting a form never deletes leads.
		$wpdb->delete( MPFL_Database::table( 'form_fields' ), array( 'form_id' => (int) $form_id ), array( '%d' ) );
		$wpdb->delete( MPFL_Database::table( 'forms' ), array( 'id' => (int) $form_id ), array( '%d' ) );
		return true;
	}

	public static function get_form( $form_id ) {
		global $wpdb;
		$table = MPFL_Database::table( 'forms' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $form_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function get_forms( $status = '' ) {
		global $wpdb;
		$table = MPFL_Database::table( 'forms' );
		if ( '' !== $status ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY updated_at DESC", $status ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY updated_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	private static function sanitize_form_settings( $settings ) {
		$settings = is_array( $settings ) ? $settings : array();
		$clean    = array();
		$clean['success_message'] = isset( $settings['success_message'] ) ? sanitize_textarea_field( $settings['success_message'] ) : __( 'Thank you — your enquiry has been received.', 'mayfair-forms-leads' );
		$clean['redirect_url']    = isset( $settings['redirect_url'] ) ? esc_url_raw( $settings['redirect_url'] ) : '';
		$clean['button_text']     = isset( $settings['button_text'] ) ? sanitize_text_field( $settings['button_text'] ) : __( 'Submit', 'mayfair-forms-leads' );
		$clean['notify_admin']    = ! empty( $settings['notify_admin'] ) ? 1 : 0;
		$clean['notify_visitor']  = ! empty( $settings['notify_visitor'] ) ? 1 : 0;
		$clean['webhook_enabled'] = ! empty( $settings['webhook_enabled'] ) ? 1 : 0;
		$clean['lead_type']       = isset( $settings['lead_type'] ) ? sanitize_key( $settings['lead_type'] ) : '';
		$clean['design_preset']   = isset( $settings['design_preset'] ) ? sanitize_key( $settings['design_preset'] ) : 'mayfair-heritage';
		return $clean;
	}

	/* ------------------------------------------------------------------ */
	/* Fields                                                             */
	/* ------------------------------------------------------------------ */

	public static function add_field( $form_id, $data ) {
		global $wpdb;
		$types = self::field_types();
		$type  = isset( $data['field_type'] ) && isset( $types[ $data['field_type'] ] ) ? $data['field_type'] : 'text';
		$key   = isset( $data['field_key'] ) ? sanitize_key( $data['field_key'] ) : '';
		if ( '' === $key ) {
			$key = sanitize_key( 'f_' . ( isset( $data['label'] ) ? $data['label'] : $type ) . '_' . wp_rand( 100, 999 ) );
		}
		$wpdb->insert(
			MPFL_Database::table( 'form_fields' ),
			array(
				'form_id'       => (int) $form_id,
				'field_key'     => $key,
				'field_type'    => $type,
				'label'         => isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : '',
				'placeholder'   => isset( $data['placeholder'] ) ? sanitize_text_field( $data['placeholder'] ) : '',
				'description'   => isset( $data['description'] ) ? sanitize_textarea_field( $data['description'] ) : '',
				'required'      => ! empty( $data['required'] ) ? 1 : 0,
				'default_value' => isset( $data['default_value'] ) ? sanitize_textarea_field( $data['default_value'] ) : '',
				'css_class'     => isset( $data['css_class'] ) ? sanitize_html_class( $data['css_class'] ) : '',
				'width'         => isset( $data['width'] ) && in_array( (string) $data['width'], array( '25', '33', '50', '66', '75', '100' ), true ) ? (string) $data['width'] : '100',
				'sort_order'    => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0,
				'validation'    => isset( $data['validation'] ) ? wp_json_encode( self::sanitize_scalar_map( $data['validation'] ) ) : null,
				'conditions'    => isset( $data['conditions'] ) ? wp_json_encode( self::sanitize_conditions( $data['conditions'] ) ) : null,
				'options'       => isset( $data['options'] ) ? wp_json_encode( array_map( 'sanitize_text_field', (array) $data['options'] ) ) : null,
				'admin_only'    => ! empty( $data['admin_only'] ) ? 1 : 0,
				'export_label'  => isset( $data['export_label'] ) ? sanitize_text_field( $data['export_label'] ) : '',
				'privacy_flag'  => ! empty( $data['privacy_flag'] ) ? 1 : 0,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%d' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function update_field( $field_id, $data ) {
		global $wpdb;
		$data['sort_order'] = isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0;
		$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT form_id FROM ' . MPFL_Database::table( 'form_fields' ) . ' WHERE id = %d', $field_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! $existing ) {
			return new WP_Error( 'mpfl_field_missing', __( 'Field not found.', 'mayfair-forms-leads' ) );
		}
		$wpdb->delete( MPFL_Database::table( 'form_fields' ), array( 'id' => (int) $field_id ), array( '%d' ) );
		$data['form_id'] = $existing['form_id'];
		return self::add_field( $existing['form_id'], $data );
	}

	public static function delete_field( $field_id ) {
		global $wpdb;
		$wpdb->delete( MPFL_Database::table( 'form_fields' ), array( 'id' => (int) $field_id ), array( '%d' ) );
		return true;
	}

	public static function reorder_fields( $form_id, $ordered_ids ) {
		global $wpdb;
		foreach ( array_values( (array) $ordered_ids ) as $index => $field_id ) {
			$wpdb->update(
				MPFL_Database::table( 'form_fields' ),
				array( 'sort_order' => (int) $index ),
				array( 'id' => (int) $field_id, 'form_id' => (int) $form_id ),
				array( '%d' ),
				array( '%d', '%d' )
			);
		}
		return true;
	}

	/** All fields for a form, decoded, ordered. */
	public static function get_fields( $form_id ) {
		global $wpdb;
		$table = MPFL_Database::table( 'form_fields' );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE form_id = %d ORDER BY sort_order ASC, id ASC", $form_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		foreach ( $rows as &$row ) {
			$row['validation'] = ! empty( $row['validation'] ) ? json_decode( $row['validation'], true ) : array();
			$row['conditions'] = ! empty( $row['conditions'] ) ? json_decode( $row['conditions'], true ) : array();
			$row['options']    = ! empty( $row['options'] ) ? json_decode( $row['options'], true ) : array();
		}
		return $rows;
	}

	private static function sanitize_scalar_map( $map ) {
		$clean = array();
		foreach ( (array) $map as $k => $v ) {
			$clean[ sanitize_key( $k ) ] = sanitize_text_field( (string) $v );
		}
		return $clean;
	}

	/**
	 * Conditions structure (v1 — simple by design):
	 * { "relation": "AND"|"OR", "rules": [ { "field": "field_key", "operator": "is"|"is_not"|"contains", "value": "..." } ] }
	 */
	private static function sanitize_conditions( $conditions ) {
		$conditions = is_array( $conditions ) ? $conditions : array();
		$clean      = array(
			'relation' => ( isset( $conditions['relation'] ) && 'OR' === strtoupper( $conditions['relation'] ) ) ? 'OR' : 'AND',
			'rules'    => array(),
		);
		if ( ! empty( $conditions['rules'] ) && is_array( $conditions['rules'] ) ) {
			foreach ( $conditions['rules'] as $rule ) {
				if ( empty( $rule['field'] ) ) {
					continue;
				}
				$clean['rules'][] = array(
					'field'    => sanitize_key( $rule['field'] ),
					'operator' => isset( $rule['operator'] ) && in_array( $rule['operator'], array( 'is', 'is_not', 'contains' ), true ) ? $rule['operator'] : 'is',
					'value'    => isset( $rule['value'] ) ? sanitize_text_field( $rule['value'] ) : '',
				);
			}
		}
		return $clean;
	}

	/** Evaluate conditional visibility server-side against submitted values. */
	public static function conditions_met( $conditions, $submitted ) {
		if ( empty( $conditions ) || empty( $conditions['rules'] ) ) {
			return true;
		}
		$results = array();
		foreach ( $conditions['rules'] as $rule ) {
			$actual = isset( $submitted[ $rule['field'] ] ) ? $submitted[ $rule['field'] ] : '';
			$actual = is_array( $actual ) ? implode( ',', $actual ) : (string) $actual;
			switch ( $rule['operator'] ) {
				case 'is_not':
					$results[] = ( $actual !== (string) $rule['value'] );
					break;
				case 'contains':
					$results[] = ( '' !== $rule['value'] && false !== strpos( $actual, (string) $rule['value'] ) );
					break;
				default:
					$results[] = ( $actual === (string) $rule['value'] );
			}
		}
		return ( 'OR' === $conditions['relation'] ) ? in_array( true, $results, true ) : ! in_array( false, $results, true );
	}
}
