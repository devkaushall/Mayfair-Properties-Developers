<?php
/**
 * Elementor integration: 'Mayfair' category + 'Mayfair Form' widget.
 * Loads only when Elementor is present. The backend never depends on Elementor.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Elementor {

	public static function init() {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widget' ) );
	}

	public static function register_category( $elements_manager ) {
		$elements_manager->add_category( 'mayfair', array(
			'title' => __( 'Mayfair', 'mayfair-forms-leads' ),
			'icon'  => 'fa fa-building',
		) );
	}

	public static function register_widget( $widgets_manager ) {
		require_once MPFL_DIR . 'includes/class-elementor-widget.php';
		$widgets_manager->register( new MPFL_Elementor_Widget() );
	}
}
