<?php
/**
 * Built-in real-estate form templates + reusable field presets.
 * Templates are seeded as normal editable forms — never locked.
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPFL_Templates {

	/** Reusable field presets (Buyer / Seller / Visit / Investor / Loan). */
	public static function field_presets() {
		return array(
			'buyer'    => array(
				array( 'field_type' => 'budget_range', 'field_key' => 'budget', 'label' => 'Budget (INR)', 'required' => 1 ),
				array( 'field_type' => 'property_type', 'field_key' => 'preferred_type', 'label' => 'Property Type' ),
				array( 'field_type' => 'location', 'field_key' => 'preferred_location', 'label' => 'Preferred Location' ),
				array( 'field_type' => 'bedrooms', 'field_key' => 'bedrooms', 'label' => 'Bedrooms', 'options' => array( '1', '2', '3', '4', '5+' ) ),
				array( 'field_type' => 'select', 'field_key' => 'timeline', 'label' => 'Purchase Timeline', 'options' => array( 'Immediately', '1-3 months', '3-6 months', '6-12 months', 'Exploring' ) ),
			),
			'seller'   => array(
				array( 'field_type' => 'property_type', 'field_key' => 'sell_type', 'label' => 'Property Type', 'required' => 1 ),
				array( 'field_type' => 'location', 'field_key' => 'sell_location', 'label' => 'Location', 'required' => 1 ),
				array( 'field_type' => 'number', 'field_key' => 'sell_area', 'label' => 'Area (sq.ft.)' ),
				array( 'field_type' => 'budget_range', 'field_key' => 'expected_price', 'label' => 'Expected Price (INR)' ),
				array( 'field_type' => 'select', 'field_key' => 'ownership', 'label' => 'Ownership', 'options' => array( 'Freehold', 'Leasehold', 'Power of Attorney', 'Other' ) ),
			),
			'visit'    => array(
				array( 'field_type' => 'property', 'field_key' => 'visit_property', 'label' => 'Property' ),
				array( 'field_type' => 'date', 'field_key' => 'visit_date', 'label' => 'Preferred Date', 'required' => 1 ),
				array( 'field_type' => 'time', 'field_key' => 'visit_time', 'label' => 'Preferred Time' ),
				array( 'field_type' => 'number', 'field_key' => 'visitors', 'label' => 'Number of Visitors', 'validation' => array( 'min' => '1', 'max' => '20' ) ),
			),
			'investor' => array(
				array( 'field_type' => 'budget_range', 'field_key' => 'investment_budget', 'label' => 'Investment Budget (INR)', 'required' => 1 ),
				array( 'field_type' => 'location', 'field_key' => 'inv_location', 'label' => 'Preferred Location' ),
				array( 'field_type' => 'property_type', 'field_key' => 'inv_type', 'label' => 'Property Type' ),
				array( 'field_type' => 'select', 'field_key' => 'inv_timeline', 'label' => 'Timeline', 'options' => array( 'Immediately', '1-3 months', '3-6 months', 'This year' ) ),
				array( 'field_type' => 'select', 'field_key' => 'objective', 'label' => 'Objective', 'options' => array( 'Rental income', 'Capital appreciation', 'Both', 'Undecided' ) ),
			),
			'loan'     => array(
				array( 'field_type' => 'property', 'field_key' => 'loan_property', 'label' => 'Property' ),
				array( 'field_type' => 'budget_range', 'field_key' => 'loan_budget', 'label' => 'Property Budget (INR)' ),
				array( 'field_type' => 'budget_range', 'field_key' => 'loan_amount', 'label' => 'Loan Requirement (INR)', 'required' => 1 ),
				array( 'field_type' => 'select', 'field_key' => 'employment', 'label' => 'Employment Category', 'options' => array( 'Salaried', 'Self-employed professional', 'Business owner', 'NRI', 'Other' ) ),
				array( 'field_type' => 'select', 'field_key' => 'loan_timeline', 'label' => 'Timeline', 'options' => array( 'Immediately', '1-3 months', '3-6 months' ) ),
			),
		);
	}

	/** Base contact fields shared by all templates. */
	private static function contact_fields() {
		return array(
			array( 'field_type' => 'text', 'field_key' => 'name', 'label' => 'Full Name', 'required' => 1, 'width' => '50' ),
			array( 'field_type' => 'phone', 'field_key' => 'phone', 'label' => 'Phone', 'required' => 1, 'width' => '50' ),
			array( 'field_type' => 'email', 'field_key' => 'email', 'label' => 'Email', 'required' => 1 ),
		);
	}

	private static function message_field( $label = 'Message' ) {
		return array( 'field_type' => 'textarea', 'field_key' => 'message', 'label' => $label );
	}

	private static function consent_field() {
		return array( 'field_type' => 'consent', 'field_key' => 'consent', 'label' => 'Consent', 'required' => 1 );
	}

	/** The 12 built-in templates. */
	public static function definitions() {
		$presets = self::field_presets();
		return array(
			'general_enquiry'    => array( 'name' => 'General Enquiry', 'lead_type' => 'general', 'fields' => array_merge( self::contact_fields(), array( self::message_field() ), array( self::consent_field() ) ) ),
			'property_enquiry'   => array( 'name' => 'Property Enquiry', 'lead_type' => 'buyer', 'fields' => array_merge( self::contact_fields(), array( self::message_field( 'Your Requirement' ) ), array( self::consent_field() ) ) ),
			'schedule_visit'     => array( 'name' => 'Schedule Site Visit', 'lead_type' => 'visit', 'fields' => array_merge( self::contact_fields(), $presets['visit'], array( self::consent_field() ) ) ),
			'buyer_requirement'  => array( 'name' => 'Buyer Requirement', 'lead_type' => 'buyer', 'fields' => array_merge( self::contact_fields(), $presets['buyer'], array( self::message_field( 'Additional Requirements' ) ), array( self::consent_field() ) ) ),
			'callback_request'   => array( 'name' => 'Callback Request', 'lead_type' => 'callback', 'fields' => array_merge( self::contact_fields(), array( array( 'field_type' => 'select', 'field_key' => 'callback_time', 'label' => 'Best Time to Call', 'options' => array( 'Morning (9-12)', 'Afternoon (12-4)', 'Evening (4-8)' ) ) ), array( self::consent_field() ) ) ),
			'project_enquiry'    => array( 'name' => 'Project Enquiry', 'lead_type' => 'buyer', 'fields' => array_merge( self::contact_fields(), array( array( 'field_type' => 'project', 'field_key' => 'project', 'label' => 'Project' ), self::message_field() ), array( self::consent_field() ) ) ),
			'sell_valuation'     => array( 'name' => 'Sell / Property Valuation', 'lead_type' => 'seller', 'fields' => array_merge( self::contact_fields(), $presets['seller'], array( self::consent_field() ) ) ),
			'home_loan'          => array( 'name' => 'Home Loan / Finance Assistance', 'lead_type' => 'loan', 'fields' => array_merge( self::contact_fields(), $presets['loan'], array( self::consent_field() ) ) ),
			'rental_requirement' => array( 'name' => 'Rental / Lease Requirement', 'lead_type' => 'rental', 'fields' => array_merge( self::contact_fields(), array(
				array( 'field_type' => 'property_type', 'field_key' => 'rent_type', 'label' => 'Property Type' ),
				array( 'field_type' => 'location', 'field_key' => 'rent_location', 'label' => 'Preferred Location' ),
				array( 'field_type' => 'budget_range', 'field_key' => 'rent_budget', 'label' => 'Monthly Budget (INR)' ),
			), array( self::consent_field() ) ) ),
			'investor'           => array( 'name' => 'Investor Consultation', 'lead_type' => 'investor', 'fields' => array_merge( self::contact_fields(), $presets['investor'], array( self::consent_field() ) ) ),
			'channel_partner'    => array( 'name' => 'Channel Partner Registration', 'lead_type' => 'partner', 'fields' => array_merge( self::contact_fields(), array(
				array( 'field_type' => 'text', 'field_key' => 'company', 'label' => 'Company / Firm Name' ),
				array( 'field_type' => 'text', 'field_key' => 'rera_id', 'label' => 'RERA Registration (if any)' ),
				array( 'field_type' => 'location', 'field_key' => 'operating_location', 'label' => 'Operating Location' ),
			), array( self::consent_field() ) ) ),
			'vendor'             => array( 'name' => 'Vendor / Partnership Enquiry', 'lead_type' => 'vendor', 'fields' => array_merge( self::contact_fields(), array(
				array( 'field_type' => 'text', 'field_key' => 'company', 'label' => 'Company Name' ),
				array( 'field_type' => 'select', 'field_key' => 'service_type', 'label' => 'Nature of Service', 'options' => array( 'Construction', 'Interior', 'Legal', 'Marketing', 'Finance', 'Other' ) ),
				self::message_field( 'Proposal Summary' ),
			), array( self::consent_field() ) ) ),
		);
	}

	/** Seed once on activation; never overwrites user-modified forms. */
	public static function seed_builtin_templates() {
		if ( get_option( 'mpfl_templates_seeded' ) ) {
			return;
		}
		foreach ( self::definitions() as $type => $def ) {
			$form_id = MPFL_Form_Builder::create_form( array(
				'name'        => $def['name'],
				'description' => 'Built-in Mayfair template. Duplicate or edit freely — nothing is locked.',
				'form_type'   => $type,
				'status'      => 'published',
				'settings'    => array( 'lead_type' => $def['lead_type'], 'notify_admin' => 1 ),
			) );
			if ( is_wp_error( $form_id ) ) {
				continue;
			}
			foreach ( $def['fields'] as $index => $field ) {
				$field['sort_order'] = $index;
				MPFL_Form_Builder::add_field( $form_id, $field );
			}
		}
		update_option( 'mpfl_templates_seeded', 1 );
	}
}
