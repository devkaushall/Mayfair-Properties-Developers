<?php
/**
 * Uninstall handler.
 *
 * DEFAULT BEHAVIOUR: submission data and forms are PRESERVED.
 * Tables and options are removed ONLY if the admin explicitly enabled
 * "Delete all plugin data on uninstall" in Settings (default OFF).
 *
 * @package Mayfair_Forms_Leads
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$mpfl_settings = get_option( 'mpfl_settings', array() );

if ( empty( $mpfl_settings['delete_on_uninstall'] ) ) {
	// Explicit opt-in absent: leave every table, option and lead untouched.
	return;
}

global $wpdb;

foreach ( array( 'forms', 'form_fields', 'submissions', 'submission_values', 'submission_events' ) as $mpfl_suffix ) {
	$mpfl_table = $wpdb->prefix . 'mayfair_' . $mpfl_suffix;
	$wpdb->query( "DROP TABLE IF EXISTS `{$mpfl_table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- uninstall cleanup, table name built from trusted prefix + fixed suffix
}

delete_option( 'mpfl_settings' );
delete_option( 'mpfl_webhook' );
delete_option( 'mpfl_export_presets' );
delete_option( 'mpfl_templates_seeded' );
delete_option( 'mpfl_db_version' );
