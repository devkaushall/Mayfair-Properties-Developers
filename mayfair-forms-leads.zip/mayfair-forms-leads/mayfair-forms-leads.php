<?php
/**
 * Plugin Name:       Mayfair Forms & Leads
 * Description:       Form builder, independent submission database, lead dashboard and multi-format export system for Mayfair Properties & Developers. Elementor renders; this plugin owns forms, submissions and leads.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Mayfair Properties & Developers
 * License:           GPL-2.0-or-later
 * Text Domain:       mayfair-forms-leads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MPFL_VERSION', '1.0.0' );
define( 'MPFL_DB_VERSION', '1.0.0' );
define( 'MPFL_FILE', __FILE__ );
define( 'MPFL_DIR', plugin_dir_path( __FILE__ ) );
define( 'MPFL_URL', plugin_dir_url( __FILE__ ) );

require_once MPFL_DIR . 'includes/class-security.php';
require_once MPFL_DIR . 'includes/class-database.php';
require_once MPFL_DIR . 'includes/class-templates.php';
require_once MPFL_DIR . 'includes/class-form-builder.php';
require_once MPFL_DIR . 'includes/class-form-renderer.php';
require_once MPFL_DIR . 'includes/class-submissions.php';
require_once MPFL_DIR . 'includes/class-leads.php';
require_once MPFL_DIR . 'includes/class-pdf.php';
require_once MPFL_DIR . 'includes/class-exports.php';
require_once MPFL_DIR . 'includes/class-email.php';
require_once MPFL_DIR . 'includes/class-webhooks.php';
require_once MPFL_DIR . 'includes/class-rest.php';
require_once MPFL_DIR . 'includes/class-elementor.php';
require_once MPFL_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'MPFL_Database', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MPFL_Database', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'MPFL_Plugin', 'instance' ) );
