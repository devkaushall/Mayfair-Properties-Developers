/**
 * Mayfair Forms & Leads — frontend behaviour.
 * Vanilla JS only. One concern: conditional field visibility.
 * Server-side validation is authoritative; this file adds zero validation logic
 * beyond native browser hints, and the form works without JS (conditions
 * are re-evaluated server-side on submit).
 */
( function () {
	'use strict';

	function fieldValue( form, key ) {
		var els = form.querySelectorAll( '[name="mpfl_f_' + key + '"], [name="mpfl_f_' + key + '[]"]' );
		if ( ! els.length ) {
			return '';
		}
		var el = els[ 0 ];
		if ( el.type === 'radio' ) {
			var checked = form.querySelector( '[name="mpfl_f_' + key + '"]:checked' );
			return checked ? checked.value : '';
		}
		if ( el.type === 'checkbox' ) {
			var vals = [];
			els.forEach( function ( c ) {
				if ( c.checked ) {
					vals.push( c.value );
				}
			} );
			return vals.join( ',' );
		}
		return el.value || '';
	}

	function ruleMet( form, rule ) {
		var actual = String( fieldValue( form, rule.field ) );
		var expected = String( rule.value || '' );
		if ( rule.operator === 'is_not' ) {
			return actual !== expected;
		}
		if ( rule.operator === 'contains' ) {
			return expected !== '' && actual.indexOf( expected ) !== -1;
		}
		return actual === expected;
	}

	function evaluate( form ) {
		form.querySelectorAll( '[data-mpfl-conditions]' ).forEach( function ( wrap ) {
			var conf;
			try {
				conf = JSON.parse( wrap.getAttribute( 'data-mpfl-conditions' ) );
			} catch ( e ) {
				return;
			}
			if ( ! conf || ! conf.rules || ! conf.rules.length ) {
				return;
			}
			var results = conf.rules.map( function ( rule ) {
				return ruleMet( form, rule );
			} );
			var visible = conf.relation === 'OR'
				? results.indexOf( true ) !== -1
				: results.indexOf( false ) === -1;
			wrap.setAttribute( 'data-mpfl-hidden', visible ? '0' : '1' );
			// Hidden fields must not block native required validation.
			wrap.querySelectorAll( 'input, select, textarea' ).forEach( function ( input ) {
				if ( visible ) {
					if ( input.getAttribute( 'data-mpfl-was-required' ) === '1' ) {
						input.required = true;
					}
				} else {
					if ( input.required ) {
						input.setAttribute( 'data-mpfl-was-required', '1' );
					}
					input.required = false;
				}
			} );
		} );
	}

	function initForm( form ) {
		evaluate( form );
		form.addEventListener( 'change', function () {
			evaluate( form );
		} );
		form.addEventListener( 'input', function () {
			evaluate( form );
		} );
	}

	function init() {
		document.querySelectorAll( 'form.mpfl-form' ).forEach( initForm );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
