# Mayfair Forms & Leads — Form Inventory (Locked)

Plugin: Mayfair Forms & Leads (Custom WordPress Plugin)
Target DB: wp_mayfair_leads

10 Approved Form Scenarios:
1. Property Enquiry (property_enquiry) -> Shortcode: [mayfair_form type="property_enquiry" property_id="[acf:mpd_property_id]" title="[post_title]"]
2. Project Enquiry (project_enquiry) -> Shortcode: [mayfair_form type="project_enquiry" project_id="[post_id]" title="[post_title]"]
3. Site Visit (site_visit) -> Captures preferred date and time slot
4. Buyer Requirement (buyer_requirement) -> Ingests budget bracket, target micro-markets
5. Request a Callback (callback) -> Quick telephone dispatch
6. Sell Property (sell_property) -> Captures property location, area, owner asking price
7. Valuation Request (valuation) -> Captures unit details for desktop valuation
8. Investment Consultation (investment_consultation) -> Senior partner portfolio desk
9. Rental Requirement (rental_requirement) -> Corporate leasing division
10. General Enquiry (general_enquiry) -> Inbound general routing