# Mayfair Responsive Breakpoint Specifications (Locked)

Breakpoints:
- Desktop Large: >= 1280px (1280px boxed container)
- Desktop Standard: 1025px - 1279px (1140px boxed container)
- Tablet: 768px - 1024px (2 columns loop grid, off-canvas menu)
- Mobile: <= 767px (1 column full width, sticky bottom action bar, min 44px touch targets)