# Mayfair Data Model & Field Audit (Locked)

Audit Summary:
- CPTs: property, project, insight (All verified)
- Taxonomies: property-type, property-status, location, project-type, insight-topic (All verified)
- Property ACF: 17 verified fields. All invented fields (amenities, parking, carpet area, developer, RERA, gallery repeaters) REMOVED.
- Project ACF: 9 verified fields (including mpd_developer_name, mpd_rera_number).
- Insight ACF: 9 verified fields.
- Forms: 10 form types exclusively via Mayfair Forms & Leads plugin.