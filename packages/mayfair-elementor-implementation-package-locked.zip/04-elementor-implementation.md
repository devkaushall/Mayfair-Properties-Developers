# Mayfair Properties & Developers — Complete Elementor Container & Widget Implementation Tree (Locked Architectural Edition)

Target Platform: WordPress 6.x + Hello Elementor + Elementor Pro 3.24+ (Flexbox Containers Engine)
Status: Authoritative & Locked
Design Archetype: Architectural Sharp & Mayfair Heritage
Global Container Standard: 1280px Boxed Width, 24px Desktop Horizontal Gutter (16px Mobile), 64px–80px Vertical Section Padding

Key Template Trees Defined:
- Single Property (Single Post: Property): 1280px Boxed, 2-Column (66% Content / 34% Sticky Sidebar)
- Single Project (Single Post: Project): Hero with Developer & RERA badges, 2-Column Main Body
- Loop Item: Property Card: 240px Media Frame, Absolute Badges, 20px Content Body with Specs Row
- Loop Item: Project Card: 240px Media Frame, Developer Tag, RERA Compliance Strip
- Front Page (Single Page: Front Page): Hero Search, Curated Loop Grid, Authority Strip, New Projects, Private CTA
- Properties Archive (Archive: Property): Filter Bar, Current Query Loop Grid, Pagination
- Global Header & Footer: Sticky 76px Header, 4-Column Structured Footer