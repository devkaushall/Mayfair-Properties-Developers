# Mayfair Properties & Developers — Reusable Component Inventory (Locked)

Target Platform: Elementor Pro Theme Builder & Loop Builder
Shape Standard: Architectural Sharp (0–4px radius)

15 Core UI Components:
- CMP-01: Global Navigation Header (.mfp-header)
- CMP-02: Global Footer (.mfp-footer)
- CMP-03: Property Loop Card (loop-property-card)
- CMP-04: Horizontal Property Card
- CMP-05: Project Loop Card (loop-project-card)
- CMP-06: Section Header Block
- CMP-07: Page Hero Banner
- CMP-08: Dynamic Taxonomy Search & Filter Bar
- CMP-09: Metric & Authority Strip
- CMP-10: Testimonial & Advisory Card
- CMP-11: 6-Item Architectural Specifications Matrix (Bedrooms, Bathrooms, Area, Floor, Furnishing, Possession)
- CMP-12: Floor Plan & Brochure Downloader Gate
- CMP-13: Mayfair Lead Capture Form Block
- CMP-14: Accordion / FAQ Block
- CMP-15: Map & Location Coordinates Block (via mpd_latitude / mpd_longitude)