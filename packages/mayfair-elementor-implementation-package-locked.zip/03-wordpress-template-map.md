# Mayfair Properties & Developers — Elementor Pro Theme Builder Template Architecture (Locked Edition)

Target Platform: Elementor Pro 3.24+ Theme Builder & Loop Builder
Theme Foundation: Hello Elementor
Status: Authoritative & Locked

Theme Builder Template Instances:
1. Header: "Mayfair Global Header" -> Include: Entire Site (Dynamic Menu, Site Logo, Concierge Phone)
2. Footer: "Mayfair Global Footer" -> Include: Entire Site (Taxonomy Links, Advisory Links, Callback Shortcode)
3. Single Page: "Front Page Template" -> Include: Front Page (Search bar, Featured Loop Grid, Project Loop Grid)
4. Single Post: "Single Property Template" -> Include: Properties > All (Hero, Featured Image, 6-item specs, Post Content, Floor Plan, Video, Map, Sticky Mayfair Inquiry Desk)
5. Single Post: "Single Project Template" -> Include: Projects > All (Developer pill, RERA badge, Possession date, Brochure gate)
6. Single Post: "Single Insight Template" -> Include: Insights > All (Subtitle, Reading time, Author avatar/byline, Citation footnotes, Contextual CTA)
7. Archive: "Property Archive Template" -> Include: Post Type: property & Taxonomies: location, property-type, property-status (Current Query Loop Grid, Live Filters, Pagination)
8. Archive: "Project Archive Template" -> Include: Post Type: project & Taxonomy: project-type (Current Query Loop Grid)
9. Archive: "Insight Archive Template" -> Include: Post Type: insight & Taxonomy: insight-topic (Current Query Loop Grid)
10. Single Page: "Sell Page Template" -> Include: Pages > Sell (Native Content + Mayfair Valuation Form)
11. Single Page: "Acquisitions Page Template" -> Include: Pages > Acquisitions (Native Content + Mayfair Buyer Form)
12. Loop Item: "Property Card Loop Item" -> Source: property (Featured Image, Status pill, Verified tag, Price badge, Title, Locality, Beds/Baths/Area)
13. Loop Item: "Project Card Loop Item" -> Source: project (Featured Image, Developer pill, Possession tag, Price bracket, RERA badge, Brochure CTA)
14. Loop Item: "Insight Card Loop Item" -> Source: insight (Featured Image, Subtitle, Reading time, Author byline)