# Mayfair Properties & Developers — Full Live Implementation QA Checklist (Locked Protocol)

Target Platform: WordPress 6.x + Hello Elementor + Elementor Pro 3.24+ + ACF Free + Mayfair Forms & Leads
Status: Authoritative Verification Protocol
Audit Standard: 100% Zero-Defect Compliance before Production Go-Live

Phases Covered:
- Phase 1: Design Tokens & Site Settings Verification (#1A1A1A, #A68B5B, #725B2F, #FFDEA7, #F9F7F2, #E5E1D8)
- Phase 2: Typography & Font Hierarchy (Playfair Display, Inter, strict line heights and weights)
- Phase 3: Shape Language & Motion (2-4px card/button radii, 0-2px image radii, scale 1.03)
- Phase 4: Dynamic ACF Free Field Bindings Audit (All 35 fields tested individually)
- Phase 5: Theme Builder & Loop Builder Verification
- Phase 6: Mayfair Forms & Leads Verification (All 10 scenarios routed to wp_mayfair_leads)
- Phase 7: Responsive Breakpoint & Cross-Device Audit
- Phase 8: Performance, SEO & Pre-Launch Hardening