# Mayfair Properties & Developers — Design System Specification (Locked Architectural Edition)

Target Platform: WordPress 6.x + Hello Elementor + Elementor Pro Site Settings
Status: Authoritative & Locked
Design Archetype: Architectural Sharp & Mayfair Heritage

1. LOCKED GLOBAL COLOR PALETTE
- Primary Charcoal: #1A1A1A (Mayfair Primary Charcoal)
- Secondary Bronze: #725B2F (Mayfair Secondary Bronze)
- Accent Bronze: #A68B5B (Mayfair Accent Bronze)
- Bronze Light: #FFDEA7 (Mayfair Bronze Light)
- Canvas Background: #F9F7F2 (Mayfair Canvas Background)
- Surface Pure White: #FFFFFF (Mayfair Surface White)
- Cream Surface: #F5F0E7 (Mayfair Cream)
- Surface Soft: #F7F3EA (Mayfair Surface Soft)
- Surface Mid: #F2EDE4 (Mayfair Surface Mid)
- Surface High: #ECE8DF (Mayfair Surface High)
- Surface Highest: #E6E2D9 (Mayfair Surface Highest)
- Border Subtle: #E5E1D8 (Mayfair Border Subtle)
- Border Strong: #C4C7C7 (Mayfair Border Strong)
- Muted Text: #444748 (Mayfair Text Muted)

2. LOCKED TYPOGRAPHY HIERARCHY
- Headings: Playfair Display (500, 600, 700)
- Body / UI: Inter (400, 500, 600, 700)
- Hero Display H1: 48–52px (Desktop), 40px (Tablet), 32px (Mobile), Line Height: 1.15
- Page Title H1: 36–40px (Desktop), 32px (Tablet), 26px (Mobile), Line Height: 1.2
- Section Heading H2: 30–32px (Desktop), 26px (Tablet), 22px (Mobile), Line Height: 1.25
- Sub-section H3: 20–22px (Desktop), 18px (Tablet), 16px (Mobile), Line Height: 1.3
- Card Title H4: 16–17px (Desktop), 15px (Mobile), Line Height: 1.4
- Eyebrow / Overline: 10–11px Inter Bold, Uppercase, Tracking: 0.14em
- Body Regular: 15px (Desktop), 14px (Mobile), Line Height: 1.6
- Price & Key Metric: 20–28px Inter Bold

3. ARCHITECTURAL SHARP SHAPE & MOTION
- Cards: 2–4px radius
- Images: 0–2px radius
- Buttons: 0–4px radius
- Hover image scale: max 1.03
- Hover elevation: max translateY(-2px) with border transition to #A68B5B
- Transitions: 200–250ms ease