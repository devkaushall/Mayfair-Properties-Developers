# Mayfair Developer Build Order (Locked)

Phase 1: Environment & Foundational Setup (Hello Elementor, ACF Free, Mayfair Core, Mayfair Forms & Leads)
Phase 2: Design System & Elementor Site Settings (#1A1A1A, #A68B5B, #725B2F, Playfair, Inter)
Phase 3: ACF Custom Fields Setup (17 Property, 9 Project, 9 Insight)
Phase 4: Theme Builder Header, Footer & Loop Card Templates
Phase 5: Single & Archive Templates
Phase 6: Core Pages & Conversion Forms
Phase 7: Quality Assurance & Launch