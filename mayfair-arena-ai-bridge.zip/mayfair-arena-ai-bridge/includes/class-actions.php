<?php
/**
 * AI action runner: connects editor actions (property/project/insight)
 * to prompts + context + the Arena client. Always returns a labelled
 * draft for human Accept/Reject — never writes content automatically.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Actions {

	/** action_key => [ label, post_type, task_type ] */
	public static function registry() {
		return array(
			// Property
			'property_description' => array( 'Generate Property Description', 'property', 'property' ),
			'property_rewrite'     => array( 'Rewrite Description', 'property', 'property' ),
			'property_short'       => array( 'Generate Short Description', 'property', 'property' ),
			'property_seo_title'   => array( 'Generate SEO Title', 'property', 'seo' ),
			'property_meta_desc'   => array( 'Generate Meta Description', 'property', 'seo' ),
			'property_highlights'  => array( 'Generate Property Highlights', 'property', 'property' ),
			'property_cta'         => array( 'Generate CTA Copy', 'property', 'content' ),
			'property_social'      => array( 'Generate Social Caption', 'property', 'content' ),
			// Project
			'project_description'  => array( 'Generate Project Description', 'project', 'project' ),
			'project_highlights'   => array( 'Generate Highlights', 'project', 'project' ),
			'project_seo_title'    => array( 'Generate SEO Title', 'project', 'seo' ),
			'project_meta_desc'    => array( 'Generate Meta Description', 'project', 'seo' ),
			'project_cta'          => array( 'Generate CTA', 'project', 'content' ),
			'project_social'       => array( 'Generate Social Caption', 'project', 'content' ),
			// Insight
			'insight_outline'      => array( 'Generate Outline', 'insight', 'insight' ),
			'insight_draft'        => array( 'Generate Draft', 'insight', 'insight' ),
			'insight_rewrite'      => array( 'Rewrite', 'insight', 'insight' ),
			'insight_summarize'    => array( 'Summarize', 'insight', 'insight' ),
			'insight_excerpt'      => array( 'Generate Excerpt', 'insight', 'insight' ),
			'insight_seo_title'    => array( 'Generate SEO Title', 'insight', 'seo' ),
			'insight_meta_desc'    => array( 'Generate Meta Description', 'insight', 'seo' ),
			'insight_faq'          => array( 'Generate FAQ Draft', 'insight', 'insight' ),
			'insight_social'       => array( 'Generate Social Caption', 'insight', 'content' ),
		);
	}

	public static function actions_for( $post_type ) {
		$out = array();
		foreach ( self::registry() as $key => $def ) {
			if ( $def[1] === $post_type ) {
				$out[ $key ] = $def[0];
			}
		}
		return $out;
	}

	/**
	 * Execute an AI action for a post. Capability + nonce checked by caller.
	 *
	 * @return array|WP_Error { draft, label, task_id, meta }
	 */
	public static function run( $action_key, $post_id ) {
		$registry = self::registry();
		if ( ! isset( $registry[ $action_key ] ) ) {
			return new WP_Error( 'mpa_action', __( 'Unknown AI action.', 'mayfair-arena-ai-bridge' ) );
		}
		list( , $post_type, $task_type ) = array_values( array( $registry[ $action_key ][0], $registry[ $action_key ][1], $registry[ $action_key ][2] ) );

		$post = get_post( $post_id );
		if ( ! $post || $post->post_type !== $post_type ) {
			return new WP_Error( 'mpa_post', __( 'This action does not apply to this post.', 'mayfair-arena-ai-bridge' ) );
		}

		$rate = MPA_RateLimit::check( $action_key );
		if ( is_wp_error( $rate ) ) {
			return $rate;
		}

		$prompt = MPA_Prompts::get_by_action( $action_key );
		if ( ! $prompt ) {
			return new WP_Error( 'mpa_prompt', __( 'No active prompt is configured for this action. Check Mayfair AI → Prompts.', 'mayfair-arena-ai-bridge' ) );
		}

		// Build context + substitute variables (allowlist only).
		$vars     = MPA_Context::for_post( $post_id );
		$user_sub = MPA_Prompts::substitute( $prompt['user_template'], $vars );
		$sys_sub  = MPA_Prompts::substitute( $prompt['system_prompt'], $vars );

		// System prompt = prompt system text + anti-invention guard from real data.
		$system = trim( $sys_sub['text'] ) . "\n\n" . MPA_Context::guard_instruction( $vars );

		$task_id = MPA_Tasks::create( $task_type, $action_key, $prompt['model'], $system . "\n" . $user_sub['text'], $post_id );

		$result = MPA_Arena_Client::chat_completion( array(
			'model'       => $prompt['model'],
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user', 'content' => $user_sub['text'] ),
			),
			'temperature' => $prompt['temperature'],
			'max_tokens'  => $prompt['max_tokens'],
		) );

		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			$meta = is_array( $data ) && isset( $data['meta'] ) ? $data['meta'] : array();
			MPA_Tasks::fail( $task_id, $result->get_error_message(), $meta );
			MPA_Database::log( 'error', 'action', $action_key . ': ' . $result->get_error_message(), $meta, isset( $meta['trace_id'] ) ? $meta['trace_id'] : '' );
			return $result;
		}

		$draft = MPA_Sanitizer::clean( $result['text'], $prompt['output_format'] );
		MPA_Tasks::complete( $task_id, $result['meta'], $draft );
		MPA_Database::log( 'info', 'action', $action_key . ' completed', $result['meta'], isset( $result['meta']['trace_id'] ) ? $result['meta']['trace_id'] : '' );

		return array(
			'draft'   => $draft,
			'label'   => MPA_Sanitizer::label(),
			'task_id' => $task_id,
			'meta'    => $result['meta'],
			'format'  => $prompt['output_format'],
		);
	}

	/**
	 * Accept a draft into the post — the ONLY write path, explicitly
	 * user-triggered, applies to one target field, never auto-publishes.
	 *
	 * @param string $target content|excerpt|draft_post (insight new draft).
	 * @return true|WP_Error
	 */
	public static function accept( $post_id, $target, $draft_text ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'mpa_post', __( 'Post not found.', 'mayfair-arena-ai-bridge' ) );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'mpa_cap', __( 'You cannot edit this post.', 'mayfair-arena-ai-bridge' ) );
		}
		$clean = MPA_Sanitizer::clean( (string) $draft_text, 'html' );

		switch ( $target ) {
			case 'content':
				wp_update_post( array( 'ID' => $post_id, 'post_content' => $clean ) );
				return true;
			case 'excerpt':
				wp_update_post( array( 'ID' => $post_id, 'post_excerpt' => sanitize_textarea_field( (string) $draft_text ) ) );
				return true;
			case 'draft_post':
				// AI drafts for insights become a NEW draft post — never auto-published.
				$new_id = wp_insert_post( array(
					'post_type'    => $post->post_type,
					'post_status'  => 'draft',
					'post_title'   => get_the_title( $post ) . ' — AI Draft',
					'post_content' => $clean,
				) );
				return $new_id ? true : new WP_Error( 'mpa_draft', __( 'Could not create draft.', 'mayfair-arena-ai-bridge' ) );
			default:
				return new WP_Error( 'mpa_target', __( 'Unknown accept target.', 'mayfair-arena-ai-bridge' ) );
		}
	}
}
