<?php
/**
 * Orchestrator: admin menu, pages, action dispatcher.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Plugin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		MPA_Ajax::init();
		MPA_REST::init();
		MPA_Metabox::init();

		if ( did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ) ) {
			MPA_Elementor::init();
		} else {
			add_action( 'elementor/loaded', array( 'MPA_Elementor', 'init' ) );
		}

		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'menu' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
			add_action( 'admin_post_mpa_admin_action', array( $this, 'dispatch' ) );
		}

		if ( get_option( 'mpa_db_version' ) !== MPA_DB_VERSION ) {
			MPA_Database::create_tables();
			update_option( 'mpa_db_version', MPA_DB_VERSION );
		}
	}

	public function menu() {
		add_menu_page( __( 'Mayfair AI', 'mayfair-arena-ai-bridge' ), __( 'Mayfair AI', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-dashboard', array( $this, 'page_dashboard' ), 'dashicons-superhero', 28 );
		add_submenu_page( 'mpa-dashboard', __( 'Dashboard', 'mayfair-arena-ai-bridge' ), __( 'Dashboard', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-dashboard', array( $this, 'page_dashboard' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Connection', 'mayfair-arena-ai-bridge' ), __( 'Connection', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-connection', array( $this, 'page_connection' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Models', 'mayfair-arena-ai-bridge' ), __( 'Models', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-models', array( $this, 'page_models' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Prompts', 'mayfair-arena-ai-bridge' ), __( 'Prompts', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-prompts', array( $this, 'page_prompts' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Tasks', 'mayfair-arena-ai-bridge' ), __( 'Tasks', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-tasks', array( $this, 'page_tasks' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Logs', 'mayfair-arena-ai-bridge' ), __( 'Logs', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-logs', array( $this, 'page_logs' ) );
		add_submenu_page( 'mpa-dashboard', __( 'Settings', 'mayfair-arena-ai-bridge' ), __( 'Settings', 'mayfair-arena-ai-bridge' ), MPA_Settings::CAP, 'mpa-settings', array( $this, 'page_settings' ) );
	}

	public function assets( $hook ) {
		if ( false === strpos( $hook, 'mpa-' ) ) {
			return;
		}
		wp_enqueue_style( 'mpa-admin', MPA_URL . 'admin/assets/mpa-admin.css', array(), MPA_VERSION );
	}

	private function cap() {
		if ( ! current_user_can( MPA_Settings::CAP ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mayfair-arena-ai-bridge' ) );
		}
	}

	public function page_dashboard() {
		$this->cap();
		require MPA_DIR . 'admin/views/dashboard.php';
	}
	public function page_connection() {
		$this->cap();
		require MPA_DIR . 'admin/views/connection.php';
	}
	public function page_models() {
		$this->cap();
		require MPA_DIR . 'admin/views/models.php';
	}
	public function page_prompts() {
		$this->cap();
		require MPA_DIR . 'admin/views/prompts.php';
	}
	public function page_tasks() {
		$this->cap();
		require MPA_DIR . 'admin/views/tasks.php';
	}
	public function page_logs() {
		$this->cap();
		require MPA_DIR . 'admin/views/logs.php';
	}
	public function page_settings() {
		$this->cap();
		require MPA_DIR . 'admin/views/settings.php';
	}

	/* ------------------------------------------------------------------ */

	public function dispatch() {
		$this->cap();
		$task = isset( $_POST['mpa_task'] ) ? sanitize_key( wp_unslash( $_POST['mpa_task'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified next line
		check_admin_referer( 'mpa_admin_' . $task, '_mpanonce' );
		$redirect = wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=mpa-dashboard' );

		switch ( $task ) {

			case 'save_connection':
				$settings = MPA_Settings::get();
				if ( isset( $_POST['api_base'] ) ) {
					$base = esc_url_raw( wp_unslash( $_POST['api_base'] ) );
					if ( '' !== $base && 0 === strpos( $base, 'https://' ) ) {
						$settings['api_base'] = untrailingslashit( $base );
					}
				}
				if ( isset( $_POST['timeout'] ) ) {
					$settings['timeout'] = max( 5, min( 300, (int) $_POST['timeout'] ) );
				}
				$settings['debug_logging'] = ! empty( $_POST['debug_logging'] ) ? 1 : 0;
				MPA_Settings::update( $settings );
				// Key handled separately so a blank field never wipes it accidentally.
				if ( ! empty( $_POST['api_key'] ) ) {
					MPA_Settings::set_api_key( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) );
				}
				if ( ! empty( $_POST['clear_key'] ) ) {
					MPA_Settings::set_api_key( '' );
				}
				$this->finish( $redirect, __( 'Connection settings saved.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'test_connection':
				$health = MPA_Arena_Client::health_check();
				if ( is_wp_error( $health ) ) {
					MPA_Database::log( 'error', 'connection', 'Health check failed: ' . $health->get_error_message() );
					$this->finish( $redirect, __( 'Connection test FAILED: ', 'mayfair-arena-ai-bridge' ) . $health->get_error_message() );
				}
				MPA_Database::log( 'info', 'connection', 'Health check OK' );
				$this->finish( $redirect, __( 'Connection test OK — Arena API reachable.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'refresh_models':
				$result = MPA_Arena_Client::list_models();
				if ( is_wp_error( $result ) ) {
					$this->finish( $redirect, __( 'Model refresh failed: ', 'mayfair-arena-ai-bridge' ) . $result->get_error_message() );
				}
				$settings                     = MPA_Settings::get();
				$settings['models_cache']     = $result['models'];
				$settings['models_cached_at'] = time();
				MPA_Settings::update( $settings );
				$this->finish( $redirect, sprintf( /* translators: %d count */ __( '%d models loaded from Arena.', 'mayfair-arena-ai-bridge' ), count( $result['models'] ) ) );
				break;

			case 'save_models':
				$default   = isset( $_POST['default_model'] ) ? sanitize_text_field( wp_unslash( $_POST['default_model'] ) ) : '';
				$fallbacks = array();
				foreach ( array( 'fallback_1', 'fallback_2', 'fallback_3' ) as $field ) {
					if ( ! empty( $_POST[ $field ] ) ) {
						$fallbacks[] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
					}
				}
				MPA_Settings::set_models( $default, $fallbacks );
				// Disabled models list.
				$settings = MPA_Settings::get();
				$settings['disabled_models'] = isset( $_POST['disabled_models'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['disabled_models'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- mapped
				MPA_Settings::update( $settings );
				$this->finish( $redirect, __( 'Model configuration saved.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'save_prompt':
				$prompt_id = isset( $_POST['prompt_id'] ) ? (int) $_POST['prompt_id'] : 0;
				$data      = array();
				foreach ( array( 'name', 'description', 'system_prompt', 'user_template', 'model', 'temperature', 'max_tokens', 'output_format', 'action_key', 'status' ) as $field ) {
					if ( isset( $_POST[ $field ] ) ) {
						$data[ $field ] = wp_unslash( $_POST[ $field ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized inside create()/update()
					}
				}
				if ( $prompt_id ) {
					MPA_Prompts::update( $prompt_id, $data );
				} else {
					MPA_Prompts::create( $data );
				}
				$this->finish( $redirect, __( 'Prompt saved.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'duplicate_prompt':
				MPA_Prompts::duplicate( isset( $_POST['prompt_id'] ) ? (int) $_POST['prompt_id'] : 0 );
				$this->finish( $redirect, __( 'Prompt duplicated (inactive copy).', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'delete_prompt':
				MPA_Prompts::delete( isset( $_POST['prompt_id'] ) ? (int) $_POST['prompt_id'] : 0 );
				$this->finish( $redirect, __( 'Prompt deleted.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'toggle_prompt':
				MPA_Prompts::set_status(
					isset( $_POST['prompt_id'] ) ? (int) $_POST['prompt_id'] : 0,
					isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'inactive'
				);
				$this->finish( $redirect, __( 'Prompt status updated.', 'mayfair-arena-ai-bridge' ) );
				break;

			case 'save_settings':
				$settings = MPA_Settings::get();
				$settings['store_payloads'] = ! empty( $_POST['store_payloads'] ) ? 1 : 0;
				$settings['public_widget']  = ! empty( $_POST['public_widget'] ) ? 1 : 0;
				foreach ( array( 'rate_user_max' => array( 1, 500 ), 'rate_window' => array( 60, 86400 ), 'rate_ip_max' => array( 1, 100 ) ) as $field => $range ) {
					if ( isset( $_POST[ $field ] ) ) {
						$settings[ $field ] = max( $range[0], min( $range[1], (int) $_POST[ $field ] ) );
					}
				}
				MPA_Settings::update( $settings );
				update_option( 'mpa_delete_on_uninstall', ! empty( $_POST['delete_on_uninstall'] ) ? 1 : 0 );
				$this->finish( $redirect, __( 'Settings saved.', 'mayfair-arena-ai-bridge' ) );
				break;

			default:
				wp_die( esc_html__( 'Unknown action.', 'mayfair-arena-ai-bridge' ) );
		}
	}

	private function finish( $redirect, $message ) {
		wp_safe_redirect( add_query_arg( 'mpa_notice', rawurlencode( $message ), $redirect ) );
		exit;
	}
}
