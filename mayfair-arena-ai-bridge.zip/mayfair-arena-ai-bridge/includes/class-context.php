<?php
/**
 * Secure context builder: reads allowlisted WordPress data for a post
 * and exposes it as prompt variables. Read-only. Never sends private
 * or unrelated site data.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Context {

	/** Allowlisted prompt variables (the ONLY substitutions permitted). */
	public static function allowed_variables() {
		return array(
			'property_title', 'property_id', 'location', 'price', 'price_label', 'area',
			'bedrooms', 'bathrooms', 'floor', 'furnishing', 'possession', 'locality',
			'property_type', 'property_status', 'content', 'excerpt',
			'project_title', 'developer', 'min_price', 'max_price', 'rera', 'possession_date', 'project_type',
			'insight_title', 'insight_subtitle', 'author', 'reading_time', 'insight_topic',
			'site_name',
		);
	}

	/** Allowlisted ACF meta keys per post type (read-only). */
	public static function allowed_meta() {
		return array(
			'property' => array(
				'mpd_property_id', 'mpd_price', 'mpd_price_label', 'mpd_area_sqft',
				'mpd_bedrooms', 'mpd_bathrooms', 'mpd_floor_level', 'mpd_furnishing',
				'mpd_possession_status', 'mpd_locality', 'mpd_video_url', 'mpd_featured', 'mpd_verified',
			),
			'project'  => array(
				'mpd_developer_name', 'mpd_possession_date', 'mpd_min_price', 'mpd_max_price',
				'mpd_rera_number', 'mpd_featured',
			),
			'insight'  => array(
				'mpi_subtitle', 'mpi_reading_time', 'mpi_author_name', 'mpi_featured',
				'mpi_source_name', 'mpi_cta_text',
			),
		);
	}

	/**
	 * Build the variable map for a post. Only allowlisted data; empty
	 * values stay empty (the AI is instructed never to invent them).
	 *
	 * @return array variable => value (all plain text).
	 */
	public static function for_post( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || ! in_array( $post->post_type, array( 'property', 'project', 'insight' ), true ) ) {
			return array();
		}

		$vars = array( 'site_name' => get_bloginfo( 'name' ) );
		$vars['content'] = wp_strip_all_tags( (string) $post->post_content );
		$vars['excerpt'] = wp_strip_all_tags( (string) $post->post_excerpt );

		$meta_map = self::allowed_meta();
		$meta     = array();
		foreach ( $meta_map[ $post->post_type ] as $key ) {
			$meta[ $key ] = sanitize_text_field( (string) get_post_meta( $post_id, $key, true ) );
		}

		if ( 'property' === $post->post_type ) {
			$vars['property_title']  = get_the_title( $post );
			$vars['property_id']     = $meta['mpd_property_id'];
			$vars['price']           = $meta['mpd_price'];
			$vars['price_label']     = $meta['mpd_price_label'];
			$vars['area']            = $meta['mpd_area_sqft'];
			$vars['bedrooms']        = $meta['mpd_bedrooms'];
			$vars['bathrooms']       = $meta['mpd_bathrooms'];
			$vars['floor']           = $meta['mpd_floor_level'];
			$vars['furnishing']      = $meta['mpd_furnishing'];
			$vars['possession']      = $meta['mpd_possession_status'];
			$vars['locality']        = $meta['mpd_locality'];
			$vars['property_type']   = self::terms( $post_id, 'property-type' );
			$vars['property_status'] = self::terms( $post_id, 'property-status' );
			$vars['location']        = self::terms( $post_id, 'location' );
		} elseif ( 'project' === $post->post_type ) {
			$vars['project_title']   = get_the_title( $post );
			$vars['developer']       = $meta['mpd_developer_name'];
			$vars['min_price']       = $meta['mpd_min_price'];
			$vars['max_price']       = $meta['mpd_max_price'];
			$vars['rera']            = $meta['mpd_rera_number'];
			$vars['possession_date'] = $meta['mpd_possession_date'];
			$vars['project_type']    = self::terms( $post_id, 'project-type' );
			$vars['location']        = self::terms( $post_id, 'location' );
		} else {
			$vars['insight_title']    = get_the_title( $post );
			$vars['insight_subtitle'] = $meta['mpi_subtitle'];
			$vars['author']           = $meta['mpi_author_name'] ? $meta['mpi_author_name'] : get_the_author_meta( 'display_name', (int) $post->post_author );
			$vars['reading_time']     = $meta['mpi_reading_time'];
			$vars['insight_topic']    = self::terms( $post_id, 'insight-topic' );
		}

		// Featured image metadata (alt/caption only — no binary).
		$thumb_id = get_post_thumbnail_id( $post_id );
		if ( $thumb_id ) {
			$vars['featured_image_alt'] = sanitize_text_field( (string) get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) );
		}

		return $vars;
	}

	/**
	 * Anti-invention guard appended to every system prompt built from context.
	 * The AI is explicitly told which facts exist and instructed never to
	 * fabricate the missing ones.
	 */
	public static function guard_instruction( $vars ) {
		$facts   = array();
		$missing = array();
		$factual = array( 'price', 'price_label', 'area', 'bedrooms', 'bathrooms', 'floor', 'furnishing', 'possession', 'locality', 'location', 'property_type', 'property_status', 'developer', 'min_price', 'max_price', 'rera', 'possession_date' );
		foreach ( $factual as $key ) {
			if ( isset( $vars[ $key ] ) && '' !== $vars[ $key ] ) {
				$facts[] = $key . ': ' . $vars[ $key ];
			} elseif ( array_key_exists( $key, $vars ) ) {
				$missing[] = $key;
			}
		}
		$guard  = "FACTUAL DATA (the ONLY facts you may state):\n" . ( $facts ? implode( "\n", $facts ) : '(none provided)' ) . "\n\n";
		$guard .= 'STRICT RULES: Never invent or estimate prices, areas, bedroom/bathroom counts, RERA numbers, possession dates, locations, amenities, developer names, or legal details. ';
		if ( $missing ) {
			$guard .= 'The following facts are NOT available and must not appear as specific values: ' . implode( ', ', $missing ) . '. ';
		}
		$guard .= 'If a fact is missing, write around it without stating a value. Label nothing as verified unless it appears in the factual data above.';
		return $guard;
	}

	private static function terms( $post_id, $taxonomy ) {
		$terms = get_the_terms( $post_id, $taxonomy );
		if ( ! is_array( $terms ) || empty( $terms ) ) {
			return '';
		}
		return implode( ', ', wp_list_pluck( $terms, 'name' ) );
	}
}
