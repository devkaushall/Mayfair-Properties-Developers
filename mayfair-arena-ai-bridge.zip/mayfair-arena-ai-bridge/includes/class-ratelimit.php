<?php
/**
 * Local WordPress-side rate limiting: per user, per action, optional
 * per-IP (public widget mode only). Arena-side 429s are respected
 * upstream (no aggressive retry; Retry-After surfaced).
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_RateLimit {

	/**
	 * Check + consume one request slot.
	 *
	 * @param string $action  action key for per-action granularity.
	 * @param bool   $public  true for anonymous widget requests (per-IP).
	 * @return true|WP_Error
	 */
	public static function check( $action, $public = false ) {
		$settings = MPA_Settings::get();

		if ( $public ) {
			$ip_key = 'mpa_rl_ip_' . substr( hash_hmac( 'sha256', isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '', wp_salt( 'auth' ) ), 0, 24 );
			$count  = (int) get_transient( $ip_key );
			if ( $count >= (int) $settings['rate_ip_max'] ) {
				return new WP_Error( 'mpa_rate_ip', __( 'Too many requests. Please try again later.', 'mayfair-arena-ai-bridge' ) );
			}
			set_transient( $ip_key, $count + 1, (int) $settings['rate_window'] );
			return true;
		}

		$user_id = get_current_user_id();
		$key     = 'mpa_rl_u' . $user_id . '_' . sanitize_key( $action );
		$count   = (int) get_transient( $key );
		if ( $count >= (int) $settings['rate_user_max'] ) {
			return new WP_Error( 'mpa_rate_user', sprintf(
				/* translators: %d minutes */
				__( 'You have reached the AI request limit for this action. Try again in about %d minutes.', 'mayfair-arena-ai-bridge' ),
				max( 1, (int) round( $settings['rate_window'] / 60 ) )
			) );
		}
		set_transient( $key, $count + 1, (int) $settings['rate_window'] );
		return true;
	}
}
