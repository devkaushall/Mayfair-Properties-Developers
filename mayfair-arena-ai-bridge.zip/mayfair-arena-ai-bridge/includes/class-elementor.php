<?php
/**
 * Elementor integration: 'Mayfair AI' widget under the Mayfair category.
 * Inherits Elementor styling; alters no site settings/colors/fonts.
 * Public anonymous requests disabled unless explicitly enabled.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Elementor {

	public static function init() {
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'widget' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function category( $elements_manager ) {
		$elements_manager->add_category( 'mayfair', array(
			'title' => __( 'Mayfair', 'mayfair-arena-ai-bridge' ),
			'icon'  => 'fa fa-building',
		) );
	}

	public static function widget( $widgets_manager ) {
		require_once MPA_DIR . 'includes/class-elementor-widget.php';
		$widgets_manager->register( new MPA_Elementor_Widget() );
	}

	public static function assets() {
		wp_register_script( 'mpa-widget', MPA_URL . 'public/assets/mpa-widget.js', array(), MPA_VERSION, true );
		wp_localize_script( 'mpa-widget', 'mpaWidget', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'mpa_widget' ),
		) );
	}
}
