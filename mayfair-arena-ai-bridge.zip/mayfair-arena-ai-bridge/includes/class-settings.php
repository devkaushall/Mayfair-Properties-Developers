<?php
/**
 * Settings: connection config, key storage, capability model.
 *
 * API key storage: encrypted at rest with AES-256-CBC when OpenSSL is
 * available, keyed from wp_salt('auth') — better than plaintext options,
 * honestly documented as NOT hardware-grade secrecy (anything the PHP
 * process can decrypt, a compromised PHP process can too). Never exposed
 * to the frontend, REST responses, JS, or logs.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Settings {

	const OPTION = 'mpa_settings';
	const CAP    = 'manage_mayfair_ai';

	public static function defaults() {
		return array(
			'api_base'        => 'https://api.preview.arena.ai',
			'api_key_enc'     => '',
			'default_model'   => '',
			'fallback_models' => array(), // max 3
			'timeout'         => 60,
			'debug_logging'   => 0,
			'store_payloads'  => 0,       // full prompts/responses NOT stored by default
			'public_widget'   => 0,       // anonymous widget requests disabled by default
			'rate_user_max'   => 20,      // requests per window per user
			'rate_window'     => 3600,
			'rate_ip_max'     => 10,      // for public mode only
			'models_cache'    => array(),
			'models_cached_at' => 0,
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	public static function update( $settings ) {
		update_option( self::OPTION, $settings, false ); // autoload off — contains model cache
	}

	/* ---------------- API key handling ---------------- */

	public static function set_api_key( $plain ) {
		$settings = self::get();
		$plain    = trim( (string) $plain );
		$settings['api_key_enc'] = ( '' === $plain ) ? '' : self::encrypt( $plain );
		self::update( $settings );
	}

	public static function get_api_key() {
		$settings = self::get();
		if ( '' === $settings['api_key_enc'] ) {
			return '';
		}
		return self::decrypt( $settings['api_key_enc'] );
	}

	public static function has_api_key() {
		$settings = self::get();
		return '' !== $settings['api_key_enc'];
	}

	/** Masked display form: first 6 + last 4 only. Never the full key. */
	public static function masked_key() {
		$key = self::get_api_key();
		if ( '' === $key ) {
			return '';
		}
		if ( strlen( $key ) <= 12 ) {
			return str_repeat( '*', strlen( $key ) );
		}
		return substr( $key, 0, 6 ) . str_repeat( '*', 8 ) . substr( $key, -4 );
	}

	private static function encrypt( $plain ) {
		if ( function_exists( 'openssl_encrypt' ) ) {
			$key    = hash( 'sha256', wp_salt( 'auth' ), true );
			$iv     = random_bytes( 16 );
			$cipher = openssl_encrypt( $plain, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
			if ( false !== $cipher ) {
				return 'enc1:' . base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- binary-safe storage, not obfuscation
			}
		}
		// Fallback: reversible encoding with marker (documented limitation on hosts without OpenSSL).
		return 'b64:' . base64_encode( $plain ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	private static function decrypt( $stored ) {
		if ( 0 === strpos( $stored, 'enc1:' ) && function_exists( 'openssl_decrypt' ) ) {
			$raw = base64_decode( substr( $stored, 5 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( false !== $raw && strlen( $raw ) > 16 ) {
				$key   = hash( 'sha256', wp_salt( 'auth' ), true );
				$iv    = substr( $raw, 0, 16 );
				$plain = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv );
				return ( false === $plain ) ? '' : $plain;
			}
			return '';
		}
		if ( 0 === strpos( $stored, 'b64:' ) ) {
			$plain = base64_decode( substr( $stored, 4 ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			return ( false === $plain ) ? '' : $plain;
		}
		return '';
	}

	/* ---------------- Model config ---------------- */

	/** Sanitize + persist fallback list (max 3, no duplicates of primary). */
	public static function set_models( $default_model, $fallbacks ) {
		$settings = self::get();
		$settings['default_model'] = sanitize_text_field( $default_model );
		$clean = array();
		foreach ( (array) $fallbacks as $model ) {
			$model = sanitize_text_field( $model );
			if ( '' !== $model && $model !== $settings['default_model'] && ! in_array( $model, $clean, true ) ) {
				$clean[] = $model;
			}
			if ( count( $clean ) >= 3 ) {
				break; // max 3 fallbacks — dedupe/validate first, then cap
			}
		}
		$settings['fallback_models'] = $clean;
		self::update( $settings );
	}

	public static function capabilities() {
		return array( self::CAP );
	}
}
