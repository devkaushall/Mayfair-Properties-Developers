<?php
/**
 * MPA_Arena_Client — the reusable Arena API service.
 *
 * Connects ONLY to Arena's documented HTTP API gateway via
 * wp_remote_get()/wp_remote_post(). No browser automation, no cookies,
 * no arena.ai web UI interaction, no Agent Mode session control.
 *
 * Routes: GET /v1/models · POST /v1/chat/completions · POST /v1/messages
 *         POST /v1/images/generations · POST /v1/images/edits
 *         GET /health/liveliness
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Arena_Client {

	/** Arena metadata headers captured from responses. */
	const TRACE_HEADERS = array(
		'x-arena-trace-id'        => 'trace_id',
		'x-arena-resolved-model'  => 'resolved_model',
		'x-arena-fallback-index'  => 'fallback_index',
		'x-arena-fallback-reason' => 'fallback_reason',
	);

	/* ------------------------------------------------------------------ */
	/* Public API methods                                                 */
	/* ------------------------------------------------------------------ */

	/**
	 * GET /v1/models
	 *
	 * @return array|WP_Error normalized model list.
	 */
	public static function list_models() {
		$response = self::request( 'GET', '/v1/models' );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$body   = $response['json'];
		$models = array();
		$list   = isset( $body['data'] ) && is_array( $body['data'] ) ? $body['data'] : ( is_array( $body ) ? $body : array() );
		foreach ( $list as $model ) {
			if ( ! is_array( $model ) || empty( $model['id'] ) ) {
				continue;
			}
			$models[] = array(
				'id'       => sanitize_text_field( $model['id'] ),
				'provider' => isset( $model['owned_by'] ) ? sanitize_text_field( $model['owned_by'] ) : ( isset( $model['provider'] ) ? sanitize_text_field( $model['provider'] ) : '' ),
				'input'    => isset( $model['input_modalities'] ) ? implode( ',', array_map( 'sanitize_text_field', (array) $model['input_modalities'] ) ) : 'text',
				'output'   => isset( $model['output_modalities'] ) ? implode( ',', array_map( 'sanitize_text_field', (array) $model['output_modalities'] ) ) : 'text',
				'available' => isset( $model['available'] ) ? (bool) $model['available'] : true,
			);
		}
		return array( 'models' => $models, 'meta' => $response['meta'] );
	}

	/**
	 * POST /v1/chat/completions (OpenAI-compatible).
	 *
	 * @param array $args model, messages[], temperature, max_tokens, extra.
	 * @return array|WP_Error { text, raw, meta }
	 */
	public static function chat_completion( $args ) {
		$payload = self::build_chat_payload( $args );
		if ( is_wp_error( $payload ) ) {
			return $payload;
		}
		$response = self::request( 'POST', '/v1/chat/completions', $payload );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$text = self::parse_chat_text( $response['json'] );
		return array( 'text' => $text, 'raw' => $response['json'], 'meta' => $response['meta'] );
	}

	/**
	 * Build the chat payload (public for unit testing).
	 *
	 * @return array|WP_Error
	 */
	public static function build_chat_payload( $args ) {
		$settings = MPA_Settings::get();
		$model    = ! empty( $args['model'] ) ? sanitize_text_field( $args['model'] ) : $settings['default_model'];
		if ( '' === $model ) {
			return new WP_Error( 'mpa_no_model', __( 'No model configured. Set a default model under Mayfair AI → Models.', 'mayfair-arena-ai-bridge' ) );
		}
		if ( empty( $args['messages'] ) || ! is_array( $args['messages'] ) ) {
			return new WP_Error( 'mpa_no_messages', __( 'No messages supplied.', 'mayfair-arena-ai-bridge' ) );
		}
		$messages = array();
		foreach ( $args['messages'] as $message ) {
			if ( empty( $message['role'] ) || ! isset( $message['content'] ) ) {
				continue;
			}
			$role = in_array( $message['role'], array( 'system', 'user', 'assistant' ), true ) ? $message['role'] : 'user';
			$messages[] = array( 'role' => $role, 'content' => (string) $message['content'] );
		}
		$payload = array(
			'model'    => $model,
			'messages' => $messages,
		);
		// Arena fallback configuration (documented pattern: models array = primary + fallbacks).
		$fallbacks = ! empty( $args['fallback_models'] ) ? (array) $args['fallback_models'] : $settings['fallback_models'];
		$fallbacks = array_slice( array_filter( array_map( 'sanitize_text_field', $fallbacks ) ), 0, 3 );
		if ( ! empty( $fallbacks ) ) {
			$payload['models'] = array_merge( array( $model ), $fallbacks );
		}
		if ( isset( $args['temperature'] ) && '' !== $args['temperature'] ) {
			$payload['temperature'] = max( 0, min( 2, (float) $args['temperature'] ) );
		}
		if ( ! empty( $args['max_tokens'] ) ) {
			$payload['max_tokens'] = max( 1, min( 32000, (int) $args['max_tokens'] ) );
		}
		return $payload;
	}

	/** Parse assistant text out of an OpenAI-compatible response (public for testing). */
	public static function parse_chat_text( $json ) {
		if ( isset( $json['choices'][0]['message']['content'] ) ) {
			return (string) $json['choices'][0]['message']['content'];
		}
		if ( isset( $json['choices'][0]['text'] ) ) {
			return (string) $json['choices'][0]['text'];
		}
		return '';
	}

	/**
	 * POST /v1/messages (Anthropic-compatible).
	 *
	 * @return array|WP_Error
	 */
	public static function anthropic_message( $args ) {
		$settings = MPA_Settings::get();
		$model    = ! empty( $args['model'] ) ? sanitize_text_field( $args['model'] ) : $settings['default_model'];
		if ( '' === $model ) {
			return new WP_Error( 'mpa_no_model', __( 'No model configured.', 'mayfair-arena-ai-bridge' ) );
		}
		$payload = array(
			'model'      => $model,
			'max_tokens' => ! empty( $args['max_tokens'] ) ? max( 1, min( 32000, (int) $args['max_tokens'] ) ) : 1024,
			'messages'   => isset( $args['messages'] ) ? (array) $args['messages'] : array(),
		);
		if ( ! empty( $args['system'] ) ) {
			$payload['system'] = (string) $args['system'];
		}
		$response = self::request( 'POST', '/v1/messages', $payload );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$text = self::parse_anthropic_text( $response['json'] );
		return array( 'text' => $text, 'raw' => $response['json'], 'meta' => $response['meta'] );
	}

	/** Parse Anthropic-format content blocks (public for testing). */
	public static function parse_anthropic_text( $json ) {
		$out = '';
		if ( isset( $json['content'] ) && is_array( $json['content'] ) ) {
			foreach ( $json['content'] as $block ) {
				if ( isset( $block['type'] ) && 'text' === $block['type'] && isset( $block['text'] ) ) {
					$out .= $block['text'];
				}
			}
		}
		return $out;
	}

	/**
	 * POST /v1/images/generations
	 *
	 * @return array|WP_Error { images: [ {b64|url} ], meta }
	 */
	public static function generate_image( $args ) {
		$settings = MPA_Settings::get();
		$payload  = array(
			'prompt' => (string) ( isset( $args['prompt'] ) ? $args['prompt'] : '' ),
		);
		if ( '' === trim( $payload['prompt'] ) ) {
			return new WP_Error( 'mpa_no_prompt', __( 'Image prompt is required.', 'mayfair-arena-ai-bridge' ) );
		}
		$model = ! empty( $args['model'] ) ? sanitize_text_field( $args['model'] ) : $settings['default_model'];
		if ( '' !== $model ) {
			$payload['model'] = $model;
		}
		if ( ! empty( $args['size'] ) && preg_match( '/^\d{3,4}x\d{3,4}$/', $args['size'] ) ) {
			$payload['size'] = $args['size'];
		}
		if ( ! empty( $args['n'] ) ) {
			$payload['n'] = max( 1, min( 4, (int) $args['n'] ) );
		}
		$response = self::request( 'POST', '/v1/images/generations', $payload, 180 );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return array( 'images' => self::parse_images( $response['json'] ), 'meta' => $response['meta'] );
	}

	/**
	 * POST /v1/images/edits
	 *
	 * @return array|WP_Error
	 */
	public static function edit_image( $args ) {
		// Image edit requires multipart upload of the source image.
		$attachment_id = ! empty( $args['attachment_id'] ) ? (int) $args['attachment_id'] : 0;
		$path          = $attachment_id ? get_attached_file( $attachment_id ) : '';
		if ( ! $path || ! file_exists( $path ) ) {
			return new WP_Error( 'mpa_no_image', __( 'Source image not found in the Media Library.', 'mayfair-arena-ai-bridge' ) );
		}
		$prompt = isset( $args['prompt'] ) ? (string) $args['prompt'] : '';
		if ( '' === trim( $prompt ) ) {
			return new WP_Error( 'mpa_no_prompt', __( 'Edit prompt is required.', 'mayfair-arena-ai-bridge' ) );
		}

		$boundary = 'mpa' . wp_generate_password( 24, false, false );
		$body     = '';
		$fields   = array( 'prompt' => $prompt );
		$settings = MPA_Settings::get();
		if ( ! empty( $args['model'] ) || '' !== $settings['default_model'] ) {
			$fields['model'] = ! empty( $args['model'] ) ? sanitize_text_field( $args['model'] ) : $settings['default_model'];
		}
		foreach ( $fields as $name => $value ) {
			$body .= '--' . $boundary . "\r\n";
			$body .= 'Content-Disposition: form-data; name="' . $name . '"' . "\r\n\r\n" . $value . "\r\n";
		}
		$body .= '--' . $boundary . "\r\n";
		$body .= 'Content-Disposition: form-data; name="image"; filename="' . basename( $path ) . '"' . "\r\n";
		$body .= 'Content-Type: ' . get_post_mime_type( $attachment_id ) . "\r\n\r\n";
		$body .= file_get_contents( $path ) . "\r\n"; // phpcs:ignore WordPressVIPMinimum.Performance.FetchingRemoteData.FileGetContentsUnknown -- local attachment
		$body .= '--' . $boundary . '--';

		$response = self::request( 'POST', '/v1/images/edits', $body, 180, 'multipart/form-data; boundary=' . $boundary );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return array( 'images' => self::parse_images( $response['json'] ), 'meta' => $response['meta'] );
	}

	private static function parse_images( $json ) {
		$images = array();
		if ( isset( $json['data'] ) && is_array( $json['data'] ) ) {
			foreach ( $json['data'] as $item ) {
				if ( isset( $item['b64_json'] ) ) {
					$images[] = array( 'b64' => $item['b64_json'] );
				} elseif ( isset( $item['url'] ) ) {
					$images[] = array( 'url' => esc_url_raw( $item['url'] ) );
				}
			}
		}
		return $images;
	}

	/**
	 * GET /health/liveliness
	 *
	 * @return array|WP_Error
	 */
	public static function health_check() {
		$response = self::request( 'GET', '/health/liveliness', null, 15 );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		return array( 'ok' => ( $response['code'] >= 200 && $response['code'] < 300 ), 'meta' => $response['meta'] );
	}

	/* ------------------------------------------------------------------ */
	/* HTTP core                                                          */
	/* ------------------------------------------------------------------ */

	/**
	 * Perform an Arena API request via the WP HTTP API.
	 *
	 * @param string      $method  GET|POST.
	 * @param string      $route   e.g. /v1/models.
	 * @param array|string|null $body payload (array = JSON-encoded).
	 * @param int         $timeout override seconds.
	 * @param string      $content_type override.
	 * @return array|WP_Error { code, json, meta }
	 */
	public static function request( $method, $route, $body = null, $timeout = 0, $content_type = 'application/json' ) {
		$settings = MPA_Settings::get();
		$key      = MPA_Settings::get_api_key();
		if ( '' === $key && '/health/liveliness' !== $route ) {
			return new WP_Error( 'mpa_no_key', __( 'Arena API key is not configured. Add it under Mayfair AI → Connection.', 'mayfair-arena-ai-bridge' ) );
		}

		$base = untrailingslashit( esc_url_raw( $settings['api_base'] ) );
		if ( '' === $base || 0 !== strpos( $base, 'https://' ) ) {
			return new WP_Error( 'mpa_bad_base', __( 'API Base URL must be a valid https:// URL.', 'mayfair-arena-ai-bridge' ) );
		}
		$url = $base . $route;

		$args = array(
			'timeout' => $timeout > 0 ? $timeout : max( 5, min( 300, (int) $settings['timeout'] ) ),
			'headers' => array(
				'Authorization' => 'Bearer ' . $key,
				'Accept'        => 'application/json',
			),
		);
		if ( null !== $body ) {
			$args['headers']['Content-Type'] = $content_type;
			$args['body']                    = is_array( $body ) ? wp_json_encode( $body ) : $body;
		}

		$response = ( 'GET' === $method ) ? wp_remote_get( $url, $args ) : wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'mpa_network', self::human_error( 0, $response->get_error_message() ) );
		}

		$code    = (int) wp_remote_retrieve_response_code( $response );
		$raw     = wp_remote_retrieve_body( $response );
		$json    = json_decode( $raw, true );
		$meta    = self::extract_meta( $response, $code );

		if ( $code < 200 || $code >= 300 ) {
			$api_message = '';
			if ( is_array( $json ) ) {
				if ( isset( $json['error']['message'] ) ) {
					$api_message = (string) $json['error']['message'];
				} elseif ( isset( $json['message'] ) ) {
					$api_message = (string) $json['message'];
				}
			}
			$error = new WP_Error( 'mpa_http_' . $code, self::human_error( $code, $api_message ), array( 'meta' => $meta, 'status' => $code ) );
			// Respect Retry-After on 429 — surfaced to callers, no aggressive retry.
			if ( 429 === $code ) {
				$retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
				$error->add_data( array( 'retry_after' => (int) $retry_after ), 'retry' );
			}
			return $error;
		}

		if ( null === $json && '' !== trim( $raw ) && false !== strpos( (string) wp_remote_retrieve_header( $response, 'content-type' ), 'json' ) ) {
			return new WP_Error( 'mpa_bad_json', __( 'Arena returned a response that could not be parsed as JSON.', 'mayfair-arena-ai-bridge' ), array( 'meta' => $meta ) );
		}

		return array( 'code' => $code, 'json' => is_array( $json ) ? $json : array(), 'meta' => $meta );
	}

	/** Capture Arena trace/fallback headers. */
	private static function extract_meta( $response, $code ) {
		$meta = array( 'status' => $code );
		foreach ( self::TRACE_HEADERS as $header => $meta_key ) {
			$value = wp_remote_retrieve_header( $response, $header );
			if ( '' !== $value && null !== $value ) {
				$meta[ $meta_key ] = sanitize_text_field( is_array( $value ) ? implode( ',', $value ) : $value );
			}
		}
		return $meta;
	}

	/** Human-readable error per status. Never includes the API key. */
	public static function human_error( $code, $detail = '' ) {
		$map = array(
			0   => __( 'Could not reach the Arena API (network failure). Check connectivity and the API Base URL.', 'mayfair-arena-ai-bridge' ),
			400 => __( 'Arena rejected the request as invalid (400). The prompt or parameters may be malformed.', 'mayfair-arena-ai-bridge' ),
			401 => __( 'Authentication failed (401). The API key is missing, invalid, or revoked.', 'mayfair-arena-ai-bridge' ),
			403 => __( 'Access denied (403). The API key does not have permission for this operation.', 'mayfair-arena-ai-bridge' ),
			404 => __( 'Endpoint or model not found (404). Refresh the model list or check the API Base URL.', 'mayfair-arena-ai-bridge' ),
			408 => __( 'The request timed out on Arena\'s side (408). Try again or reduce the request size.', 'mayfair-arena-ai-bridge' ),
			409 => __( 'Request conflict (409). Try again.', 'mayfair-arena-ai-bridge' ),
			429 => __( 'Rate limited by Arena (429). Wait before retrying — the plugin will not retry aggressively.', 'mayfair-arena-ai-bridge' ),
			500 => __( 'Arena internal error (500). Try again shortly.', 'mayfair-arena-ai-bridge' ),
			502 => __( 'Bad gateway between WordPress and Arena (502). Try again shortly.', 'mayfair-arena-ai-bridge' ),
			503 => __( 'Arena service temporarily unavailable (503). Try again shortly.', 'mayfair-arena-ai-bridge' ),
			504 => __( 'Gateway timeout (504). The model may be overloaded; try again or use a fallback model.', 'mayfair-arena-ai-bridge' ),
		);
		$message = isset( $map[ $code ] ) ? $map[ $code ] : sprintf( /* translators: %d http code */ __( 'Arena API error (HTTP %d).', 'mayfair-arena-ai-bridge' ), $code );
		if ( '' !== $detail ) {
			// Detail comes from the API body/network layer — safe to append, never contains our key.
			$message .= ' ' . sanitize_text_field( $detail );
		}
		return $message;
	}
}
