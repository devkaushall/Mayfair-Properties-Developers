<?php
/**
 * Task engine: every AI request becomes a stored task with metadata.
 * Full prompts/responses stored ONLY when the admin enables it.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Tasks {

	public static function types() {
		return array( 'text', 'content', 'seo', 'property', 'project', 'insight', 'image', 'analysis' );
	}

	/** Create a pending task; returns id. */
	public static function create( $task_type, $action_key, $model, $prompt_text, $post_id = 0 ) {
		global $wpdb;
		$settings = MPA_Settings::get();
		$now      = current_time( 'mysql' );
		$wpdb->insert(
			MPA_Database::table( 'tasks' ),
			array(
				'task_type'   => in_array( $task_type, self::types(), true ) ? $task_type : 'text',
				'action_key'  => sanitize_key( $action_key ),
				'user_id'     => get_current_user_id(),
				'post_id'     => $post_id ? (int) $post_id : null,
				'model'       => sanitize_text_field( $model ),
				'prompt_hash' => hash( 'sha256', (string) $prompt_text ),
				'status'      => 'pending',
				'payload'     => ! empty( $settings['store_payloads'] ) ? wp_json_encode( array( 'prompt' => $prompt_text ) ) : null,
				'created_at'  => $now,
				'updated_at'  => $now,
			),
			array( '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/** Mark completed with response metadata (+ optional payload). */
	public static function complete( $task_id, $meta, $response_text = '' ) {
		global $wpdb;
		$settings = MPA_Settings::get();
		$update   = array(
			'status'         => 'completed',
			'response_meta'  => wp_json_encode( $meta ),
			'resolved_model' => isset( $meta['resolved_model'] ) ? sanitize_text_field( $meta['resolved_model'] ) : '',
			'trace_id'       => isset( $meta['trace_id'] ) ? sanitize_text_field( $meta['trace_id'] ) : '',
			'updated_at'     => current_time( 'mysql' ),
		);
		$formats = array( '%s', '%s', '%s', '%s', '%s' );
		if ( ! empty( $settings['store_payloads'] ) && '' !== $response_text ) {
			$existing = self::get( $task_id );
			$payload  = $existing && $existing['payload'] ? json_decode( $existing['payload'], true ) : array();
			$payload['response'] = $response_text;
			$update['payload']   = wp_json_encode( $payload );
			$formats[]           = '%s';
		}
		$wpdb->update( MPA_Database::table( 'tasks' ), $update, array( 'id' => (int) $task_id ), $formats, array( '%d' ) );
	}

	public static function fail( $task_id, $error_message, $meta = array() ) {
		global $wpdb;
		$wpdb->update(
			MPA_Database::table( 'tasks' ),
			array(
				'status'        => 'failed',
				'error'         => sanitize_textarea_field( $error_message ),
				'response_meta' => wp_json_encode( $meta ),
				'trace_id'      => isset( $meta['trace_id'] ) ? sanitize_text_field( $meta['trace_id'] ) : '',
				'updated_at'    => current_time( 'mysql' ),
			),
			array( 'id' => (int) $task_id ),
			array( '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function get( $task_id ) {
		global $wpdb;
		$t = MPA_Database::table( 'tasks' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $task_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function recent( $limit = 50 ) {
		global $wpdb;
		$t = MPA_Database::table( 'tasks' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function counters() {
		global $wpdb;
		$t   = MPA_Database::table( 'tasks' );
		$out = array();
		$out['today']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE created_at >= %s", gmdate( 'Y-m-d' ) . ' 00:00:00' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out['total']      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out['failed']     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status = 'failed'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out['last']       = $wpdb->get_row( "SELECT created_at, action_key, status FROM {$t} ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$out['last_error'] = $wpdb->get_row( "SELECT created_at, error FROM {$t} WHERE status = 'failed' ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $out;
	}
}
