<?php
/**
 * Prompt manager: CRUD + variable substitution ({{var}} against the
 * allowlist only) + built-in prompt seeds for the AI actions.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Prompts {

	/* ---------------- CRUD ---------------- */

	public static function create( $data ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$wpdb->insert(
			MPA_Database::table( 'prompts' ),
			array(
				'name'          => sanitize_text_field( isset( $data['name'] ) ? $data['name'] : '' ),
				'description'   => sanitize_textarea_field( isset( $data['description'] ) ? $data['description'] : '' ),
				'system_prompt' => sanitize_textarea_field( isset( $data['system_prompt'] ) ? $data['system_prompt'] : '' ),
				'user_template' => sanitize_textarea_field( isset( $data['user_template'] ) ? $data['user_template'] : '' ),
				'model'         => sanitize_text_field( isset( $data['model'] ) ? $data['model'] : '' ),
				'temperature'   => isset( $data['temperature'] ) && '' !== $data['temperature'] ? max( 0, min( 2, (float) $data['temperature'] ) ) : 0.7,
				'max_tokens'    => isset( $data['max_tokens'] ) ? max( 1, min( 32000, (int) $data['max_tokens'] ) ) : 1024,
				'output_format' => in_array( isset( $data['output_format'] ) ? $data['output_format'] : '', array( 'text', 'html', 'markdown', 'json' ), true ) ? $data['output_format'] : 'text',
				'action_key'    => sanitize_key( isset( $data['action_key'] ) ? $data['action_key'] : '' ),
				'status'        => ( isset( $data['status'] ) && 'inactive' === $data['status'] ) ? 'inactive' : 'active',
				'created_at'    => $now,
				'updated_at'    => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%f', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public static function update( $prompt_id, $data ) {
		$existing = self::get( $prompt_id );
		if ( ! $existing ) {
			return new WP_Error( 'mpa_prompt', __( 'Prompt not found.', 'mayfair-arena-ai-bridge' ) );
		}
		global $wpdb;
		$wpdb->delete( MPA_Database::table( 'prompts' ), array( 'id' => (int) $prompt_id ), array( '%d' ) );
		$data = array_merge( $existing, $data );
		unset( $data['id'] );
		return self::create( $data );
	}

	public static function duplicate( $prompt_id ) {
		$existing = self::get( $prompt_id );
		if ( ! $existing ) {
			return new WP_Error( 'mpa_prompt', __( 'Prompt not found.', 'mayfair-arena-ai-bridge' ) );
		}
		$existing['name']  .= ' (Copy)';
		$existing['status'] = 'inactive';
		$existing['action_key'] = '';
		unset( $existing['id'] );
		return self::create( $existing );
	}

	public static function delete( $prompt_id ) {
		global $wpdb;
		$wpdb->delete( MPA_Database::table( 'prompts' ), array( 'id' => (int) $prompt_id ), array( '%d' ) );
		return true;
	}

	public static function set_status( $prompt_id, $status ) {
		global $wpdb;
		$wpdb->update(
			MPA_Database::table( 'prompts' ),
			array( 'status' => ( 'active' === $status ) ? 'active' : 'inactive', 'updated_at' => current_time( 'mysql' ) ),
			array( 'id' => (int) $prompt_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		return true;
	}

	public static function get( $prompt_id ) {
		global $wpdb;
		$t = MPA_Database::table( 'prompts' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d", $prompt_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function get_by_action( $action_key ) {
		global $wpdb;
		$t = MPA_Database::table( 'prompts' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE action_key = %s AND status = 'active' ORDER BY id DESC LIMIT 1", $action_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	public static function all() {
		global $wpdb;
		$t = MPA_Database::table( 'prompts' );
		return $wpdb->get_results( "SELECT * FROM {$t} ORDER BY name ASC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/* ---------------- Variable substitution ---------------- */

	/**
	 * Replace {{variable}} placeholders using ONLY the allowlist.
	 * Unknown variables are replaced with empty string and reported.
	 * No code execution of any kind.
	 *
	 * @return array { text, unknown[] }
	 */
	public static function substitute( $template, $vars ) {
		$allowed = MPA_Context::allowed_variables();
		$allowed[] = 'featured_image_alt';
		$unknown = array();
		$text    = preg_replace_callback(
			'/\{\{\s*([a-z0-9_]+)\s*\}\}/i',
			function ( $m ) use ( $vars, $allowed, &$unknown ) {
				$key = strtolower( $m[1] );
				if ( ! in_array( $key, $allowed, true ) ) {
					$unknown[] = $key;
					return '';
				}
				return isset( $vars[ $key ] ) ? (string) $vars[ $key ] : '';
			},
			(string) $template
		);
		return array( 'text' => $text, 'unknown' => array_values( array_unique( $unknown ) ) );
	}

	/* ---------------- Built-in prompt seeds ---------------- */

	/** Seeded once on activation. All editable; wired to the editor actions via action_key. */
	public static function seeds() {
		$brand = 'You write for Mayfair Properties & Developers, a premium Indian real estate agency. Tone: trustworthy, editorial, warm, precise. Never salesy hype. British-Indian English. ';
		return array(
			// Property
			array( 'action_key' => 'property_description', 'name' => 'Property — Generate Description', 'system_prompt' => $brand . 'Write a property description of 150-250 words using ONLY the supplied factual data.', 'user_template' => "Property: {{property_title}}\nLocation: {{location}} {{locality}}\nType: {{property_type}} | Status: {{property_status}}\nExisting notes: {{content}}\n\nWrite the description.", 'output_format' => 'text' ),
			array( 'action_key' => 'property_rewrite', 'name' => 'Property — Rewrite Description', 'system_prompt' => $brand . 'Rewrite the given description: keep every fact identical, improve clarity and flow. Never add facts.', 'user_template' => "Rewrite this property description:\n\n{{content}}", 'output_format' => 'text' ),
			array( 'action_key' => 'property_short', 'name' => 'Property — Short Description', 'system_prompt' => $brand . 'Write a 40-60 word teaser description from the supplied data only.', 'user_template' => "Property: {{property_title}} in {{location}}. Facts and notes: {{content}}", 'output_format' => 'text' ),
			array( 'action_key' => 'property_seo_title', 'name' => 'Property — SEO Title', 'system_prompt' => $brand . 'Write one SEO title, max 60 characters. Include the property name and location if available. Output only the title.', 'user_template' => "Property: {{property_title}} | Location: {{location}} | Type: {{property_type}}", 'output_format' => 'text', 'max_tokens' => 60 ),
			array( 'action_key' => 'property_meta_desc', 'name' => 'Property — Meta Description', 'system_prompt' => $brand . 'Write one meta description, 140-155 characters, factual, with a soft call to action. Output only the description.', 'user_template' => "Property: {{property_title}} in {{location}}. {{content}}", 'output_format' => 'text', 'max_tokens' => 100 ),
			array( 'action_key' => 'property_highlights', 'name' => 'Property — Highlights', 'system_prompt' => $brand . 'Produce 4-6 short bullet highlights from the supplied facts ONLY. One line each, no invented amenities.', 'user_template' => "Property: {{property_title}}\nNotes: {{content}}", 'output_format' => 'text' ),
			array( 'action_key' => 'property_cta', 'name' => 'Property — CTA Copy', 'system_prompt' => $brand . 'Write 2-3 short call-to-action lines (max 12 words each) inviting an enquiry or site visit.', 'user_template' => "Property: {{property_title}} in {{location}}.", 'output_format' => 'text', 'max_tokens' => 120 ),
			array( 'action_key' => 'property_social', 'name' => 'Property — Social Caption', 'system_prompt' => $brand . 'Write one Instagram-style caption (max 220 characters) plus 5 relevant hashtags. Facts only.', 'user_template' => "Property: {{property_title}} in {{location}}. {{content}}", 'output_format' => 'text', 'max_tokens' => 160 ),
			// Project
			array( 'action_key' => 'project_description', 'name' => 'Project — Generate Description', 'system_prompt' => $brand . 'Write a project overview of 150-250 words from the supplied data only. Never invent RERA numbers or possession dates.', 'user_template' => "Project: {{project_title}}\nDeveloper: {{developer}}\nLocation: {{location}}\nType: {{project_type}}\nNotes: {{content}}", 'output_format' => 'text' ),
			array( 'action_key' => 'project_highlights', 'name' => 'Project — Highlights', 'system_prompt' => $brand . 'Produce 4-6 factual bullet highlights from the supplied data only.', 'user_template' => "Project: {{project_title}}. Notes: {{content}}", 'output_format' => 'text' ),
			array( 'action_key' => 'project_seo_title', 'name' => 'Project — SEO Title', 'system_prompt' => $brand . 'One SEO title, max 60 characters. Output only the title.', 'user_template' => "Project: {{project_title}} | {{location}} | {{project_type}}", 'output_format' => 'text', 'max_tokens' => 60 ),
			array( 'action_key' => 'project_meta_desc', 'name' => 'Project — Meta Description', 'system_prompt' => $brand . 'One meta description, 140-155 characters. Output only the description.', 'user_template' => "Project: {{project_title}} in {{location}}. {{content}}", 'output_format' => 'text', 'max_tokens' => 100 ),
			array( 'action_key' => 'project_cta', 'name' => 'Project — CTA Copy', 'system_prompt' => $brand . 'Write 2-3 short CTA lines for project enquiries.', 'user_template' => "Project: {{project_title}} in {{location}}.", 'output_format' => 'text', 'max_tokens' => 120 ),
			array( 'action_key' => 'project_social', 'name' => 'Project — Social Caption', 'system_prompt' => $brand . 'One social caption (max 220 chars) + 5 hashtags. Facts only.', 'user_template' => "Project: {{project_title}} in {{location}}. {{content}}", 'output_format' => 'text', 'max_tokens' => 160 ),
			// Insight
			array( 'action_key' => 'insight_outline', 'name' => 'Insight — Generate Outline', 'system_prompt' => $brand . 'Create a structured article outline (H2/H3 headings with one-line notes) for the given topic.', 'user_template' => "Article: {{insight_title}}\nSubtitle: {{insight_subtitle}}\nTopic: {{insight_topic}}\nExisting notes: {{content}}", 'output_format' => 'markdown' ),
			array( 'action_key' => 'insight_draft', 'name' => 'Insight — Generate Draft', 'system_prompt' => $brand . 'Write a full article draft (700-1000 words) with clear H2 sections. Mark any statistic or claim that needs verification as [VERIFY]. This is a DRAFT for human editing.', 'user_template' => "Article: {{insight_title}}\nSubtitle: {{insight_subtitle}}\nTopic: {{insight_topic}}\nOutline/notes: {{content}}", 'output_format' => 'markdown', 'max_tokens' => 2400 ),
			array( 'action_key' => 'insight_rewrite', 'name' => 'Insight — Rewrite', 'system_prompt' => $brand . 'Rewrite for clarity and flow. Keep all facts identical.', 'user_template' => "Rewrite:\n\n{{content}}", 'output_format' => 'text', 'max_tokens' => 2400 ),
			array( 'action_key' => 'insight_summarize', 'name' => 'Insight — Summarize', 'system_prompt' => $brand . 'Summarize in 3-5 sentences.', 'user_template' => "Summarize:\n\n{{content}}", 'output_format' => 'text', 'max_tokens' => 300 ),
			array( 'action_key' => 'insight_excerpt', 'name' => 'Insight — Generate Excerpt', 'system_prompt' => $brand . 'Write one excerpt of 25-40 words. Output only the excerpt.', 'user_template' => "Article: {{insight_title}}\n\n{{content}}", 'output_format' => 'text', 'max_tokens' => 80 ),
			array( 'action_key' => 'insight_seo_title', 'name' => 'Insight — SEO Title', 'system_prompt' => $brand . 'One SEO title, max 60 characters. Output only the title.', 'user_template' => "Article: {{insight_title}} | Topic: {{insight_topic}}", 'output_format' => 'text', 'max_tokens' => 60 ),
			array( 'action_key' => 'insight_meta_desc', 'name' => 'Insight — Meta Description', 'system_prompt' => $brand . 'One meta description, 140-155 characters. Output only the description.', 'user_template' => "Article: {{insight_title}}. {{content}}", 'output_format' => 'text', 'max_tokens' => 100 ),
			array( 'action_key' => 'insight_faq', 'name' => 'Insight — FAQ Draft', 'system_prompt' => $brand . 'Draft 4-6 FAQ question/answer pairs based ONLY on the article content. Mark uncertain answers [VERIFY].', 'user_template' => "Article: {{insight_title}}\n\n{{content}}", 'output_format' => 'markdown', 'max_tokens' => 900 ),
			array( 'action_key' => 'insight_social', 'name' => 'Insight — Social Caption', 'system_prompt' => $brand . 'One social caption (max 220 chars) + 5 hashtags.', 'user_template' => "Article: {{insight_title}}. {{excerpt}}", 'output_format' => 'text', 'max_tokens' => 160 ),
		);
	}

	public static function seed() {
		if ( get_option( 'mpa_prompts_seeded' ) ) {
			return;
		}
		foreach ( self::seeds() as $seed ) {
			self::create( $seed );
		}
		update_option( 'mpa_prompts_seeded', 1 );
	}
}
