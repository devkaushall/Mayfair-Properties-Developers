<?php
/**
 * Elementor widget: Mayfair AI.
 * The prompt/model/max_tokens are WIDGET SETTINGS (configured by the site
 * builder, stored server-side in Elementor data) — visitors never supply
 * arbitrary prompts. Output is sanitized text.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class MPA_Elementor_Widget extends Widget_Base {

	public function get_name() {
		return 'mayfair_ai';
	}

	public function get_title() {
		return __( 'Mayfair AI', 'mayfair-arena-ai-bridge' );
	}

	public function get_icon() {
		return 'eicon-ai';
	}

	public function get_categories() {
		return array( 'mayfair' );
	}

	public function get_script_depends() {
		return array( 'mpa-widget' );
	}

	protected function register_controls() {
		$this->start_controls_section( 'section_ai', array( 'label' => __( 'AI', 'mayfair-arena-ai-bridge' ) ) );

		$this->add_control( 'prompt', array(
			'label'       => __( 'Prompt', 'mayfair-arena-ai-bridge' ),
			'type'        => Controls_Manager::TEXTAREA,
			'rows'        => 6,
			'description' => __( 'Configured by you, the builder — visitors cannot change it.', 'mayfair-arena-ai-bridge' ),
		) );

		$this->add_control( 'model', array(
			'label'       => __( 'Model (optional)', 'mayfair-arena-ai-bridge' ),
			'type'        => Controls_Manager::TEXT,
			'description' => __( 'Leave empty to use the default model from Mayfair AI → Connection.', 'mayfair-arena-ai-bridge' ),
		) );

		$this->add_control( 'max_tokens', array(
			'label'   => __( 'Max Tokens', 'mayfair-arena-ai-bridge' ),
			'type'    => Controls_Manager::NUMBER,
			'default' => 512,
			'min'     => 16,
			'max'     => 2000,
		) );

		$this->add_control( 'output_mode', array(
			'label'   => __( 'Output Mode', 'mayfair-arena-ai-bridge' ),
			'type'    => Controls_Manager::SELECT,
			'options' => array(
				'button' => __( 'Generate on button click', 'mayfair-arena-ai-bridge' ),
				'hidden' => __( 'Hidden until generated', 'mayfair-arena-ai-bridge' ),
			),
			'default' => 'button',
		) );

		$this->add_control( 'button_text', array(
			'label'   => __( 'Button Text', 'mayfair-arena-ai-bridge' ),
			'type'    => Controls_Manager::TEXT,
			'default' => __( 'Generate', 'mayfair-arena-ai-bridge' ),
		) );

		$this->add_control( 'loading_text', array(
			'label'   => __( 'Loading Text', 'mayfair-arena-ai-bridge' ),
			'type'    => Controls_Manager::TEXT,
			'default' => __( 'Thinking…', 'mayfair-arena-ai-bridge' ),
		) );

		$this->add_control( 'error_text', array(
			'label'   => __( 'Error Text', 'mayfair-arena-ai-bridge' ),
			'type'    => Controls_Manager::TEXT,
			'default' => __( 'Something went wrong. Please try again.', 'mayfair-arena-ai-bridge' ),
		) );

		$this->add_control( 'security_note', array(
			'type' => Controls_Manager::RAW_HTML,
			'raw'  => esc_html__( 'By default this widget only works for logged-in authorized users. Anonymous public mode must be explicitly enabled under Mayfair AI → Settings and is rate-limited per IP.', 'mayfair-arena-ai-bridge' ),
		) );

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$prompt   = (string) $settings['prompt'];
		if ( '' === trim( $prompt ) ) {
			if ( current_user_can( MPA_Settings::CAP ) ) {
				echo '<p>' . esc_html__( 'Mayfair AI widget: configure a prompt in the widget settings.', 'mayfair-arena-ai-bridge' ) . '</p>';
			}
			return;
		}
		$app = MPA_Settings::get();
		// If public mode is off and visitor is anonymous, render nothing (no key exposure, no dead UI).
		if ( empty( $app['public_widget'] ) && ! is_user_logged_in() ) {
			return;
		}
		wp_enqueue_script( 'mpa-widget' );
		?>
		<div class="mpa-widget"
			data-prompt="<?php echo esc_attr( $prompt ); ?>"
			data-model="<?php echo esc_attr( (string) $settings['model'] ); ?>"
			data-max="<?php echo esc_attr( (int) $settings['max_tokens'] ); ?>"
			data-loading="<?php echo esc_attr( (string) $settings['loading_text'] ); ?>"
			data-error="<?php echo esc_attr( (string) $settings['error_text'] ); ?>">
			<button type="button" class="mpa-widget__btn elementor-button"><?php echo esc_html( (string) $settings['button_text'] ); ?></button>
			<div class="mpa-widget__out" role="status" aria-live="polite" hidden>
				<span class="mpa-widget__label"><?php esc_html_e( 'AI-generated', 'mayfair-arena-ai-bridge' ); ?></span>
				<div class="mpa-widget__text"></div>
			</div>
		</div>
		<?php
	}
}
