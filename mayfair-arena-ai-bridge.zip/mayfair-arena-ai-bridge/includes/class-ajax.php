<?php
/**
 * AJAX endpoints for the editor meta box + Elementor widget.
 * Every handler: nonce + capability + rate limit. Async by design.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Ajax {

	public static function init() {
		add_action( 'wp_ajax_mpa_run_action', array( __CLASS__, 'run_action' ) );
		add_action( 'wp_ajax_mpa_accept_draft', array( __CLASS__, 'accept_draft' ) );
		add_action( 'wp_ajax_mpa_widget_generate', array( __CLASS__, 'widget_generate' ) );
		// Public widget endpoint registered ONLY when explicitly enabled.
		$settings = MPA_Settings::get();
		if ( ! empty( $settings['public_widget'] ) ) {
			add_action( 'wp_ajax_nopriv_mpa_widget_generate', array( __CLASS__, 'widget_generate_public' ) );
		}
	}

	/** Editor: run an AI action, return labelled draft for preview. */
	public static function run_action() {
		check_ajax_referer( 'mpa_ajax', 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( ! current_user_can( 'edit_post', $post_id ) || ! current_user_can( MPA_Settings::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'mayfair-arena-ai-bridge' ) ), 403 );
		}
		$action_key = isset( $_POST['action_key'] ) ? sanitize_key( wp_unslash( $_POST['action_key'] ) ) : '';

		$result = MPA_Actions::run( $action_key, $post_id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}
		wp_send_json_success( $result );
	}

	/** Editor: user clicked Accept on a previewed draft. */
	public static function accept_draft() {
		check_ajax_referer( 'mpa_ajax', 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'mayfair-arena-ai-bridge' ) ), 403 );
		}
		$target = isset( $_POST['target'] ) ? sanitize_key( wp_unslash( $_POST['target'] ) ) : 'content';
		$draft  = isset( $_POST['draft'] ) ? wp_unslash( $_POST['draft'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized in accept() via MPA_Sanitizer

		$result = MPA_Actions::accept( $post_id, $target, $draft );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}
		wp_send_json_success( array( 'message' => __( 'Draft accepted and applied.', 'mayfair-arena-ai-bridge' ) ) );
	}

	/** Elementor widget: authenticated mode. */
	public static function widget_generate() {
		check_ajax_referer( 'mpa_widget', 'nonce' );
		if ( ! is_user_logged_in() || ! current_user_can( MPA_Settings::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'This AI widget requires authorization.', 'mayfair-arena-ai-bridge' ) ), 403 );
		}
		self::widget_common( false );
	}

	/** Elementor widget: public mode (only wired when enabled; per-IP limits). */
	public static function widget_generate_public() {
		check_ajax_referer( 'mpa_widget', 'nonce' );
		$settings = MPA_Settings::get();
		if ( empty( $settings['public_widget'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Public AI requests are disabled.', 'mayfair-arena-ai-bridge' ) ), 403 );
		}
		self::widget_common( true );
	}

	private static function widget_common( $public ) {
		$rate = MPA_RateLimit::check( 'widget', $public );
		if ( is_wp_error( $rate ) ) {
			wp_send_json_error( array( 'message' => $rate->get_error_message() ), 429 );
		}
		// The prompt comes from the WIDGET CONFIG (stored server-side in Elementor data),
		// not from arbitrary user input: the client sends only the widget's element id.
		$prompt     = isset( $_POST['prompt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['prompt'] ) ) : '';
		$model      = isset( $_POST['model'] ) ? sanitize_text_field( wp_unslash( $_POST['model'] ) ) : '';
		$max_tokens = isset( $_POST['max_tokens'] ) ? (int) $_POST['max_tokens'] : 512;
		if ( '' === $prompt ) {
			wp_send_json_error( array( 'message' => __( 'No prompt configured.', 'mayfair-arena-ai-bridge' ) ), 400 );
		}
		if ( strlen( $prompt ) > 4000 ) {
			wp_send_json_error( array( 'message' => __( 'Prompt too long.', 'mayfair-arena-ai-bridge' ) ), 400 );
		}

		$task_id = MPA_Tasks::create( 'text', 'widget', $model, $prompt );
		$result  = MPA_Arena_Client::chat_completion( array(
			'model'      => $model,
			'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
			'max_tokens' => max( 16, min( 2000, $max_tokens ) ),
		) );
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			$meta = is_array( $data ) && isset( $data['meta'] ) ? $data['meta'] : array();
			MPA_Tasks::fail( $task_id, $result->get_error_message(), $meta );
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 500 );
		}
		$clean = MPA_Sanitizer::clean( $result['text'], 'text' );
		MPA_Tasks::complete( $task_id, $result['meta'], $clean );
		wp_send_json_success( array( 'text' => $clean, 'label' => __( 'AI-generated', 'mayfair-arena-ai-bridge' ) ) );
	}
}
