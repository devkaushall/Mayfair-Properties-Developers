<?php
/**
 * REST API (mayfair-ai/v1) — authenticated, capability-gated.
 * The Arena key is NEVER present in any response.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_REST {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
	}

	public static function routes() {
		register_rest_route( 'mayfair-ai/v1', '/models', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'models' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
		) );

		register_rest_route( 'mayfair-ai/v1', '/generate', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( __CLASS__, 'generate' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
			'args'                => array(
				'prompt'     => array( 'type' => 'string', 'required' => true ),
				'model'      => array( 'type' => 'string', 'required' => false ),
				'max_tokens' => array( 'type' => 'integer', 'required' => false, 'default' => 512 ),
				'system'     => array( 'type' => 'string', 'required' => false ),
			),
		) );

		register_rest_route( 'mayfair-ai/v1', '/tasks/(?P<id>\d+)', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'task' ),
			'permission_callback' => array( __CLASS__, 'can_manage' ),
		) );
	}

	public static function can_manage() {
		return current_user_can( MPA_Settings::CAP );
	}

	public static function models() {
		$settings = MPA_Settings::get();
		// Serve cache when fresh (1 hour), refresh otherwise.
		if ( ! empty( $settings['models_cache'] ) && ( time() - (int) $settings['models_cached_at'] ) < 3600 ) {
			return rest_ensure_response( array( 'models' => $settings['models_cache'], 'cached' => true ) );
		}
		$result = MPA_Arena_Client::list_models();
		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'mpa_models', $result->get_error_message(), array( 'status' => 502 ) );
		}
		$settings['models_cache']     = $result['models'];
		$settings['models_cached_at'] = time();
		MPA_Settings::update( $settings );
		return rest_ensure_response( array( 'models' => $result['models'], 'cached' => false ) );
	}

	public static function generate( WP_REST_Request $request ) {
		$rate = MPA_RateLimit::check( 'rest_generate' );
		if ( is_wp_error( $rate ) ) {
			return new WP_Error( 'mpa_rate', $rate->get_error_message(), array( 'status' => 429 ) );
		}
		$prompt = sanitize_textarea_field( (string) $request->get_param( 'prompt' ) );
		if ( '' === $prompt || strlen( $prompt ) > 8000 ) {
			return new WP_Error( 'mpa_prompt', __( 'Prompt is empty or too long.', 'mayfair-arena-ai-bridge' ), array( 'status' => 400 ) );
		}
		$messages = array();
		$system   = sanitize_textarea_field( (string) $request->get_param( 'system' ) );
		if ( '' !== $system ) {
			$messages[] = array( 'role' => 'system', 'content' => $system );
		}
		$messages[] = array( 'role' => 'user', 'content' => $prompt );

		$task_id = MPA_Tasks::create( 'text', 'rest_generate', (string) $request->get_param( 'model' ), $prompt );
		$result  = MPA_Arena_Client::chat_completion( array(
			'model'      => (string) $request->get_param( 'model' ),
			'messages'   => $messages,
			'max_tokens' => (int) $request->get_param( 'max_tokens' ),
		) );
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			$meta = is_array( $data ) && isset( $data['meta'] ) ? $data['meta'] : array();
			MPA_Tasks::fail( $task_id, $result->get_error_message(), $meta );
			return new WP_Error( 'mpa_generate', $result->get_error_message(), array( 'status' => 502 ) );
		}
		$clean = MPA_Sanitizer::clean( $result['text'], 'text' );
		MPA_Tasks::complete( $task_id, $result['meta'], $clean );
		return rest_ensure_response( array(
			'task_id' => $task_id,
			'text'    => $clean,
			'label'   => 'AI-generated',
			'meta'    => $result['meta'], // trace/fallback metadata only — never the key
		) );
	}

	public static function task( WP_REST_Request $request ) {
		$task = MPA_Tasks::get( (int) $request['id'] );
		if ( ! $task ) {
			return new WP_Error( 'mpa_task', __( 'Task not found.', 'mayfair-arena-ai-bridge' ), array( 'status' => 404 ) );
		}
		// payload only included if payload storage is enabled (admin opt-in).
		return rest_ensure_response( array(
			'id'             => (int) $task['id'],
			'type'           => $task['task_type'],
			'action'         => $task['action_key'],
			'status'         => $task['status'],
			'model'          => $task['model'],
			'resolved_model' => $task['resolved_model'],
			'trace_id'       => $task['trace_id'],
			'error'          => $task['error'],
			'created_at'     => $task['created_at'],
			'payload'        => $task['payload'] ? json_decode( $task['payload'], true ) : null,
		) );
	}
}
