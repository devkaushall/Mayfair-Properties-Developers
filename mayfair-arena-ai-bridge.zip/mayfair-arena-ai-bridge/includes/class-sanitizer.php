<?php
/**
 * AI output sanitizer. All AI-generated content is untrusted:
 * - never executed (no PHP/JS/shell paths exist)
 * - HTML sanitized with a restricted kses profile before storage/display
 * - scripts/styles/iframes/event handlers stripped
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Sanitizer {

	/** Restricted tag profile for AI HTML output (tighter than wp_kses_post). */
	public static function allowed_html() {
		return array(
			'p'      => array(),
			'br'     => array(),
			'strong' => array(),
			'em'     => array(),
			'b'      => array(),
			'i'      => array(),
			'u'      => array(),
			'h2'     => array(),
			'h3'     => array(),
			'h4'     => array(),
			'ul'     => array(),
			'ol'     => array(),
			'li'     => array(),
			'blockquote' => array(),
			'a'      => array( 'href' => true, 'title' => true, 'rel' => true ),
			'table'  => array(),
			'thead'  => array(),
			'tbody'  => array(),
			'tr'     => array(),
			'th'     => array(),
			'td'     => array(),
		);
	}

	/**
	 * Sanitize AI output according to declared format.
	 * text/markdown -> plain text preserved, tags stripped.
	 * html          -> restricted kses profile.
	 * json          -> must parse; re-encoded canonical JSON or plain text fallback.
	 */
	public static function clean( $output, $format = 'text' ) {
		$output = (string) $output;
		// Belt & braces: kill script/style/iframe blocks and PHP tags in ALL formats first.
		$output = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $output );
		$output = preg_replace( '#<style\b[^>]*>.*?</style>#is', '', $output );
		$output = preg_replace( '#<iframe\b[^>]*>.*?</iframe>#is', '', $output );
		// Strip complete PHP blocks (content included), then any orphan tags.
		$output = preg_replace( '#<\?(?:php|=)?.*?(?:\?>|$)#is', '', $output );
		$output = str_replace( array( '<?php', '<?=', '?>' ), '', $output );

		switch ( $format ) {
			case 'html':
				return wp_kses( $output, self::allowed_html() );
			case 'json':
				$decoded = json_decode( $output, true );
				if ( null !== $decoded ) {
					return wp_json_encode( $decoded, JSON_PRETTY_PRINT );
				}
				return sanitize_textarea_field( $output );
			case 'markdown':
			case 'text':
			default:
				// Markdown stays as text (rendered elsewhere if ever needed); strip any HTML.
				return sanitize_textarea_field( $output );
		}
	}

	/** Label AI content unmistakably when presented for review. */
	public static function label() {
		return __( 'AI Draft — review required. Accept to use it, Reject to discard. Nothing is applied automatically.', 'mayfair-arena-ai-bridge' );
	}
}
