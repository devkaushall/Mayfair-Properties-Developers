<?php
/**
 * "Mayfair AI" meta box on property/project/insight editors.
 * Generate → Preview (labelled AI Draft) → Accept / Reject.
 * Vanilla JS, async, never touches content without explicit Accept.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Metabox {

	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function register() {
		foreach ( array( 'property', 'project', 'insight' ) as $post_type ) {
			add_meta_box(
				'mpa-ai-box',
				__( 'Mayfair AI', 'mayfair-arena-ai-bridge' ),
				array( __CLASS__, 'render' ),
				$post_type,
				'side',
				'default'
			);
		}
	}

	public static function assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->post_type, array( 'property', 'project', 'insight' ), true ) ) {
			return;
		}
		wp_enqueue_style( 'mpa-admin', MPA_URL . 'admin/assets/mpa-admin.css', array(), MPA_VERSION );
		wp_enqueue_script( 'mpa-metabox', MPA_URL . 'admin/assets/mpa-metabox.js', array(), MPA_VERSION, true );
		wp_localize_script( 'mpa-metabox', 'mpaBox', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'mpa_ajax' ),
			'i18n'    => array(
				'working' => __( 'Generating… this can take up to a minute.', 'mayfair-arena-ai-bridge' ),
				'error'   => __( 'Generation failed.', 'mayfair-arena-ai-bridge' ),
				'confirm' => __( 'Apply this AI draft? Your current field content will be replaced (a revision is kept by WordPress).', 'mayfair-arena-ai-bridge' ),
			),
		) );
	}

	public static function render( $post ) {
		if ( ! current_user_can( MPA_Settings::CAP ) ) {
			echo '<p>' . esc_html__( 'You do not have permission to use Mayfair AI.', 'mayfair-arena-ai-bridge' ) . '</p>';
			return;
		}
		if ( ! MPA_Settings::has_api_key() ) {
			echo '<p>' . esc_html__( 'Arena API key not configured. Go to Mayfair AI → Connection.', 'mayfair-arena-ai-bridge' ) . '</p>';
			return;
		}
		$actions = MPA_Actions::actions_for( $post->post_type );
		?>
		<div class="mpa-box" data-post="<?php echo esc_attr( $post->ID ); ?>">
			<p class="mpa-box__hint"><?php esc_html_e( 'Output appears below as a labelled AI Draft. Nothing changes until you click Accept.', 'mayfair-arena-ai-bridge' ); ?></p>
			<label for="mpa-action" class="screen-reader-text"><?php esc_html_e( 'AI action', 'mayfair-arena-ai-bridge' ); ?></label>
			<select id="mpa-action" class="mpa-box__select">
				<?php foreach ( $actions as $mpa_key => $mpa_label ) : ?>
					<option value="<?php echo esc_attr( $mpa_key ); ?>"><?php echo esc_html( $mpa_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<button type="button" class="button button-primary mpa-box__generate"><?php esc_html_e( 'Generate', 'mayfair-arena-ai-bridge' ); ?></button>
			<div class="mpa-box__status" role="status" aria-live="polite"></div>
			<div class="mpa-box__preview" hidden>
				<p class="mpa-box__label"><strong><?php esc_html_e( 'AI Draft', 'mayfair-arena-ai-bridge' ); ?></strong> — <?php esc_html_e( 'review before use', 'mayfair-arena-ai-bridge' ); ?></p>
				<textarea class="mpa-box__draft" rows="10" readonly></textarea>
				<p class="mpa-box__meta"></p>
				<label for="mpa-target"><?php esc_html_e( 'Apply to:', 'mayfair-arena-ai-bridge' ); ?></label>
				<select id="mpa-target" class="mpa-box__target">
					<option value="content"><?php esc_html_e( 'Post content (replace)', 'mayfair-arena-ai-bridge' ); ?></option>
					<option value="excerpt"><?php esc_html_e( 'Excerpt', 'mayfair-arena-ai-bridge' ); ?></option>
					<?php if ( 'insight' === $post->post_type ) : ?>
						<option value="draft_post"><?php esc_html_e( 'New draft post (safest)', 'mayfair-arena-ai-bridge' ); ?></option>
					<?php endif; ?>
				</select>
				<p>
					<button type="button" class="button button-primary mpa-box__accept"><?php esc_html_e( 'Accept', 'mayfair-arena-ai-bridge' ); ?></button>
					<button type="button" class="button mpa-box__reject"><?php esc_html_e( 'Reject', 'mayfair-arena-ai-bridge' ); ?></button>
					<button type="button" class="button mpa-box__copy"><?php esc_html_e( 'Copy', 'mayfair-arena-ai-bridge' ); ?></button>
				</p>
				<p class="description"><?php esc_html_e( 'SEO titles/descriptions: use Copy, then paste into the Rank Math fields.', 'mayfair-arena-ai-bridge' ); ?></p>
			</div>
		</div>
		<?php
	}
}
