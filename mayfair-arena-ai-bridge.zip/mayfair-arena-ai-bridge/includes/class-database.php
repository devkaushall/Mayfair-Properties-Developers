<?php
/**
 * Database: 3 custom tables ({prefix}mpa_tasks / _prompts / _logs)
 * via dbDelta. Uninstall preserves data by default.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MPA_Database {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'mpa_' . $name;
	}

	public static function activate() {
		self::create_tables();
		$role = get_role( 'administrator' );
		if ( $role ) {
			$role->add_cap( MPA_Settings::CAP );
		}
		MPA_Prompts::seed();
		update_option( 'mpa_db_version', MPA_DB_VERSION );
		add_option( 'mpa_delete_on_uninstall', 0 ); // default OFF — data survives uninstall
	}

	public static function deactivate() {
		// Nothing destructive.
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$tasks   = self::table( 'tasks' );
		$prompts = self::table( 'prompts' );
		$logs    = self::table( 'logs' );

		dbDelta( "CREATE TABLE {$tasks} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			task_type VARCHAR(30) NOT NULL DEFAULT 'text',
			action_key VARCHAR(60) NOT NULL DEFAULT '',
			user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			post_id BIGINT(20) UNSIGNED NULL,
			model VARCHAR(190) NOT NULL DEFAULT '',
			resolved_model VARCHAR(190) NOT NULL DEFAULT '',
			prompt_hash VARCHAR(64) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			response_meta LONGTEXT NULL,
			payload LONGTEXT NULL,
			error TEXT NULL,
			trace_id VARCHAR(190) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY task_type (task_type),
			KEY user_id (user_id),
			KEY post_id (post_id),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$prompts} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL,
			description TEXT NULL,
			system_prompt LONGTEXT NULL,
			user_template LONGTEXT NULL,
			model VARCHAR(190) NOT NULL DEFAULT '',
			temperature FLOAT NOT NULL DEFAULT 0.7,
			max_tokens INT(11) UNSIGNED NOT NULL DEFAULT 1024,
			output_format VARCHAR(20) NOT NULL DEFAULT 'text',
			action_key VARCHAR(60) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY action_key (action_key),
			KEY status (status)
		) {$charset};" );

		dbDelta( "CREATE TABLE {$logs} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			level VARCHAR(10) NOT NULL DEFAULT 'info',
			source VARCHAR(60) NOT NULL DEFAULT '',
			message TEXT NULL,
			context LONGTEXT NULL,
			trace_id VARCHAR(190) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY level (level),
			KEY created_at (created_at)
		) {$charset};" );
	}

	/** Write a log row. Context is JSON; API keys are never logged. */
	public static function log( $level, $source, $message, $context = array(), $trace_id = '' ) {
		global $wpdb;
		$settings = MPA_Settings::get();
		if ( 'debug' === $level && empty( $settings['debug_logging'] ) ) {
			return;
		}
		$wpdb->insert(
			self::table( 'logs' ),
			array(
				'level'      => in_array( $level, array( 'debug', 'info', 'warn', 'error' ), true ) ? $level : 'info',
				'source'     => sanitize_key( $source ),
				'message'    => sanitize_textarea_field( (string) $message ),
				'context'    => wp_json_encode( $context ),
				'trace_id'   => sanitize_text_field( $trace_id ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	public static function recent_logs( $limit = 100 ) {
		global $wpdb;
		$t = self::table( 'logs' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
}
