<?php
/**
 * Plugin Name:       Mayfair Arena AI Bridge
 * Description:       Secure, admin-controlled AI integration layer connecting WordPress to the official Arena API gateway (models, chat/messages, images). Provides prompt management, property/project/insight AI actions with human review, a task engine, and an optional Elementor widget. Connects ONLY to Arena's documented API — it does not control the arena.ai Agent Mode browser/sandbox session.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Mayfair Properties & Developers
 * License:           GPL-2.0-or-later
 * Text Domain:       mayfair-arena-ai-bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MPA_VERSION', '1.0.0' );
define( 'MPA_DB_VERSION', '1.0.0' );
define( 'MPA_FILE', __FILE__ );
define( 'MPA_DIR', plugin_dir_path( __FILE__ ) );
define( 'MPA_URL', plugin_dir_url( __FILE__ ) );

require_once MPA_DIR . 'includes/class-settings.php';
require_once MPA_DIR . 'includes/class-database.php';
require_once MPA_DIR . 'includes/class-sanitizer.php';
require_once MPA_DIR . 'includes/class-arena-client.php';
require_once MPA_DIR . 'includes/class-context.php';
require_once MPA_DIR . 'includes/class-prompts.php';
require_once MPA_DIR . 'includes/class-ratelimit.php';
require_once MPA_DIR . 'includes/class-tasks.php';
require_once MPA_DIR . 'includes/class-actions.php';
require_once MPA_DIR . 'includes/class-ajax.php';
require_once MPA_DIR . 'includes/class-metabox.php';
require_once MPA_DIR . 'includes/class-rest.php';
require_once MPA_DIR . 'includes/class-elementor.php';
require_once MPA_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'MPA_Database', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MPA_Database', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'MPA_Plugin', 'instance' ) );
