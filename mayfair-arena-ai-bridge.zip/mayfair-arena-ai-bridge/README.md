# Mayfair Arena AI Bridge

**Version 1.0.0 — Generated for manual installation. Not installed, activated, or tested on the live website. No live Arena API calls were made during generation (no API key present in the build environment).**

A secure, admin-controlled AI integration layer connecting the Mayfair Properties & Developers WordPress site to the **official Arena API gateway**.

## Scope statement (read this first)

> This plugin connects WordPress to Arena's documented API gateway (`https://api.preview.arena.ai`).
> It does **NOT** connect to or remotely control the arena.ai **Agent Mode** browser/sandbox session.
> No browser scraping, no arena.ai cookies, no web-UI automation — the documented HTTP API only.

## What it does

- **Connection** — API key (encrypted at rest, never exposed to frontend/REST/logs), base URL, timeout, debug logging, health-check test button (`GET /health/liveliness`).
- **Models** — refresh from `GET /v1/models`, display ID/provider/modalities/availability, enable/disable, choose default + up to **3 fallbacks** (sent per Arena's documented fallback behavior). No model names hardcoded.
- **AI request engine** — `MPA_Arena_Client`: `list_models() · chat_completion() · anthropic_message() · generate_image() · edit_image() · health_check()`, all via `wp_remote_get/post`, HTTP-status validated, capturing `X-Arena-Trace-ID`, `X-Arena-Resolved-Model`, `X-Arena-Fallback-Index/Reason` into tasks and logs.
- **Prompt manager** — CRUD/duplicate/activate; system prompt + user template with **allowlisted `{{variables}}` only** (unknown variables removed, never executed); 24 built-in prompts seeded for the editor actions, all editable.
- **Property / Project / Insight AI** — a "Mayfair AI" side meta box in each editor: Generate → labelled **AI Draft** preview → **Accept / Reject / Copy**. Anti-invention guard: every request carries the post's real allowlisted data plus explicit instructions never to fabricate prices, areas, RERA numbers, possession dates, amenities, or legal details; missing facts are named as unavailable. Insight drafts can be accepted as a **new draft post** — nothing is auto-published, nothing is overwritten automatically.
- **Task engine** — every request stored: type, user, timestamp, model, prompt hash, status, response metadata, error, Arena trace ID. Full prompts/responses stored **only** when the admin enables payload storage (default OFF).
- **Elementor** — "Mayfair AI" widget (Mayfair category): builder-configured prompt/model/tokens, button/loading/error text. Anonymous public requests **disabled by default**; the explicit public mode is per-IP rate limited. Inherits Elementor styling; touches no site settings/colors/fonts.
- **REST** — `mayfair-ai/v1`: `/models`, `/generate`, `/tasks/{id}` — all capability-gated (`manage_mayfair_ai`), key never present in responses.
- **Protection** — local per-user/per-action rate limits (+per-IP for public mode); Arena 429s respected with Retry-After surfaced and no aggressive retry; all AI output sanitized (restricted kses profile, scripts/iframes/PHP stripped) before storage/display; AI output is never executed as PHP/JS/shell.

## Requirements

WordPress 6.0+, PHP 7.4+ (OpenSSL recommended for key encryption), an Arena API key (obtained separately — the plugin ships without one), Elementor optional (admin works without it).

## Install

Plugins → Add New → Upload → `mayfair-arena-ai-bridge.zip` → Activate → **Mayfair AI → Connection** → paste API key → Test Connection → **Models → Refresh** → pick default + fallbacks → open any property and try *Generate Property Description*.

## What it never touches

CPT/taxonomy registrations, existing ACF fields (read-only allowlisted context), Hello Elementor, Elementor Site Settings/Global Colors/Fonts, the Mayfair design system.

## Documentation

`docs/`: architecture · installation · arena-api · security · elementor · property-ai · project-ai · insight-ai · qa-checklist · changelog

## Honesty

Statically validated + engine-level functional tests only (see `docs/qa-checklist.md`). Requires a live WordPress install AND a real Arena API key for end-to-end verification.
