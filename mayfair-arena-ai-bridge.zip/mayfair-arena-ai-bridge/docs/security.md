# Security Model

## API key
- Stored encrypted (AES-256-CBC, key derived from wp_salt('auth')) when OpenSSL exists; marker-prefixed reversible encoding otherwise (documented limitation).
- Displayed masked (first 6 + last 4). Never in: frontend HTML, JS variables, REST responses, logs, error messages, task rows.
- Honest limit: server-side encryption protects against DB dumps/backup leaks, not against a fully compromised PHP process.

## Request security
- Nonce on every admin action (`check_admin_referer('mpa_admin_{task}')`), every AJAX call (`check_ajax_referer`), every REST route (`permission_callback` → `manage_mayfair_ai`).
- Capability checks additionally per handler; editor actions also require `edit_post` on the target post.
- Rate limits: per-user/per-action transients; per-IP (hashed, salted) for the opt-in public widget mode.

## AI output is untrusted, always
- `MPA_Sanitizer::clean()` on every response before storage/display: script/style/iframe blocks removed, PHP blocks (including content) removed, then restricted kses profile (no class/style/id attrs, no media embeds) for HTML mode; plain-text mode strips all tags.
- Widget output rendered via `textContent` (cannot execute); admin previews via `esc_textarea`.
- There is no code path that evals, includes, or shells out — AI output is data, period.

## Content safety
- Every generation is labelled "AI Draft — review required"; Accept/Reject is explicit; Accept writes to exactly one field (WordPress revisions preserve the old content); insight drafts can be routed to a NEW draft post; nothing auto-publishes.
- Anti-invention guard: system prompt enumerates the post's real facts and names the missing ones as forbidden.

## Data & SQL
- 3 tables via `$wpdb->prefix` + dbDelta; all queries prepared; uninstall preserves data by default (explicit opt-in to delete).
- Payload storage (full prompts/responses) default OFF — only SHA-256 prompt hashes and response metadata.
