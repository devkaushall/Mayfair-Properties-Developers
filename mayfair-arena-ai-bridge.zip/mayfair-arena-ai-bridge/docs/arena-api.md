# Arena API Usage

Base: `https://api.preview.arena.ai` (configurable, https enforced)
Auth: `Authorization: Bearer <ARENA_API_KEY>` — attached server-side only.

| Route | Used by | Notes |
|---|---|---|
| `GET /v1/models` | Models screen, REST /models | Normalized to id/provider/input/output/available; cached 1h |
| `POST /v1/chat/completions` | All text actions, widget, REST /generate | OpenAI-compatible; payload includes `models: [primary, fb1..fb3]` when fallbacks configured |
| `POST /v1/messages` | `anthropic_message()` service method | Anthropic-compatible; text blocks parsed |
| `POST /v1/images/generations` | `generate_image()` | prompt, optional model/size (`WxH`)/n(≤4); b64 or URL results |
| `POST /v1/images/edits` | `edit_image()` | multipart with a Media Library source image |
| `GET /health/liveliness` | Test Connection button | No key required by the plugin for this check |

Response metadata captured into tasks/logs when present: `X-Arena-Trace-ID`, `X-Arena-Resolved-Model`, `X-Arena-Fallback-Index`, `X-Arena-Fallback-Reason`.

429 handling: error surfaced with Retry-After; no automatic aggressive retry.

Explicit non-goals: no browser scraping of arena.ai, no Arena web-UI cookies, no web-UI automation, no Agent Mode browser/sandbox control. Image storage: generated media saved to the Media Library only after explicit admin confirmation; existing featured images never overwritten automatically.
