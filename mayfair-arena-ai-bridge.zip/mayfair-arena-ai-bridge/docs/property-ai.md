# Property AI

Editor box actions (each mapped to an editable prompt via action keys):
Generate Property Description (`property_description`) · Rewrite Description (`property_rewrite`) · Generate Short Description (`property_short`) · Generate SEO Title (`property_seo_title`) · Generate Meta Description (`property_meta_desc`) · Generate Property Highlights (`property_highlights`) · Generate CTA Copy (`property_cta`) · Generate Social Caption (`property_social`).

## Data the AI can see (read-only allowlist)
Post title/content/excerpt, featured image alt, taxonomies (property-type, property-status, location), and: mpd_property_id, mpd_price, mpd_price_label, mpd_area_sqft, mpd_bedrooms, mpd_bathrooms, mpd_floor_level, mpd_furnishing, mpd_possession_status, mpd_locality, mpd_video_url, mpd_featured, mpd_verified. Latitude/longitude/file fields are excluded (no display value).

## Anti-invention guarantee
The system prompt lists the post's actual values as the ONLY permitted facts and explicitly forbids inventing price, area, bedrooms, bathrooms, RERA, location, amenities, developer or legal information; missing fields are named as unavailable. This is enforced per request, not just per prompt template.

## Workflow
Generate → labelled AI Draft in the box (with resolved model/fallback/trace metadata) → Accept (content or excerpt; WP revision kept) / Reject / Copy (for Rank Math SEO fields). Content is never replaced without the explicit Accept click.
