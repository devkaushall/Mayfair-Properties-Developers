# Insight AI

Actions: Generate Outline · Generate Draft · Rewrite · Summarize · Generate Excerpt · Generate SEO Title · Generate Meta Description · Generate FAQ Draft · Generate Social Caption (action keys `insight_*`).

Allowlisted context: title/content/excerpt, author (mpi_author_name or WP author), insight-topic taxonomy, mpi_subtitle, mpi_reading_time, mpi_featured, mpi_source_name, mpi_cta_text.

## Draft-first policy
- The "Generate Draft" prompt instructs the model to mark unverified claims **[VERIFY]**.
- Accept offers **New draft post (safest)** — the AI output becomes a separate WordPress draft titled "… — AI Draft" for human editing.
- Nothing is ever auto-published; publishing remains a human editorial decision in WordPress.
