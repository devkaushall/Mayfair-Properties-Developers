# Elementor — Mayfair AI Widget

Category: **Mayfair** (shared with the other Mayfair plugins). Requires Elementor for placement only; all admin features work without Elementor.

## Controls
Prompt (builder-configured — visitors never type prompts) · Model (blank = default) · Max Tokens (16–2000) · Output Mode (button / hidden-until-generated) · Button Text · Loading Text · Error Text.

## Security behavior
- Default: only logged-in users with `manage_mayfair_ai` can trigger generation; for anonymous visitors the widget renders nothing at all (no dead UI, no endpoints exposed).
- Public mode (Settings → Public Widget Mode, default OFF): anonymous clicks allowed, per-IP rate limited, prompt still fixed by the builder, output sanitized and rendered as text.
- The Arena key never reaches the browser; requests route through admin-ajax with a nonce.

## Styling
The widget outputs a plain button (`elementor-button` class) and a text container — it inherits Global Colors/Fonts and the Mayfair design system. The plugin changes no Elementor site settings.
