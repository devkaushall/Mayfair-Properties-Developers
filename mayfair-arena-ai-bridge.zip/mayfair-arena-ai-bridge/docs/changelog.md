# Changelog — Mayfair Arena AI Bridge

## 1.0.0 — 2026-08-19
Initial release (generated; statically + CLI-functionally validated; awaiting live WordPress + real Arena key testing).

- Arena client service (models/chat/messages/images/edits/health) over wp_remote_*, trace-header capture, human error map, 429/Retry-After respect
- Encrypted API key storage, masked display, zero-exposure policy
- Model management from /v1/models; default + max-3 fallback configuration; nothing hardcoded
- Prompt manager with allowlisted {{variables}} + 24 editable seeded prompts
- Property (8) / Project (6) / Insight (9) editor AI actions with per-request anti-invention guard
- Generate → labelled AI Draft → Accept/Reject/Copy; insight drafts to new draft posts; no auto-publish, no silent overwrite
- Task engine (hash-only by default), logs with trace/fallback metadata
- Elementor "Mayfair AI" widget: builder-fixed prompts, default-off public mode, per-IP limits
- Capability-gated REST API (mayfair-ai/v1)
- 3 dbDelta tables, preserve-data-by-default uninstall
- Explicit scope: documented API gateway only — no Agent Mode/browser control
