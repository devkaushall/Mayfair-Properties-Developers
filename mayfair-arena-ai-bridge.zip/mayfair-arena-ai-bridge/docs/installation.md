# Installation & First Run

1. WordPress Admin → Plugins → Add New → Upload Plugin → `mayfair-arena-ai-bridge.zip` → Install → **Activate**.
   Activation creates 3 tables ({prefix}mpa_tasks/_prompts/_logs), seeds 24 editable prompts, adds the `manage_mayfair_ai` capability to administrators.
2. **Mayfair AI → Connection**: paste your Arena API key (stored encrypted; shown masked afterwards), confirm base URL `https://api.preview.arena.ai`, Save → click **Test Connection**. Expect "Connection test OK".
3. **Mayfair AI → Models**: **Refresh Models** → pick a **Primary (Default) Model** and up to 3 fallbacks → Save.
4. Open any Property → the **Mayfair AI** box appears in the sidebar → choose *Generate Property Description* → **Generate** → review the labelled AI Draft → **Accept** (or Copy for SEO fields → paste into Rank Math).
5. Optional: **Settings** — payload storage (default OFF), rate limits, public widget mode (default OFF), uninstall data policy (default: preserve).

Troubleshooting: 401 → key wrong/revoked · 404 on models → check base URL · timeouts → raise Request Timeout (image generation can be slow) · LiteSpeed: admin-ajax is not cached by default; no special exclusion normally needed.
