# Architecture — Mayfair Arena AI Bridge

## Layers
```
WordPress admin/editor UI          Elementor widget           REST (mayfair-ai/v1)
        │                                │                          │
        ▼                                ▼                          ▼
   MPA_Ajax  ◄──nonce+cap+rate──►  MPA_Actions  ◄────────────  MPA_REST
        │                                │
        │                     MPA_Prompts (allowlisted {{vars}})
        │                     MPA_Context (allowlisted post data + anti-invention guard)
        ▼                                ▼
              MPA_Arena_Client  ── wp_remote_* ──►  https://api.preview.arena.ai
                     │                                   /v1/models /v1/chat/completions
                     │                                   /v1/messages /v1/images/* /health/liveliness
                     ▼
        MPA_Tasks + MPA_Database (tasks/prompts/logs, trace IDs, resolved models)
                     │
              MPA_Sanitizer (all AI output cleaned before storage/display)
```

## Files
- `class-settings.php` — config, encrypted key storage, capability (`manage_mayfair_ai`), fallback config (max 3)
- `class-arena-client.php` — 6 API methods, payload builders (public/testable), response parsers, human error map for 400/401/403/404/408/409/429/5xx/network, trace-header capture
- `class-context.php` — per-CPT allowlisted read-only context + `guard_instruction()` anti-invention system text
- `class-prompts.php` — CRUD + `{{var}}` substitution against the allowlist + 24 built-in seeds
- `class-actions.php` — 23 editor actions registry, run() pipeline, accept() as the ONLY write path (user-triggered)
- `class-tasks.php` / `class-database.php` — task engine + 3 dbDelta tables + logging
- `class-sanitizer.php` — restricted kses profile, script/iframe/PHP stripping, per-format cleaning
- `class-ratelimit.php` — transient-based per-user/action + per-IP (public)
- `class-ajax.php` / `class-metabox.php` / `class-rest.php` / `class-elementor*.php` / `class-plugin.php`

## Maintainability against model-lineup change
No model IDs hardcoded anywhere: the lineup lives in the `/v1/models` cache; default/fallbacks are settings; prompts reference models by editable text field. If Arena renames its models tomorrow, the fix is Refresh Models + update two settings — zero code changes.
