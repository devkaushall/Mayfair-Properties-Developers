# QA — Static Results & Live Checklist

## Part A — performed before delivery (generation environment; NO live WordPress, NO real Arena key)

| Check | Result |
|---|---|
| PHP syntax (php -l, PHP 8.4) on all 24 files | PASS |
| All requires resolve; no undefined MPA_ classes/functions | PASS |
| No hardcoded wp_ table names; $wpdb->prefix + dbDelta ×3 | PASS |
| Hooks wired (activation, menu, admin-post, ajax, rest_api_init, elementor/widgets/register) | PASS |
| Nonce per admin task + per AJAX action + REST permission_callbacks | PASS |
| Capability checks (manage_mayfair_ai + edit_post) on every surface | PASS |
| Prepared SQL audit | PASS |
| API key exposure scan: key never echoed/localized/logged/in REST | PASS |
| No eval/assert/create_function/exec/shell_exec/system/passthru/proc_open | PASS |
| No browser automation (no scraping, no cookie jars, no headless drivers) | PASS |
| Arena endpoint validation: exactly the 6 documented routes, https enforced | PASS |
| AI output sanitization on every response path | PASS |
| Elementor widget/category registration (structural) | PASS |
| CPT context mapping: allowlists match the locked architecture | PASS |
| **Functional (PHP CLI): 44/44** — chat payload building + clamping + fallback array, role coercion, OpenAI/Anthropic/legacy response parsing, all 11 HTTP error codes + network mapped human-readably, key encryption round-trip + masking, fallback max-3 dedupe, {{var}} substitution + allowlist rejection + case tolerance, anti-invention guard content, HTML/text/JSON sanitization incl. script/iframe/PHP stripping | PASS |
| Bugs found & fixed during testing | 2 (fallback cap-before-dedupe; PHP block content surviving strip) |

## Part B — requires a live WordPress installation
- [ ] Activate: 3 tables created, 24 prompts seeded, menu + capability present
- [ ] Meta box appears on property/project/insight editors only
- [ ] Prompt CRUD/duplicate/toggle; unknown {{vars}} stripped in a test prompt
- [ ] Rate limit trips after N rapid requests
- [ ] REST routes 401 for logged-out, 403 for non-capable users
- [ ] Elementor widget renders for admin; invisible to logged-out visitors while public mode OFF
- [ ] Settings toggles persist; uninstall respects the preserve-data default
- [ ] View page source of pages with the widget: no API key anywhere

## Part C — requires a real Arena API key
- [ ] Test Connection returns OK (GET /health/liveliness)
- [ ] Refresh Models populates the table from GET /v1/models
- [ ] Property "Generate Description" returns a draft; trace ID + resolved model captured in Tasks
- [ ] Force a fallback (set an invalid primary) → X-Arena-Fallback-Index logged
- [ ] Invalid key → clean 401 message, no key fragments in the error
- [ ] 429 behavior: message shown, no retry storm (observe Logs)
- [ ] Image generation returns media; stored ONLY after explicit confirmation
