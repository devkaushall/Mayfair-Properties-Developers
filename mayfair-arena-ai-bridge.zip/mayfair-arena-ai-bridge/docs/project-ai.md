# Project AI

Actions: Generate Project Description (`project_description`) · Generate Highlights (`project_highlights`) · Generate SEO Title (`project_seo_title`) · Generate Meta Description (`project_meta_desc`) · Generate CTA (`project_cta`) · Generate Social Caption (`project_social`).

Allowlisted context: title/content/excerpt, project-type + location taxonomies, mpd_developer_name, mpd_possession_date, mpd_min_price, mpd_max_price, mpd_rera_number, mpd_featured.

Hard rule enforced by the per-request guard: **RERA numbers and possession dates are never invented** — if absent from the post they are declared unavailable to the model and cannot appear as specific values. Same Generate → AI Draft → Accept/Reject workflow as properties.
