/**
 * Mayfair AI meta box — vanilla JS, async fetch to admin-ajax.
 * Generate -> preview labelled draft -> Accept/Reject/Copy.
 * Never modifies editor content without explicit Accept.
 */
( function () {
	'use strict';

	function init() {
		var box = document.querySelector( '.mpa-box' );
		if ( ! box || typeof window.mpaBox === 'undefined' ) {
			return;
		}
		var postId   = box.getAttribute( 'data-post' );
		var actionEl = box.querySelector( '#mpa-action' );
		var genBtn   = box.querySelector( '.mpa-box__generate' );
		var status   = box.querySelector( '.mpa-box__status' );
		var preview  = box.querySelector( '.mpa-box__preview' );
		var draftEl  = box.querySelector( '.mpa-box__draft' );
		var metaEl   = box.querySelector( '.mpa-box__meta' );
		var targetEl = box.querySelector( '#mpa-target' );

		function post( data ) {
			var body = new URLSearchParams();
			Object.keys( data ).forEach( function ( k ) {
				body.append( k, data[ k ] );
			} );
			return fetch( window.mpaBox.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			} ).then( function ( r ) {
				return r.json();
			} );
		}

		genBtn.addEventListener( 'click', function () {
			status.textContent = window.mpaBox.i18n.working;
			genBtn.disabled = true;
			preview.hidden = true;
			post( {
				action: 'mpa_run_action',
				nonce: window.mpaBox.nonce,
				post_id: postId,
				action_key: actionEl.value
			} ).then( function ( res ) {
				genBtn.disabled = false;
				if ( ! res || ! res.success ) {
					status.textContent = ( res && res.data && res.data.message ) ? res.data.message : window.mpaBox.i18n.error;
					return;
				}
				status.textContent = '';
				draftEl.value = res.data.draft;
				var meta = res.data.meta || {};
				var bits = [];
				if ( meta.resolved_model ) { bits.push( 'Model: ' + meta.resolved_model ); }
				if ( meta.fallback_index ) { bits.push( 'Fallback #' + meta.fallback_index + ( meta.fallback_reason ? ' (' + meta.fallback_reason + ')' : '' ) ); }
				if ( meta.trace_id ) { bits.push( 'Trace: ' + meta.trace_id ); }
				metaEl.textContent = bits.join( ' · ' );
				preview.hidden = false;
			} ).catch( function () {
				genBtn.disabled = false;
				status.textContent = window.mpaBox.i18n.error;
			} );
		} );

		box.querySelector( '.mpa-box__accept' ).addEventListener( 'click', function () {
			if ( ! window.confirm( window.mpaBox.i18n.confirm ) ) {
				return;
			}
			post( {
				action: 'mpa_accept_draft',
				nonce: window.mpaBox.nonce,
				post_id: postId,
				target: targetEl ? targetEl.value : 'content',
				draft: draftEl.value
			} ).then( function ( res ) {
				status.textContent = ( res && res.data && res.data.message ) ? res.data.message : '';
				if ( res && res.success ) {
					preview.hidden = true;
					window.location.reload();
				}
			} );
		} );

		box.querySelector( '.mpa-box__reject' ).addEventListener( 'click', function () {
			draftEl.value = '';
			preview.hidden = true;
			status.textContent = '';
		} );

		box.querySelector( '.mpa-box__copy' ).addEventListener( 'click', function () {
			draftEl.select();
			document.execCommand( 'copy' );
			status.textContent = 'Copied.';
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
