<?php
/**
 * Model management.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpa_set      = MPA_Settings::get();
$mpa_models   = isset( $mpa_set['models_cache'] ) ? (array) $mpa_set['models_cache'] : array();
$mpa_disabled = isset( $mpa_set['disabled_models'] ) ? (array) $mpa_set['disabled_models'] : array();
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Models', 'mayfair-arena-ai-bridge' ); ?></h1>
	<?php if ( isset( $_GET['mpa_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpa_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:16px;">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="refresh_models">
		<?php wp_nonce_field( 'mpa_admin_refresh_models', '_mpanonce' ); ?>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'Refresh Models (GET /v1/models)', 'mayfair-arena-ai-bridge' ); ?></button>
		<?php if ( $mpa_set['models_cached_at'] ) : ?>
			<span class="description" style="margin-left:8px;"><?php echo esc_html( sprintf( /* translators: %s time */ __( 'Last refreshed: %s', 'mayfair-arena-ai-bridge' ), gmdate( 'Y-m-d H:i', (int) $mpa_set['models_cached_at'] ) . ' UTC' ) ); ?></span>
		<?php endif; ?>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="save_models">
		<?php wp_nonce_field( 'mpa_admin_save_models', '_mpanonce' ); ?>

		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( 'Model ID', 'mayfair-arena-ai-bridge' ); ?></th>
				<th><?php esc_html_e( 'Provider', 'mayfair-arena-ai-bridge' ); ?></th>
				<th><?php esc_html_e( 'Input', 'mayfair-arena-ai-bridge' ); ?></th>
				<th><?php esc_html_e( 'Output', 'mayfair-arena-ai-bridge' ); ?></th>
				<th><?php esc_html_e( 'Available', 'mayfair-arena-ai-bridge' ); ?></th>
				<th><?php esc_html_e( 'Enabled', 'mayfair-arena-ai-bridge' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $mpa_models as $mpa_m ) : ?>
				<tr>
					<td><code><?php echo esc_html( $mpa_m['id'] ); ?></code></td>
					<td><?php echo esc_html( $mpa_m['provider'] ? $mpa_m['provider'] : '—' ); ?></td>
					<td><?php echo esc_html( $mpa_m['input'] ); ?></td>
					<td><?php echo esc_html( $mpa_m['output'] ); ?></td>
					<td><?php echo ! empty( $mpa_m['available'] ) ? '&#10003;' : '&#10007;'; ?></td>
					<td><label><input type="checkbox" name="enabled_models[]" value="<?php echo esc_attr( $mpa_m['id'] ); ?>" <?php checked( ! in_array( $mpa_m['id'], $mpa_disabled, true ) ); ?> onchange="this.form.querySelector('[name=\'disabled_models[]\'][value='+JSON.stringify(this.value)+']').disabled=this.checked;"></label>
					<input type="hidden" name="disabled_models[]" value="<?php echo esc_attr( $mpa_m['id'] ); ?>" <?php disabled( ! in_array( $mpa_m['id'], $mpa_disabled, true ) ); ?>></td>
				</tr>
			<?php endforeach; ?>
			<?php if ( empty( $mpa_models ) ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'No models cached yet. Configure the API key under Connection, then click Refresh Models.', 'mayfair-arena-ai-bridge' ); ?></td></tr>
			<?php endif; ?>
			</tbody>
		</table>

		<h2><?php esc_html_e( 'Default & Fallbacks', 'mayfair-arena-ai-bridge' ); ?></h2>
		<table class="form-table">
			<tr><th><label for="mpa-default"><?php esc_html_e( 'Primary (Default) Model', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-default" type="text" name="default_model" class="regular-text" list="mpa-model-list" value="<?php echo esc_attr( $mpa_set['default_model'] ); ?>"></td></tr>
			<?php for ( $mpa_i = 1; $mpa_i <= 3; $mpa_i++ ) : ?>
				<tr><th><label for="mpa-fb<?php echo esc_attr( $mpa_i ); ?>"><?php echo esc_html( sprintf( /* translators: %d index */ __( 'Fallback %d', 'mayfair-arena-ai-bridge' ), $mpa_i ) ); ?></label></th>
					<td><input id="mpa-fb<?php echo esc_attr( $mpa_i ); ?>" type="text" name="fallback_<?php echo esc_attr( $mpa_i ); ?>" class="regular-text" list="mpa-model-list" value="<?php echo esc_attr( isset( $mpa_set['fallback_models'][ $mpa_i - 1 ] ) ? $mpa_set['fallback_models'][ $mpa_i - 1 ] : '' ); ?>"></td></tr>
			<?php endfor; ?>
		</table>
		<datalist id="mpa-model-list">
			<?php foreach ( $mpa_models as $mpa_m ) : ?>
				<option value="<?php echo esc_attr( $mpa_m['id'] ); ?>"></option>
			<?php endforeach; ?>
		</datalist>
		<p class="description"><?php esc_html_e( 'Fallbacks (max 3) are sent with each request per Arena\'s documented fallback behavior. No model name is permanently hardcoded — the lineup comes from /v1/models.', 'mayfair-arena-ai-bridge' ); ?></p>
		<?php submit_button( __( 'Save Model Configuration', 'mayfair-arena-ai-bridge' ) ); ?>
	</form>
</div>
