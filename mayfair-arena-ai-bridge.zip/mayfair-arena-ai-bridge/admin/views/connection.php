<?php
/**
 * Connection settings.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpa_set = MPA_Settings::get();
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Connection', 'mayfair-arena-ai-bridge' ); ?></h1>
	<?php if ( isset( $_GET['mpa_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpa_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="save_connection">
		<?php wp_nonce_field( 'mpa_admin_save_connection', '_mpanonce' ); ?>
		<table class="form-table">
			<tr><th><label for="mpa-key"><?php esc_html_e( 'API Key', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td>
					<input id="mpa-key" type="password" name="api_key" class="regular-text" autocomplete="off" placeholder="<?php echo esc_attr( MPA_Settings::has_api_key() ? __( 'Key saved — enter a new key to replace it', 'mayfair-arena-ai-bridge' ) : __( 'Paste your Arena API key', 'mayfair-arena-ai-bridge' ) ); ?>">
					<?php if ( MPA_Settings::has_api_key() ) : ?>
						<p class="description"><?php esc_html_e( 'Current key:', 'mayfair-arena-ai-bridge' ); ?> <code><?php echo esc_html( MPA_Settings::masked_key() ); ?></code>
						&nbsp;<label><input type="checkbox" name="clear_key" value="1"> <?php esc_html_e( 'Remove key', 'mayfair-arena-ai-bridge' ); ?></label></p>
					<?php endif; ?>
					<p class="description"><?php esc_html_e( 'Stored encrypted server-side. Never rendered in frontend HTML, JavaScript, REST responses, or logs.', 'mayfair-arena-ai-bridge' ); ?></p>
				</td></tr>
			<tr><th><label for="mpa-base"><?php esc_html_e( 'API Base URL', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-base" type="url" name="api_base" class="regular-text" value="<?php echo esc_attr( $mpa_set['api_base'] ); ?>">
				<p class="description"><?php esc_html_e( 'Default: https://api.preview.arena.ai — https required.', 'mayfair-arena-ai-bridge' ); ?></p></td></tr>
			<tr><th><label for="mpa-timeout"><?php esc_html_e( 'Request Timeout (seconds)', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-timeout" type="number" name="timeout" min="5" max="300" value="<?php echo esc_attr( $mpa_set['timeout'] ); ?>"></td></tr>
			<tr><th><?php esc_html_e( 'Debug Logging', 'mayfair-arena-ai-bridge' ); ?></th>
				<td><label><input type="checkbox" name="debug_logging" value="1" <?php checked( ! empty( $mpa_set['debug_logging'] ) ); ?>> <?php esc_html_e( 'Write debug-level entries to the Logs screen', 'mayfair-arena-ai-bridge' ); ?></label></td></tr>
		</table>
		<?php submit_button( __( 'Save Connection', 'mayfair-arena-ai-bridge' ) ); ?>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="test_connection">
		<?php wp_nonce_field( 'mpa_admin_test_connection', '_mpanonce' ); ?>
		<button type="submit" class="button"><?php esc_html_e( 'Test Connection (GET /health/liveliness)', 'mayfair-arena-ai-bridge' ); ?></button>
	</form>
</div>
