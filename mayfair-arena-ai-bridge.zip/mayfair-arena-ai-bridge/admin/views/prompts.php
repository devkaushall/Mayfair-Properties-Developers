<?php
/**
 * Prompt manager.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpa_edit = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mpa_p    = $mpa_edit ? MPA_Prompts::get( $mpa_edit ) : null;
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Prompts', 'mayfair-arena-ai-bridge' ); ?></h1>
	<?php if ( isset( $_GET['mpa_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpa_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<h2><?php echo $mpa_p ? esc_html__( 'Edit Prompt', 'mayfair-arena-ai-bridge' ) : esc_html__( 'Create Prompt', 'mayfair-arena-ai-bridge' ); ?></h2>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="save_prompt">
		<input type="hidden" name="prompt_id" value="<?php echo esc_attr( $mpa_p ? $mpa_p['id'] : 0 ); ?>">
		<?php wp_nonce_field( 'mpa_admin_save_prompt', '_mpanonce' ); ?>
		<table class="form-table">
			<tr><th><label for="mpa-pname"><?php esc_html_e( 'Name', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-pname" type="text" name="name" class="regular-text" required value="<?php echo esc_attr( $mpa_p ? $mpa_p['name'] : '' ); ?>"></td></tr>
			<tr><th><label for="mpa-pdesc"><?php esc_html_e( 'Description', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-pdesc" type="text" name="description" class="large-text" value="<?php echo esc_attr( $mpa_p ? $mpa_p['description'] : '' ); ?>"></td></tr>
			<tr><th><label for="mpa-psys"><?php esc_html_e( 'System Prompt', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><textarea id="mpa-psys" name="system_prompt" rows="4" class="large-text"><?php echo esc_textarea( $mpa_p ? $mpa_p['system_prompt'] : '' ); ?></textarea></td></tr>
			<tr><th><label for="mpa-puser"><?php esc_html_e( 'User Prompt Template', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><textarea id="mpa-puser" name="user_template" rows="5" class="large-text"><?php echo esc_textarea( $mpa_p ? $mpa_p['user_template'] : '' ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Allowed variables:', 'mayfair-arena-ai-bridge' ); ?> <code>{{<?php echo esc_html( implode( '}} {{', MPA_Context::allowed_variables() ) ); ?>}}</code><br>
				<?php esc_html_e( 'Unknown variables are removed. No PHP or code execution of any kind.', 'mayfair-arena-ai-bridge' ); ?></p></td></tr>
			<tr><th><label for="mpa-pmodel"><?php esc_html_e( 'Model (blank = default)', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-pmodel" type="text" name="model" class="regular-text" value="<?php echo esc_attr( $mpa_p ? $mpa_p['model'] : '' ); ?>"></td></tr>
			<tr><th><label for="mpa-ptemp"><?php esc_html_e( 'Temperature (0-2)', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-ptemp" type="number" step="0.1" min="0" max="2" name="temperature" value="<?php echo esc_attr( $mpa_p ? $mpa_p['temperature'] : '0.7' ); ?>"></td></tr>
			<tr><th><label for="mpa-ptok"><?php esc_html_e( 'Max Tokens', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-ptok" type="number" min="1" max="32000" name="max_tokens" value="<?php echo esc_attr( $mpa_p ? $mpa_p['max_tokens'] : '1024' ); ?>"></td></tr>
			<tr><th><label for="mpa-pfmt"><?php esc_html_e( 'Output Format', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><select id="mpa-pfmt" name="output_format">
					<?php foreach ( array( 'text', 'html', 'markdown', 'json' ) as $mpa_fmt ) : ?>
						<option value="<?php echo esc_attr( $mpa_fmt ); ?>" <?php selected( $mpa_p ? $mpa_p['output_format'] : 'text', $mpa_fmt ); ?>><?php echo esc_html( strtoupper( $mpa_fmt ) ); ?></option>
					<?php endforeach; ?>
				</select></td></tr>
			<tr><th><label for="mpa-pkey"><?php esc_html_e( 'Editor Action Key (optional)', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-pkey" type="text" name="action_key" value="<?php echo esc_attr( $mpa_p ? $mpa_p['action_key'] : '' ); ?>">
				<p class="description"><?php esc_html_e( 'Links this prompt to an editor action (e.g. property_description). Leave empty for standalone prompts.', 'mayfair-arena-ai-bridge' ); ?></p></td></tr>
			<tr><th><?php esc_html_e( 'Status', 'mayfair-arena-ai-bridge' ); ?></th>
				<td><select name="status">
					<option value="active" <?php selected( $mpa_p ? $mpa_p['status'] : 'active', 'active' ); ?>><?php esc_html_e( 'Active', 'mayfair-arena-ai-bridge' ); ?></option>
					<option value="inactive" <?php selected( $mpa_p ? $mpa_p['status'] : '', 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'mayfair-arena-ai-bridge' ); ?></option>
				</select></td></tr>
		</table>
		<?php submit_button( $mpa_p ? __( 'Save Prompt', 'mayfair-arena-ai-bridge' ) : __( 'Create Prompt', 'mayfair-arena-ai-bridge' ) ); ?>
	</form>

	<h2><?php esc_html_e( 'All Prompts', 'mayfair-arena-ai-bridge' ); ?></h2>
	<table class="widefat striped">
		<thead><tr>
			<th><?php esc_html_e( 'Name', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Action Key', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Model', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Format', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Status', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Actions', 'mayfair-arena-ai-bridge' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( MPA_Prompts::all() as $mpa_row ) : ?>
			<tr>
				<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=mpa-prompts&edit=' . (int) $mpa_row['id'] ) ); ?>"><?php echo esc_html( $mpa_row['name'] ); ?></a></strong></td>
				<td><code><?php echo esc_html( $mpa_row['action_key'] ? $mpa_row['action_key'] : '—' ); ?></code></td>
				<td><?php echo esc_html( $mpa_row['model'] ? $mpa_row['model'] : __( '(default)', 'mayfair-arena-ai-bridge' ) ); ?></td>
				<td><?php echo esc_html( strtoupper( $mpa_row['output_format'] ) ); ?></td>
				<td><?php echo esc_html( ucfirst( $mpa_row['status'] ) ); ?></td>
				<td>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpa_admin_action"><input type="hidden" name="mpa_task" value="toggle_prompt">
						<input type="hidden" name="prompt_id" value="<?php echo esc_attr( $mpa_row['id'] ); ?>">
						<input type="hidden" name="status" value="<?php echo esc_attr( 'active' === $mpa_row['status'] ? 'inactive' : 'active' ); ?>">
						<?php wp_nonce_field( 'mpa_admin_toggle_prompt', '_mpanonce' ); ?>
						<button type="submit" class="button-link"><?php echo 'active' === $mpa_row['status'] ? esc_html__( 'Deactivate', 'mayfair-arena-ai-bridge' ) : esc_html__( 'Activate', 'mayfair-arena-ai-bridge' ); ?></button>
					</form> |
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpa_admin_action"><input type="hidden" name="mpa_task" value="duplicate_prompt">
						<input type="hidden" name="prompt_id" value="<?php echo esc_attr( $mpa_row['id'] ); ?>">
						<?php wp_nonce_field( 'mpa_admin_duplicate_prompt', '_mpanonce' ); ?>
						<button type="submit" class="button-link"><?php esc_html_e( 'Duplicate', 'mayfair-arena-ai-bridge' ); ?></button>
					</form> |
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<input type="hidden" name="action" value="mpa_admin_action"><input type="hidden" name="mpa_task" value="delete_prompt">
						<input type="hidden" name="prompt_id" value="<?php echo esc_attr( $mpa_row['id'] ); ?>">
						<?php wp_nonce_field( 'mpa_admin_delete_prompt', '_mpanonce' ); ?>
						<button type="submit" class="button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this prompt?', 'mayfair-arena-ai-bridge' ) ); ?>');"><?php esc_html_e( 'Delete', 'mayfair-arena-ai-bridge' ); ?></button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
