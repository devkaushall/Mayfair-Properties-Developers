<?php
/**
 * Dashboard: connection status, model, activity.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpa_set      = MPA_Settings::get();
$mpa_counters = MPA_Tasks::counters();
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Dashboard', 'mayfair-arena-ai-bridge' ); ?></h1>
	<?php if ( isset( $_GET['mpa_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpa_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<div class="mpa-cards">
		<div class="mpa-card">
			<span class="mpa-card__n"><?php echo MPA_Settings::has_api_key() ? '&#10003;' : '&#10007;'; ?></span>
			<span class="mpa-card__l"><?php echo MPA_Settings::has_api_key() ? esc_html__( 'API Key Configured', 'mayfair-arena-ai-bridge' ) : esc_html__( 'No API Key', 'mayfair-arena-ai-bridge' ); ?></span>
		</div>
		<div class="mpa-card"><span class="mpa-card__n" style="font-size:14px;"><?php echo esc_html( $mpa_set['default_model'] ? $mpa_set['default_model'] : '—' ); ?></span><span class="mpa-card__l"><?php esc_html_e( 'Default Model', 'mayfair-arena-ai-bridge' ); ?></span></div>
		<div class="mpa-card"><span class="mpa-card__n"><?php echo esc_html( $mpa_counters['today'] ); ?></span><span class="mpa-card__l"><?php esc_html_e( 'Requests Today', 'mayfair-arena-ai-bridge' ); ?></span></div>
		<div class="mpa-card"><span class="mpa-card__n"><?php echo esc_html( $mpa_counters['total'] ); ?></span><span class="mpa-card__l"><?php esc_html_e( 'Total Tasks', 'mayfair-arena-ai-bridge' ); ?></span></div>
		<div class="mpa-card"><span class="mpa-card__n"><?php echo esc_html( $mpa_counters['failed'] ); ?></span><span class="mpa-card__l"><?php esc_html_e( 'Failed', 'mayfair-arena-ai-bridge' ); ?></span></div>
	</div>

	<table class="widefat striped" style="max-width:760px;">
		<tr><th><?php esc_html_e( 'API Base', 'mayfair-arena-ai-bridge' ); ?></th><td><code><?php echo esc_html( $mpa_set['api_base'] ); ?></code></td></tr>
		<tr><th><?php esc_html_e( 'Fallback Models', 'mayfair-arena-ai-bridge' ); ?></th><td><?php echo esc_html( $mpa_set['fallback_models'] ? implode( ' → ', $mpa_set['fallback_models'] ) : '—' ); ?></td></tr>
		<tr><th><?php esc_html_e( 'Last Request', 'mayfair-arena-ai-bridge' ); ?></th>
			<td><?php echo $mpa_counters['last'] ? esc_html( $mpa_counters['last']['created_at'] . ' — ' . $mpa_counters['last']['action_key'] . ' (' . $mpa_counters['last']['status'] . ')' ) : '—'; ?></td></tr>
		<tr><th><?php esc_html_e( 'Last Error', 'mayfair-arena-ai-bridge' ); ?></th>
			<td><?php echo $mpa_counters['last_error'] ? esc_html( $mpa_counters['last_error']['created_at'] . ' — ' . $mpa_counters['last_error']['error'] ) : '—'; ?></td></tr>
	</table>
	<p class="description"><?php esc_html_e( 'Usage/cost analytics are not shown because Arena billing data is not exposed to this plugin — no fabricated numbers.', 'mayfair-arena-ai-bridge' ); ?></p>
	<p class="description"><strong><?php esc_html_e( 'Scope:', 'mayfair-arena-ai-bridge' ); ?></strong> <?php esc_html_e( 'This plugin talks to Arena\'s documented API gateway only. It does not connect to or control the arena.ai Agent Mode browser/sandbox session.', 'mayfair-arena-ai-bridge' ); ?></p>
</div>
