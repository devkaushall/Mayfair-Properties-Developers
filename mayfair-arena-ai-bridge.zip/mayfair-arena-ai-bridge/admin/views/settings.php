<?php
/**
 * Settings: privacy, rate limits, public widget, uninstall.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mpa_set = MPA_Settings::get();
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Settings', 'mayfair-arena-ai-bridge' ); ?></h1>
	<?php if ( isset( $_GET['mpa_notice'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
		<div class="notice notice-info is-dismissible"><p><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['mpa_notice'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mpa_admin_action">
		<input type="hidden" name="mpa_task" value="save_settings">
		<?php wp_nonce_field( 'mpa_admin_save_settings', '_mpanonce' ); ?>

		<h2><?php esc_html_e( 'Privacy', 'mayfair-arena-ai-bridge' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'Store Payloads', 'mayfair-arena-ai-bridge' ); ?></th>
				<td><label><input type="checkbox" name="store_payloads" value="1" <?php checked( ! empty( $mpa_set['store_payloads'] ) ); ?>>
					<?php esc_html_e( 'Store full prompts and responses with each task (default OFF — only hashes and metadata are stored)', 'mayfair-arena-ai-bridge' ); ?></label></td></tr>
		</table>

		<h2><?php esc_html_e( 'Rate Limiting (local, WordPress-side)', 'mayfair-arena-ai-bridge' ); ?></h2>
		<table class="form-table">
			<tr><th><label for="mpa-rum"><?php esc_html_e( 'Per user per action', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-rum" type="number" name="rate_user_max" min="1" max="500" value="<?php echo esc_attr( $mpa_set['rate_user_max'] ); ?>">
					<?php esc_html_e( 'requests per', 'mayfair-arena-ai-bridge' ); ?>
					<input type="number" name="rate_window" min="60" max="86400" value="<?php echo esc_attr( $mpa_set['rate_window'] ); ?>"> <?php esc_html_e( 'seconds', 'mayfair-arena-ai-bridge' ); ?></td></tr>
			<tr><th><label for="mpa-rim"><?php esc_html_e( 'Per IP (public widget only)', 'mayfair-arena-ai-bridge' ); ?></label></th>
				<td><input id="mpa-rim" type="number" name="rate_ip_max" min="1" max="100" value="<?php echo esc_attr( $mpa_set['rate_ip_max'] ); ?>"></td></tr>
		</table>
		<p class="description"><?php esc_html_e( 'Arena-side 429 responses are respected; the plugin never retries aggressively and surfaces Retry-After when provided.', 'mayfair-arena-ai-bridge' ); ?></p>

		<h2><?php esc_html_e( 'Public Widget Mode', 'mayfair-arena-ai-bridge' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'Anonymous requests', 'mayfair-arena-ai-bridge' ); ?></th>
				<td><label><input type="checkbox" name="public_widget" value="1" <?php checked( ! empty( $mpa_set['public_widget'] ) ); ?>>
					<?php esc_html_e( 'Allow logged-out visitors to trigger the Mayfair AI Elementor widget (default OFF; per-IP rate limited; prompts remain builder-configured)', 'mayfair-arena-ai-bridge' ); ?></label></td></tr>
		</table>

		<h2><?php esc_html_e( 'Uninstall', 'mayfair-arena-ai-bridge' ); ?></h2>
		<table class="form-table">
			<tr><th><?php esc_html_e( 'Data on uninstall', 'mayfair-arena-ai-bridge' ); ?></th>
				<td><label><input type="checkbox" name="delete_on_uninstall" value="1" <?php checked( 1, (int) get_option( 'mpa_delete_on_uninstall', 0 ) ); ?>>
					<?php esc_html_e( 'Delete all plugin tables and settings on uninstall (default OFF — data is preserved)', 'mayfair-arena-ai-bridge' ); ?></label></td></tr>
		</table>

		<?php submit_button( __( 'Save Settings', 'mayfair-arena-ai-bridge' ) ); ?>
	</form>
</div>
