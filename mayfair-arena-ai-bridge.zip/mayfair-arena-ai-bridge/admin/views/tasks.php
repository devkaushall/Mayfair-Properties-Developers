<?php
/**
 * Task history.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Tasks', 'mayfair-arena-ai-bridge' ); ?></h1>
	<table class="widefat striped">
		<thead><tr>
			<th>ID</th>
			<th><?php esc_html_e( 'Date', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Type', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Action', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'User', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Post', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Model → Resolved', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Status', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Trace ID', 'mayfair-arena-ai-bridge' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( MPA_Tasks::recent( 100 ) as $mpa_t ) : ?>
			<tr>
				<td><?php echo esc_html( $mpa_t['id'] ); ?></td>
				<td><?php echo esc_html( $mpa_t['created_at'] ); ?></td>
				<td><?php echo esc_html( $mpa_t['task_type'] ); ?></td>
				<td><code><?php echo esc_html( $mpa_t['action_key'] ); ?></code></td>
				<td><?php echo esc_html( $mpa_t['user_id'] ? get_the_author_meta( 'display_name', (int) $mpa_t['user_id'] ) : '—' ); ?></td>
				<td><?php echo $mpa_t['post_id'] ? esc_html( get_the_title( (int) $mpa_t['post_id'] ) ) : '—'; ?></td>
				<td><?php echo esc_html( $mpa_t['model'] . ( $mpa_t['resolved_model'] && $mpa_t['resolved_model'] !== $mpa_t['model'] ? ' → ' . $mpa_t['resolved_model'] : '' ) ); ?></td>
				<td><span class="mpa-badge mpa-badge--<?php echo esc_attr( $mpa_t['status'] ); ?>"><?php echo esc_html( ucfirst( $mpa_t['status'] ) ); ?></span>
					<?php if ( $mpa_t['error'] ) : ?><br><small><?php echo esc_html( $mpa_t['error'] ); ?></small><?php endif; ?></td>
				<td><code><?php echo esc_html( $mpa_t['trace_id'] ? $mpa_t['trace_id'] : '—' ); ?></code></td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<p class="description"><?php esc_html_e( 'Full prompts/responses are stored only when "Store payloads" is enabled in Settings. Otherwise only hashes and metadata are kept.', 'mayfair-arena-ai-bridge' ); ?></p>
</div>
