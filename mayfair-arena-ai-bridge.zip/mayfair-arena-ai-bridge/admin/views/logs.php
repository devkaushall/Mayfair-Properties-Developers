<?php
/**
 * Logs.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="wrap mpa-wrap">
	<h1><?php esc_html_e( 'Mayfair AI — Logs', 'mayfair-arena-ai-bridge' ); ?></h1>
	<table class="widefat striped">
		<thead><tr>
			<th><?php esc_html_e( 'Date', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Level', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Source', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Message', 'mayfair-arena-ai-bridge' ); ?></th>
			<th><?php esc_html_e( 'Trace / Fallback', 'mayfair-arena-ai-bridge' ); ?></th>
		</tr></thead>
		<tbody>
		<?php foreach ( MPA_Database::recent_logs( 200 ) as $mpa_l ) : ?>
			<?php $mpa_ctx = json_decode( (string) $mpa_l['context'], true ); ?>
			<tr>
				<td><?php echo esc_html( $mpa_l['created_at'] ); ?></td>
				<td><span class="mpa-badge mpa-badge--<?php echo esc_attr( $mpa_l['level'] ); ?>"><?php echo esc_html( strtoupper( $mpa_l['level'] ) ); ?></span></td>
				<td><?php echo esc_html( $mpa_l['source'] ); ?></td>
				<td><?php echo esc_html( $mpa_l['message'] ); ?></td>
				<td>
					<?php if ( $mpa_l['trace_id'] ) : ?><code><?php echo esc_html( $mpa_l['trace_id'] ); ?></code><?php endif; ?>
					<?php if ( is_array( $mpa_ctx ) && isset( $mpa_ctx['fallback_index'] ) ) : ?>
						<br><small><?php echo esc_html( 'Fallback #' . $mpa_ctx['fallback_index'] . ( isset( $mpa_ctx['fallback_reason'] ) ? ' — ' . $mpa_ctx['fallback_reason'] : '' ) ); ?></small>
					<?php endif; ?>
					<?php if ( is_array( $mpa_ctx ) && isset( $mpa_ctx['resolved_model'] ) ) : ?>
						<br><small><?php echo esc_html( 'Resolved: ' . $mpa_ctx['resolved_model'] ); ?></small>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</div>
