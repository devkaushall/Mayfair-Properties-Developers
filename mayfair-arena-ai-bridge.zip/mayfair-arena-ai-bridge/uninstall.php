<?php
/**
 * Uninstall: preserves data by DEFAULT. Tables/options removed only if
 * the admin explicitly enabled deletion in Mayfair AI → Settings.
 *
 * @package Mayfair_Arena_AI_Bridge
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( ! get_option( 'mpa_delete_on_uninstall' ) ) {
	return;
}

global $wpdb;

foreach ( array( 'tasks', 'prompts', 'logs' ) as $mpa_suffix ) {
	$mpa_table = $wpdb->prefix . 'mpa_' . $mpa_suffix;
	$wpdb->query( "DROP TABLE IF EXISTS `{$mpa_table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- uninstall cleanup
}

delete_option( 'mpa_settings' );
delete_option( 'mpa_db_version' );
delete_option( 'mpa_prompts_seeded' );
delete_option( 'mpa_delete_on_uninstall' );
