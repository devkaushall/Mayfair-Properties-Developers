/**
 * Mayfair AI Elementor widget — vanilla JS.
 * Sends the widget-configured prompt to the plugin's AJAX endpoint.
 * The Arena API key never touches the browser; output rendered as text.
 */
( function () {
	'use strict';

	function initWidget( el ) {
		var btn = el.querySelector( '.mpa-widget__btn' );
		var out = el.querySelector( '.mpa-widget__out' );
		var txt = el.querySelector( '.mpa-widget__text' );
		if ( ! btn || typeof window.mpaWidget === 'undefined' ) {
			return;
		}
		btn.addEventListener( 'click', function () {
			btn.disabled = true;
			out.hidden = false;
			txt.textContent = el.getAttribute( 'data-loading' ) || '…';
			var body = new URLSearchParams();
			body.append( 'action', 'mpa_widget_generate' );
			body.append( 'nonce', window.mpaWidget.nonce );
			body.append( 'prompt', el.getAttribute( 'data-prompt' ) || '' );
			body.append( 'model', el.getAttribute( 'data-model' ) || '' );
			body.append( 'max_tokens', el.getAttribute( 'data-max' ) || '512' );
			fetch( window.mpaWidget.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			} ).then( function ( r ) {
				return r.json();
			} ).then( function ( res ) {
				btn.disabled = false;
				if ( res && res.success && res.data && typeof res.data.text === 'string' ) {
					txt.textContent = res.data.text; // textContent: output can never execute
				} else {
					txt.textContent = ( res && res.data && res.data.message ) ? res.data.message : ( el.getAttribute( 'data-error' ) || 'Error' );
				}
			} ).catch( function () {
				btn.disabled = false;
				txt.textContent = el.getAttribute( 'data-error' ) || 'Error';
			} );
		} );
	}

	function init() {
		document.querySelectorAll( '.mpa-widget' ).forEach( initWidget );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
